"""An account that can buy ChiNext but not STAR: skip the STAR names, or hold a STAR index fund in their place?
(declared before running, 2026-10-30, round seven)

The user can trade the main board and ChiNext but not STAR (688/689); for a STAR name on the list they would accept
"the STAR industry ETF or a STAR index" instead. Same rule, account and costs as real_account.py (10,000 yuan,
commission 0.025% with a 5-yuan minimum, stamp duty 0.05% on stock sales, transfer fee 0.001% on stocks; whole lots;
names on the new list stay untouched; the list is published after the close and traded at the next open).

B   skip:  pass over STAR names and keep going down the list (real_account.py, board "no_star").
C50 STAR 50: each STAR name among the first three becomes one place held in a STAR 50 ETF, priced by the index
    (ETFs tracking it have traded since 2020-11); the other places go down the list, passing over STAR names.
C200 STAR 200 (small caps): the same with the STAR 200 index; ETFs tracking it only listed from 2024-12-24, so
    earlier periods are hypothetical.
An index place is kept while the new list still has at least as many STAR names (place k is kept when there are at
least k); the fund pays commission only (no stamp duty or transfer fee), 100 units per lot at 1/1000 of the index.

Per run: as in real_account.py, plus the average share of the account held in the index fund. Start offsets 0, 5,
10, 15 sessions from 2024-07-01 and from 2024-01-31; the user's floor is now 0.7, so stops at 0.7 are counted.
Industry funds are not simulated: the STAR names that reached the first three are counted by industry against the
STAR industry ETFs that existed (fetched with fetch_star.py).
"""
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import real_account as ra  # noqa: E402

h, days, n, codes = ra.h, ra.days, ra.n, ra.codes
STAR = ('688', '689')
star = json.loads((ra.ir.HISTORY / 'star_indices.json').read_text(encoding='utf-8'))


def series(code):
    rows = {f"{r['trade_date'][:4]}-{r['trade_date'][4:6]}-{r['trade_date'][6:]}": r for r in star['indices'][code]['rows']}
    get = lambda key: np.array([float(rows[d][key]) if d in rows and rows[d][key] is not None else np.nan for d in days])
    return {'open': get('open'), 'close': get('close'), 'pre': get('pre_close')}


INDEX = {'C50': series('000688.SH'), 'C200': series('000699.SH')}


def simulate(variant, first, offset, floor=None, account='1万普通'):
    start_cash, minimum = ra.ACCOUNTS[account]
    idx = INDEX[variant]
    decisions = set(range(first + offset, n - 1, 20))
    start = min(decisions)
    cash, held, pending, stopped = start_cash, {}, set(), False      # held: stock index or ('idx', k) -> value
    nav, stats, index_share = [1.0], Counter(), []
    stock_list, star_places = [], 0
    for d in range(start + 1, n):
        t = d - 1
        switch = t in decisions and not stopped
        if switch:
            full = ra.ranked(t)
            star_places = sum(codes[i].startswith(STAR) for i in full[:3])
            stock_list = [i for i in full if not codes[i].startswith(STAR)]
            keep = set(stock_list[:3 - star_places]) | {('idx', k) for k in range(1, star_places + 1)}
            pending |= {key for key in held if key not in keep}
            stats['switches'] += 1
            stats['star_places'] += star_places
        freed = False
        for key in sorted(pending, key=str):                        # sales at the open of d
            if isinstance(key, tuple):
                if np.isnan(idx['open'][d]):
                    continue
                gross = held.pop(key) * idx['open'][d] / idx['pre'][d]
                cost = max(minimum, ra.RATE * gross)
            else:
                g = ra.gap(key, d)
                if g is None or g <= -(h['limit'][key] - 0.2):
                    stats['late_sale_days'] += 1
                    continue
                gross = held.pop(key) * h['open'][key, d] / h['pre'][key, d]
                cost = ra.fee(gross, minimum, True)
            cash += gross - cost
            stats['fees'] += cost
            pending.discard(key)
            freed = not switch
        bought_today = set()
        if not stopped and (switch or freed):
            wanted = [('idx', k) for k in range(1, star_places + 1)] + stock_list
            for key in wanted:                                      # buys at the open of d
                if len(held) >= 3:
                    break
                if key in held:
                    continue
                budget = cash / (3 - len(held))
                if isinstance(key, tuple):
                    price = idx['open'][d] / 1000
                    if np.isnan(price):
                        continue
                    units = np.floor(budget / (price * 100)) * 100
                    while units > 0 and units * price + max(minimum, ra.RATE * units * price) > budget:
                        units -= 100
                    if units <= 0:
                        continue
                    amount = units * price
                    cost = max(minimum, ra.RATE * amount)
                    held[key] = units * idx['close'][d] / 1000
                else:
                    g = ra.gap(key, d)
                    if g is None or g >= h['limit'][key] - 0.2:
                        stats['skips'] += 1
                        continue
                    price = h['open'][key, d]
                    shares = np.floor(budget / (price * 100)) * 100
                    while shares > 0 and shares * price + ra.fee(shares * price, minimum, False) > budget:
                        shares -= 100
                    if shares <= 0:
                        stats['skips'] += 1
                        continue
                    amount = shares * price
                    cost = ra.fee(amount, minimum, False)
                    held[key] = shares * h['close'][key, d]
                cash -= amount + cost
                stats['fees'] += cost
                bought_today.add(key)
        for key in held:                                            # value at the close of d
            if key in bought_today:
                continue
            c, p = (idx['close'][d], idx['pre'][d]) if isinstance(key, tuple) else (h['close'][key, d], h['pre'][key, d])
            if not (np.isnan(c) or np.isnan(p)):
                held[key] *= c / p
        equity = cash + sum(held.values())
        nav.append(equity / start_cash)
        index_share.append(sum(v for k, v in held.items() if isinstance(k, tuple)) / equity)
        if floor and not stopped and nav[-1] < floor:
            stopped = True
            stats['stopped_on'] = days[d]
            pending |= set(held)
    nav = np.array(nav)
    span = days[start:]
    d = ra.profile(nav, span, sorted(decisions), start)
    ref = ra.profile(ra.chinext_window(start), span, sorted(decisions), start)
    return {'start': span[0], 'cagr_pct': round(d['cagr_pct'], 2), 'max_drawdown_pct': round(d['max_drawdown_pct'], 2),
            'lowest_nav': round(d['lowest_nav'], 3), 'final_nav': round(float(nav[-1]), 3), 'big_loss': d['big_loss'],
            'worst_period_pct': round(d['worst_period_pct'], 2), 'chinext_cagr_pct': round(ref['cagr_pct'], 2),
            'chinext_max_drawdown_pct': round(ref['max_drawdown_pct'], 2),
            'beats_chinext': bool(d['cagr_pct'] > ref['cagr_pct'] and d['max_drawdown_pct'] > ref['max_drawdown_pct']),
            'fees_pct_of_start': round(stats['fees'] / start_cash * 100, 2), 'index_share_pct': round(float(np.mean(index_share)) * 100, 1),
            'star_places_per_switch': round(stats['star_places'] / max(stats['switches'], 1), 2), 'stopped_on': stats.get('stopped_on')}


def index_hold(code, first, offset):
    """Holding the index itself from the first decision day's close, for reference."""
    s = series(code)
    start = first + offset
    nav = s['close'][start:] / s['close'][start]
    d = ra.sd.describe(nav, days[start:], np.array([nav[-1] - 1]))
    return {'cagr_pct': round(d['cagr_pct'], 2), 'max_drawdown_pct': round(d['max_drawdown_pct'], 2)}


def main():
    result = {'runs': {}, 'hold': {}, 'star_industries': {}, 'etfs': {}}
    for window, label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        first = days.index(label)
        for offset in (0, 5, 10, 15):
            b, _ = ra.summary('1万普通', 'no_star', first=first, offset=offset)
            b07, _ = ra.summary('1万普通', 'no_star', first=first, offset=offset, floor=0.7)
            row = {'B': {k: b[k] for k in ('cagr_pct', 'max_drawdown_pct', 'lowest_nav', 'final_nav', 'big_loss', 'beats_chinext',
                                           'fees_pct_of_start', 'chinext_cagr_pct', 'chinext_max_drawdown_pct')} | {'stopped_on': b07['stopped_on']}}
            for variant in ('C50', 'C200'):
                row[variant] = simulate(variant, first, offset)
                row[variant]['stopped_on'] = simulate(variant, first, offset, floor=0.7)['stopped_on']
            result['runs'][f'{window}|{offset}'] = row
            result['hold'][f'{window}|{offset}'] = {code: index_hold(code, first, offset) for code in ('000688.SH', '000699.SH')}
            print(window, offset, {k: (v['cagr_pct'], v['max_drawdown_pct'], v['lowest_nav'], v['beats_chinext'], v.get('index_share_pct'), v['stopped_on'])
                                   for k, v in row.items()}, result['hold'][f'{window}|{offset}'], flush=True)
    counts = Counter()
    first = days.index('2024-07-01')
    for offset in (0, 5, 10, 15):
        for t in range(first + offset, n - 1, 20):
            for i in ra.ranked(t)[:3]:
                if codes[i].startswith(STAR):
                    counts[str(ra.ir.industry[i] or '未知')] += 1
    result['star_industries'] = dict(counts.most_common())
    listed = [e for e in star['etfs'] if str(e.get('status')) == 'L']
    result['etfs'] = {'count': len(listed), 'retrieved_at': star['retrieved_at']}
    (HERE / 'star_substitute.json').write_text(json.dumps(result, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written star_substitute.json')


if __name__ == '__main__':
    main()
