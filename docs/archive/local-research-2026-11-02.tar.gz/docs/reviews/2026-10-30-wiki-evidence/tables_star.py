"""Prints the round-seven table (skip STAR names, or a STAR index fund in their place) from star_substitute.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'star_substitute.json').read_text(encoding='utf-8'))
WINDOW = {'from_2024-07': '2024-07-01起', 'from_2024-01-31': '2024-01-31起（含2024年2月小盘大跌）'}
LABEL = {'B': '跳过科创板股票，往下取（现行）', 'C50': '科创板股票的名额换成科创50基金', 'C200': '科创板股票的名额换成科创200基金'}


def pct(v):
    return f"{v:+.1f}%"


def spread(values):
    values = sorted(values)
    mid = (values[1] + values[2]) / 2
    return f"{pct(mid)}（{pct(values[0])}至{pct(values[-1])}）"


print('表26 账户买不了科创板：跳过，还是用科创板指数基金顶替（1万元，每笔最低5元，四个起步日）\n')
print('| 起点 | 做法 | 年化中位（最低至最高） | 最大回撤（最好至最差） | 净值最低（最差） | 跑赢创业板指 | 钱在指数基金上的平均比例 | 碰到0.7 |')
print('|---|---|---|---|---|---|---|---|')
for window, wlabel in WINDOW.items():
    runs = [r['runs'][f'{window}|{o}'] for o in (0, 5, 10, 15)]
    for key in ('B', 'C50', 'C200'):
        xs = [x[key] for x in runs]
        dd = sorted(x['max_drawdown_pct'] for x in xs)
        share = '0' if key == 'B' else f"{min(x['index_share_pct'] for x in xs):.0f}%至{max(x['index_share_pct'] for x in xs):.0f}%"
        print(f"| {wlabel} | {LABEL[key]} | {spread([x['cagr_pct'] for x in xs])} | {pct(dd[-1])}至{pct(dd[0])} | "
              f"{min(x['lowest_nav'] for x in xs):.2f} | {sum(x['beats_chinext'] for x in xs)}/4 | {share} | {sum(bool(x['stopped_on']) for x in xs)}/4 |")
    for code, name in (('000688.SH', '科创50'), ('000699.SH', '科创200')):
        hold = [r['hold'][f'{window}|{o}'][code] for o in (0, 5, 10, 15)]
        dd = sorted(x['max_drawdown_pct'] for x in hold)
        print(f"| {wlabel} | 对照：一直持有{name} | {spread([x['cagr_pct'] for x in hold])} | {pct(dd[-1])}至{pct(dd[0])} | — | — | 100% | — |")
total = sum(r['star_industries'].values())
print(f"\n2024-07-01起四个起步日的换手日里，全部板块排名前3的名额中有{total}个是科创板股票，按行业："
      + '、'.join(f'{k}{v}个' for k, v in r['star_industries'].items()) + '。')
