"""事后补测: the report publishes the new list after the decision day's close, so in practice the old names are sold at
the next open, together with buying the new ones; the backtest sells at the decision day's close.

For the plan rule and the whole basket (every 20 sessions, start offsets 0, 5, 10, 15, both windows), recompute each
period with the sale moved to the next open (the overnight move of the names being sold is added; the last period
still ends at the last close), and report the compound return per year both ways. Nothing here changes a rule.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import small_cap_design as sd  # noqa: E402

h, n = sd.h, sd.n


def periods(rule, first, offset):
    rng = np.random.default_rng(0)
    decisions = sd.decision_days(20, first + offset)
    closing, opening = [], []
    for k, t in enumerate(decisions):
        end = decisions[k + 1] if k + 1 < len(decisions) else n - 1
        members = sd.choose(rule, t, rng)
        if not members:
            r = (1 + sd.CASH) ** (end - t) - 1
            closing.append(r)
            opening.append(r)
            continue
        value = np.array([h['close'][i, t + 1] / h['open'][i, t + 1] * np.prod(1 + sd.growth[i, t + 2:end + 1]) for i in members])
        gap = np.ones(len(members))
        if end + 1 < n:
            for j, i in enumerate(members):
                o, c = h['open'][i, end + 1], h['close'][i, end]
                if not (np.isnan(o) or np.isnan(c)) and c > 0:
                    gap[j] = o / c
        closing.append((1 - sd.COST) * value.mean() - 1)
        opening.append((1 - sd.COST) * (value * gap).mean() - 1)
    years = (n - 1 - decisions[0]) / 252
    yearly = lambda p: (np.prod(1 + np.array(p)) ** (1 / years) - 1) * 100
    return yearly(closing), yearly(opening), float(np.mean(np.array(opening) - np.array(closing)) * 100)


def main():
    out = {}
    for window, first_label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        first = sd.days.index(first_label)
        out[window] = {}
        for label, rule in (('整篮子', 'all'), ('3只业绩为正里最冷门', 'growth:3')):
            rows = []
            for offset in (0, 5, 10, 15):
                at_close, at_open, gap = periods(rule, first, offset)
                rows.append({'offset': offset, 'sell_at_close_pct': round(at_close, 1), 'sell_next_open_pct': round(at_open, 1),
                             'mean_overnight_pp': round(gap, 2)})
            out[window][label] = rows
            print(window, label, [(r['sell_at_close_pct'], r['sell_next_open_pct'], r['mean_overnight_pp']) for r in rows], flush=True)
    (HERE / 'execution_timing.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written execution_timing.json')


if __name__ == '__main__':
    main()
