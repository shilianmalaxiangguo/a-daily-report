"""Prints the evidence tables used in wiki/交易思想/回测与检验证据.md from the frozen backtest and the JSON results here."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'scripts/report/strategy_backtest.py').is_file())
bt = json.loads((ROOT / 'snapshots/replay/2026-10-29_replay.json').read_text(encoding='utf-8'))['data']['reading_backtest']
ev = json.loads((HERE / 'wiki_evidence.json').read_text(encoding='utf-8'))
ic = json.loads((HERE / 'ic_by_year.json').read_text(encoding='utf-8'))
null = json.loads((HERE / 'random_null.json').read_text(encoding='utf-8'))
dec = json.loads((HERE / 'random_decompose.json').read_text(encoding='utf-8'))
eqw = json.loads((HERE / 'equal_weight.json').read_text(encoding='utf-8'))


def pct(v, digits=1, sign=True):
    return '—' if v is None else f"{v:+.{digits}f}%" if sign else f"{v:.{digits}f}%"


def tval(v):
    return '—' if v is None else f"t {v:.1f}"


def cell(v):
    return f"{v['mean_pct']:+.2f}（{tval(v['nw_t'])}）"


print('表1\n')
print('| 做法 | 年化 | 最大回撤 | 夏普 | 平均在场资金 | 2024（3月起） | 2025 | 2026（至10-29） |')
print('|---|---|---|---|---|---|---|---|')
names = {'live_rule': '当前规则：进攻期买高贝塔，其余只在阿尔法近期有优势时买', 'alpha': '检查全过的阿尔法，每天买',
         'alpha_regime': '检查全过的阿尔法，防守期不买', 'beta': '高贝塔篮子，每天买', 'beta_offense': '高贝塔篮子，只在进攻期买',
         'stance': '简化轮换：进攻买贝塔、均衡买阿尔法、防守不买', 'index': '对照：持有中证全指'}
for k in ('live_rule', 'alpha', 'alpha_regime', 'beta', 'beta_offense', 'stance', 'index'):
    f, y = bt['stats'][k]['full'], bt['stats'][k]['years']
    print(f"| {names[k]} | {pct(f['cagr_pct'])} | {pct(f['max_drawdown_pct'])} | {f['sharpe']:.2f} | "
          f"{pct(f.get('exposure_pct', 100.0), 0, False)} | {pct(y['2024'])} | {pct(y['2025'])} | {pct(y['2026'])} |")
for k, label in (('random', '对照：同规则同成本，每天随机挑10只（20次的中位数）'), ('random_offense', '对照：同上，只在进攻期买（20次的中位数）')):
    v = null[k]
    print(f"| {label} | {pct(v['cagr_pct']['median'])} | {pct(v['max_drawdown_pct']['median'])} | {v['sharpe']['median']:.2f} | "
          f"{pct(v['exposure_pct']['median'], 0, False)} | — | — | — |")
e, ey = null['equal_weight_daily'], eqw['equal_weight']['years']
print(f"| 对照：等权平均持有全部可交易A股（每日再平衡、不计成本，理论参照） | {pct(e['cagr_pct'])} | {pct(e['max_drawdown_pct'])} | "
      f"{e['sharpe']:.2f} | 100% | {pct(ey['2024'])} | {pct(ey['2025'])} | {pct(ey['2026'])} |")
print(f"\n随机对照20次的年化范围：每天买 {pct(null['random']['cagr_pct']['min'])} 至 {pct(null['random']['cagr_pct']['max'])}，"
      f"只在进攻期买 {pct(null['random_offense']['cagr_pct']['min'])} 至 {pct(null['random_offense']['cagr_pct']['max'])}。")
for name, key in (('random', 'beta'), ('random', 'alpha'), ('random_offense', 'beta_offense')):
    target = null['frozen'][key]['cagr_pct']
    print(f"{name} 中年化不低于 {key}（{pct(target)}）的次数：{sum(r['cagr_pct'] >= target for r in null[name]['runs'])}/20")
oos = {k: bt['stats'][k]['out_of_sample']['cagr_pct'] for k in ('live_rule', 'alpha', 'beta_offense', 'index')}
des = {k: bt['stats'][k]['design_period']['total_pct'] for k in ('live_rule', 'alpha', 'beta_offense', 'index')}
print('样本外年化（2024-03-04至2026-07-27）：' + '、'.join(f"{k} {pct(v)}" for k, v in oos.items()))
print('设计期累计（2026-07-28至10-29）：' + '、'.join(f"{k} {pct(v)}" for k, v in des.items()))

print('\n表2\n')
print('| 信号 | 全期平均 | t（按5日重叠调整） | 为正的交易日 | 2024 | 2025 | 2026 |')
print('|---|---|---|---|---|---|---|')
for k, label in (('own', '近20日独立收益'), ('t_alpha', '近20日独立收益的显著程度'), ('own5', '近5日独立收益')):
    a = ic[f'{k}|all']
    cells = [f"{ic[f'{k}|{y}']['mean_ic']:+.3f}（{tval(ic[f'{k}|{y}']['t_overlap_adjusted'])}）" for y in ('2024', '2025', '2026')]
    print(f"| {label} | {a['mean_ic']:+.3f} | {a['t_overlap_adjusted']:.1f} | {a['positive_share'] * 100:.0f}% | " + ' | '.join(cells) + ' |')
b = bt['ic']['beta']
print(f"| 贝塔大小 | {b['mean_ic']:+.3f} | {b['t_stat']:.1f} | {b['positive_share'] * 100:.0f}% | — | — | — |")
print(f"\n近20日独立收益最高五分之一减最低五分之一，之后5日平均 {bt['ic']['own']['top_minus_bottom_pct']:+.2f} 个百分点。")

g = ev['gap']
print('\n表3\n')
print('| 开盘情况 | 次数 | 拿到当天收盘 | 拿到次日收盘 | 拿到第5个交易日收盘 | 第5日中位数 | 第5日仍高于开盘价 |')
print('|---|---|---|---|---|---|---|')
for label in ('低开超过2%', '高开0至2%', '高开2%至3%', '高开3%至5%', '高开5%以上未到涨停', '开盘涨停'):
    h0, h1, h4 = (g[f'{h}|{label}|全部|全部'] for h in ('h0', 'h1', 'h4'))
    first = '当天不可能更高' if label == '开盘涨停' else cell(h0['abs'])
    second = cell(h1['abs']) + (f"，中位 {h1['median_pct']:+.2f}" if label == '开盘涨停' else '')
    print(f"| {label} | {h0['events']:,} | {first} | {second} | {cell(h4['abs'])} | {h4['median_pct']:+.2f} | {h4['up_share'] * 100:.0f}% |")
print('\n| 情形 | 次数 | 拿到当天收盘 | 拿到次日收盘 | 拿到第5个交易日收盘 | 第5日中位数 | 第5日仍高于开盘价 |')
print('|---|---|---|---|---|---|---|')
for label in ('高开5%以上未到涨停', '开盘涨停'):
    for split in ('前5日已涨10%以上', '前5日涨幅不到10%'):
        h0, h1, h4 = (g[f'{h}|{label}|{split}|全部'] for h in ('h0', 'h1', 'h4'))
        first = '当天不可能更高' if label == '开盘涨停' else cell(h0['abs'])
        print(f"| {label}，{split} | {h0['events']:,} | {first} | {cell(h1['abs'])}，中位 {h1['median_pct']:+.2f}，"
              f"{h1['up_share'] * 100:.0f}%更高 | {cell(h4['abs'])} | {h4['median_pct']:+.2f} | {h4['up_share'] * 100:.0f}% |")
for h, title in (('h0', '分年份（拿到当天收盘）'), ('h4', '分年份（拿到第5个交易日收盘）')):
    print(title + '：' + '；'.join(
        f"{label} " + '、'.join(f"{y} {g[f'{h}|{label}|全部|{y}']['abs']['mean_pct']:+.2f}" for y in ('2024', '2025', '2026'))
        for label in ('高开2%至3%', '高开3%至5%', '高开5%以上未到涨停', '开盘涨停')))
x = g['h0|高开5%以上未到涨停|全部|全部']['excess']
print(f"高开5%以上未到涨停，拿到当天收盘相对中证全指同段：{cell(x)}")

print('\n表4\n')
print('| 条件 | 年化 |')
print('|---|---|')
for k, label in (('原样', '按回测规则：扣成本、设失效价'), ('不计成本', '不计成本'), ('不计成本且不设失效价', '不计成本，也不设失效价')):
    print(f"| {label} | {pct(dec[k]['median_cagr_pct'])} |")
print(f"| 对照：等权平均持有全部可交易A股 | {pct(null['equal_weight_daily']['cagr_pct'])} |")

ed = ev['edge']
print('\n表5\n')
print('| 决策日 | 天数（阿尔法/贝塔） | 阿尔法篮子 | 阿尔法相对中证全指 | 高贝塔篮子 | 高贝塔相对中证全指 | 中证全指 |')
print('|---|---|---|---|---|---|---|')
for name in ('近期有优势', '近期无优势', '进攻', '均衡', '防守', '全部'):
    a, b = ed[f'alpha|{name}'], ed[f'beta|{name}']
    print(f"| {name} | {a['abs']['dates']}/{b['abs']['dates']} | {a['abs']['mean_pct']:+.2f}% | {cell(a['excess'])} | "
          f"{b['abs']['mean_pct']:+.2f}% | {cell(b['excess'])} | {cell(b['index'])} |")
t = ed['alpha_trades']
print('\n逐笔核对（阿尔法每天买的实际成交）：' + '；'.join(
    f"{k} {v['trades']}笔，平均 {v['mean_pct']:+.2f}%，中位 {v['median_pct']:+.2f}%，赚钱 {v['win_share'] * 100:.0f}%" for k, v in t.items()))

years = (bt['sessions'] - 1) / 252
print('\n夏普比率的一倍标准误（Lo 2002 近似，sqrt((1 + 夏普²/2) / 年数)，年数 = %.2f）：' % years + '、'.join(
    f"{k} {((1 + bt['stats'][k]['full']['sharpe'] ** 2 / 2) / years) ** 0.5:.2f}" for k in ('live_rule', 'alpha', 'beta', 'beta_offense', 'index')))
