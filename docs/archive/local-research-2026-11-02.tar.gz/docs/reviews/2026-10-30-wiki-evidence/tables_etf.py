"""Prints the round-eight STAR ETF tables from star_etf_compare.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'star_etf_compare.json').read_text(encoding='utf-8'))


def pct(v):
    return '—' if v is None else f"{v:+.1f}%"


def spread(values):
    values = sorted(values)
    return f"{pct((values[1] + values[2]) / 2)}（{pct(values[0])}至{pct(values[-1])}）"


print(f"表27 科创板ETF：规模、费用与涨跌（基金价格；{r['window_start']}至2026-10-30）\n")
print('| 代码 | 名称 | 跟踪 | 上市 | 年费（管理＋托管） | 规模（亿元） | 近60日日均成交（亿元） | 区间涨跌 | 最大回撤 | 2026年3至6月 | 2026年7至10月 |')
print('|---|---|---|---|---|---|---|---|---|---|---|')
for code, f in r['facts'].items():
    w = f['since_window'] or {}
    note = '（2025-08-01上市起）' if code == '589720.SH' else ''
    print(f"| {code[:6]} | {f['name']} | {f['theme']} | {f['list_date']} | {f['fee_pct']:.1f}% | {f['size_yi']:,.1f} | {f['turnover_yi']:.2f} | "
          f"{pct(w.get('total_pct'))}{note} | {pct(w.get('max_drawdown_pct'))} | {pct((f['rise_2026'] or {}).get('total_pct'))} | {pct((f['fall_2026'] or {}).get('total_pct'))} |")
s = r['stand_in']
print(f"\n表28 名单里的科创板股票用哪只ETF顶替（1万元，每笔最低5元；第一个换手日{r['first_decision']}，四个起步日；股票数据到2026-10-29）\n")
print('| 做法 | 年化中位（最低至最高） | 最大回撤（最好至最差） | 净值最低（最差） | 跑赢创业板指 | 钱在ETF上的平均比例 |')
print('|---|---|---|---|---|---|')
skip = s['skip']
dd = sorted(x['max_drawdown_pct'] for x in skip)
print(f"| 跳过科创板股票（现行） | {spread([x['cagr_pct'] for x in skip])} | {pct(dd[-1])}至{pct(dd[0])} | {min(x['lowest_nav'] for x in skip):.2f} | "
      f"{sum(x['beats_chinext'] for x in skip)}/4 | 0 |")
ranked = sorted(((code, runs) for code, runs in s.items() if code != 'skip'), key=lambda kv: -sorted(x['cagr_pct'] for x in kv[1])[1])
for code, runs in ranked:
    dd = sorted(x['max_drawdown_pct'] for x in runs)
    print(f"| 用{code[:6]} {r['facts'][code]['name']}顶替 | {spread([x['cagr_pct'] for x in runs])} | {pct(dd[-1])}至{pct(dd[0])} | "
          f"{min(x['lowest_nav'] for x in runs):.2f} | {sum(x['beats_chinext'] for x in runs)}/4 | "
          f"{min(x['index_share_pct'] for x in runs):.0f}%至{max(x['index_share_pct'] for x in runs):.0f}% |")
c = skip[0]
print(f"\n同一窗口，创业板指（起点{c['start']}）年化{pct(c['chinext_cagr_pct'])}、最大回撤{pct(c['chinext_max_drawdown_pct'])}。")
