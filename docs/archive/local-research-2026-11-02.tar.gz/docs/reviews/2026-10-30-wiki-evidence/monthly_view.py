"""Monthly and yearly returns of the plan for the user's account, and how often a month reached +10%
(declared before running, 2026-10-31, round thirteen).

The account of account_names.py (10,000 yuan, commission 0.01% with no minimum, main board and ChiNext, five names,
whole lots, names on the new list kept), start offsets 0, 5, 10, 15 sessions from 2024-07-01 and from 2024-01-31.
Calendar months: net value at the last session of a month over the last session of the month before (the first
month starts at the first decision day). Reported per run: annual return; geometric and arithmetic mean month;
median month; share of months up; best and worst month; months at or above +10%; months at or below -10%;
the best and worst stretch of 12 months in a row. ChiNext and CSI 2000 over the same months for comparison.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import account_names as an  # noqa: E402

ra, days, n = an.ra, an.days, an.n
c2000 = an.ra.sd.c2000
chinext = an.ra.sd.chinext


def nav_path(first, offset):
    """Re-run the five-name account and keep its daily net value (same engine as account_names.simulate)."""
    captured = {}
    original = ra.profile

    def keep(nav, span, decisions, start):
        if 'nav' not in captured:                 # the account first; the second call is ChiNext's reference
            captured['nav'], captured['span'] = nav, span
        return original(nav, span, decisions, start)
    ra.profile = keep
    try:
        result = an.simulate(5, first, offset)
    finally:
        ra.profile = original
    return captured['nav'], captured['span'], result


def months(nav, span):
    ends = [k for k in range(len(span)) if k == len(span) - 1 or span[k][:7] != span[k + 1][:7]]
    marks = [0] + ends
    values = np.array([nav[k] for k in marks])
    return values[1:] / values[:-1] - 1, [span[k][:7] for k in ends]


def describe(monthly, cagr):
    m = np.array(monthly)
    roll = [float(np.prod(1 + m[i:i + 12]) - 1) for i in range(len(m) - 11)]
    return {'annual_pct': round(cagr, 2), 'months': int(len(m)),
            'geo_month_pct': round(float(np.prod(1 + m) ** (1 / len(m)) - 1) * 100, 2),
            'mean_month_pct': round(float(m.mean()) * 100, 2), 'median_month_pct': round(float(np.median(m)) * 100, 2),
            'up_share': round(float((m > 0).mean()), 3), 'best_month_pct': round(float(m.max()) * 100, 2),
            'worst_month_pct': round(float(m.min()) * 100, 2), 'months_10_up': int((m >= 0.10).sum()),
            'months_10_down': int((m <= -0.10).sum()),
            'best_12m_pct': round(max(roll) * 100, 1) if roll else None, 'worst_12m_pct': round(min(roll) * 100, 1) if roll else None}


def main():
    out = {}
    for window, label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        first = days.index(label)
        runs = []
        for offset in (0, 5, 10, 15):
            nav, span, result = nav_path(first, offset)
            monthly, labels = months(nav, span)
            runs.append({'offset': offset, 'start': span[0], **describe(monthly, result['cagr_pct']),
                         'monthly': [round(float(x) * 100, 2) for x in monthly], 'labels': labels})
        start = first
        refs = {}
        for name, series in (('chinext', chinext), ('csi2000', c2000)):
            nav = series[start:] / series[start]
            monthly, _ = months(nav, days[start:])
            years = (len(nav) - 1) / 252
            refs[name] = describe(monthly, (nav[-1] ** (1 / years) - 1) * 100)
        out[window] = {'runs': runs, 'refs': refs}
        for r in runs:
            print(window, r['offset'], {k: r[k] for k in ('annual_pct', 'geo_month_pct', 'mean_month_pct', 'median_month_pct', 'up_share',
                                                         'best_month_pct', 'worst_month_pct', 'months_10_up', 'months_10_down',
                                                         'best_12m_pct', 'worst_12m_pct', 'months')}, flush=True)
        print(window, 'refs', refs, flush=True)
    (HERE / 'monthly_view.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written monthly_view.json')


if __name__ == '__main__':
    main()
