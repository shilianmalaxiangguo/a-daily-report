"""Prints the round-fifteen tables (the B1 buy point of 少妇战法1.0) from b1_point.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'b1_point.json').read_text(encoding='utf-8'))
REASON = {'stop': '跌破止损', 'time': '3天没涨开', 'fall back': '涨了又跌回成本', 'BBI': '两天收在BBI下', 'end': '到最后一天还拿着'}
TRADES = {'B1|short3|open': 'B1，短线卖法（3天），次日开盘买', 'B1|short5|open': 'B1，短线卖法（5天）', 'B1|medium|open': 'B1，中线卖法（不设时间止损）',
          'shrink|short3|open': '缩量B1（成交额不到近20日最大的一半），短线卖法', 'B1|short3|close': 'B1，短线卖法，当天收盘买（文章的买法）'}
ACCOUNT = {'B1|short3|5': 'B1，短线卖法，最多5只，最缩量的先买', 'B1|short5|5': 'B1，短线卖法（5天）', 'B1|medium|5': 'B1，中线卖法',
           'shrink|short3|5': '缩量B1，短线卖法', 'B1|short3|3': 'B1，短线卖法，最多3只', 'B1|short3|5|slip0.1%': 'B1，短线卖法，每笔滑点0.1%'}
pct = lambda v: '—' if v is None else f'{v:+.1f}%'
pct2 = lambda v: '—' if v is None else f'{v:+.2f}%'


print('表36 公式核对：文章图上印的数值，与按公式算出的数值\n')
print('| 图 | 日期 | 图上 K / D / J | 算出 K / D / J | 图上 白线 / 黄线 | 算出 白线 / 黄线 |')
print('|---|---|---|---|---|---|')
for name, x in r['charts'].items():
    print(f"| {name} | {x['date']} | {' / '.join(map(str, x['printed_kdj']))} | {' / '.join(map(str, x['kdj']))} | "
          f"{' / '.join(map(str, x['printed_white_yellow']))} | {' / '.join(map(str, x['white_yellow']))} |")

print('\n表37 文章的11个例子：是不是 B1，按短线卖法的结果（次日开盘买；括号里是当天收盘买）\n')
print('| 股票 | 日期 | 白线在黄线上 | J | 涨跌幅 | 振幅 | 符合 B1 | 结果 | 怎么卖的 |')
print('|---|---|---|---|---|---|---|---|---|')
for x in r['examples']:
    o, c = x['open'], x['close']
    result = (f"{pct(o['ret_pct'])}（{pct(c['ret_pct'])}）" if o else f"次日开盘在止损价下，不买（{pct(c['ret_pct'])}）")
    how = REASON[(o or c)['reason']] + f"，{(o or c)['end']}卖"
    print(f"| {x['name']} | {x['date']} | {'是' if x['white_over_yellow'] else '否'} | {x['j']} | {x['change_pct']:+.2f}% | {x['amplitude_pct']:.2f}% | "
          f"{'是' if x['meets_b1'] else '否'} | {result} | {how} |")

s = r['signals_per_day']['b1']
print(f"\n每天符合 B1 的股票：平均{s['mean']}只，中位{s['median']:.0f}只（主板和创业板，{s['days']}个交易日里{s['zero_days']}天没有）。\n")
print('表38 每个 B1 当作一笔交易（2024-07起，不受账户限制；每笔来回0.2%；同一只股票拿着时不重复买）\n')
print('| 做法 | 笔数 | 平均每笔 | 中位 | 赚钱的笔数 | 平均赚 | 平均亏 | 亏超10% | 赚超10% | 平均拿几天 | 同一天随手买（同样卖法） | 同一天随手买白线在黄线上的 | 比随手买多（t） |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|---|')
for key, label in TRADES.items():
    x = r['trades'][key]
    b, a, t = x['b1'], x['null_any'], x['null_trend']
    print(f"| {label} | {b['trades']} | {pct2(b['mean_pct'])} | {pct2(b['median_pct'])} | {b['win_share']:.0%} | {pct(b['mean_win_pct'])} | {pct(b['mean_loss_pct'])} | "
          f"{b['loss_over_10_share']:.1%} | {b['gain_over_10_share']:.1%} | {b['held_mean']} | {pct2(a['mean_pct'])} | {pct2(t['mean_pct'])} | "
          f"{x['minus_any']['mean_pp']:+.2f}个百分点（{x['minus_any']['nw_t']}） |")
x = r['trades']['B1|short3|open']
print('\n短线卖法（3天）的卖出原因：' + '；'.join(f"{REASON[k]}{v}笔（{v / x['b1']['trades']:.0%}）" for k, v in x['b1']['reasons'].items())
      + f"；其中{x['half_share']:.1%}的笔数在上涨中卖过一半。")
print('分年度（平均每笔，括号里是同一天随手买）：' + '；'.join(f"{y}年{pct2(x[y]['mean_pct'])}（{pct2(x[y]['null_any_pct'])}），赚钱的{x[y]['win_share']:.0%}"
                                     for y in ('2024', '2025', '2026')))

for window, title in (('from_2024-07', '2024-07-01起'), ('from_2025-04-28', '2025-04-28起（近18个月）')):
    block = r['account'][window]
    ref = block['refs']
    print(f'\n表{39 if window == "from_2024-07" else 40} 用户的账户（1万元，万一免五，主板和创业板）：{title}\n')
    print('| 做法 | 年化 | 最大回撤 | 最低净值 | 跌破0.7 | 跑赢创业板指 | 每20天算一期：大亏（超过-10%）期数 | 笔数 | 赚钱的笔数 | 平均赚 / 平均亏 | 费用占本金 | 平均持股占比 |')
    print('|---|---|---|---|---|---|---|---|---|---|---|---|')
    for key, label in ACCOUNT.items():
        x = block['runs'][key]
        print(f"| {label} | {pct(x['cagr_pct'])} | {pct(x['max_drawdown_pct'])} | {x['lowest_nav']:.2f} | {x['below_0.7_on'] or '没有'} | "
              f"{'是' if x['beats_chinext'] else '否'} | {x['periods']['big_loss']}/{x['periods']['periods']} | {x['trades']} | {x['win_share']:.0%} | "
              f"{pct(x['mean_win_pct'])} / {pct(x['mean_loss_pct'])} | {x['fees_pct_of_start']:.1f}% | {x['invested_pct']:.0f}% |")
    for key, label in (('B1 random order', 'B1，同一天的 B1 随机挑（20次）'), ('null any', '同一天随手买，同样卖法（20次）'),
                       ('null trend', '同一天随手买白线在黄线上的，同样卖法（20次）')):
        x = block['runs'][key]['spread']
        print(f"| {label} | 中位{pct(x['median'])}（{pct(x['low'])}至{pct(x['high'])}） | 中位{pct(x['mdd_median'])} | {x['lowest_nav']:.2f} | — | "
              f"{x['beats_chinext']}/20 | — | — | 中位{x['win_share_median']:.0%} | — | — | — |")
    plan = ref['plan_5']
    print(f"| 执行计划：小盘轮换5只（对照） | {pct(plan['cagr_pct'])} | {pct(plan['max_drawdown_pct'])} | {plan['lowest_nav']:.2f} | 没有 | "
          f"{'是' if plan['beats_chinext'] else '否'} | — | — | — | — | — | — |")
    for key, label in (('chinext', '一直拿创业板指'), ('csi2000', '一直拿中证2000')):
        x = ref[key]
        print(f"| {label} | {pct(x['cagr_pct'])} | {pct(x['max_drawdown_pct'])} | {x['lowest_nav']:.2f} | — | — | — | — | — | — | — | — |")

o = json.loads((HERE / 'b1_order.json').read_text(encoding='utf-8'))
w = o['windows']
main_a, main_b = r['account']['from_2024-07']['runs']['B1|short3|5'], r['account']['from_2025-04-28']['runs']['B1|short3|5']
print('\n表41 账户的+26%从哪里来（看过表39、表40后补测；用户的账户，短线卖法，最多5只）\n')
print('| 每天按什么顺序买 | 2024-07起年化 | 最大回撤 | 2025-04-28起年化 | 最大回撤 |')
print('|---|---|---|---|---|')
print(f"| B1，最缩量的先买（表39、表40） | {pct(main_a['cagr_pct'])} | {pct(main_a['max_drawdown_pct'])} | {pct(main_b['cagr_pct'])} | {pct(main_b['max_drawdown_pct'])} |")
for key, label in (('B1, least shrunk first', 'B1，最不缩量的先买'), ('all stocks, most shrunk first', '不看 B1，全部股票里最缩量的先买'),
                   ('white > yellow, most shrunk first', '不看 B1，白线在黄线上的里最缩量的先买')):
    a, b = w['from_2024-07'][key], w['from_2025-04-28'][key]
    print(f"| {label} | {pct(a['cagr_pct'])} | {pct(a['max_drawdown_pct'])} | {pct(b['cagr_pct'])} | {pct(b['max_drawdown_pct'])} |")
t = o['top_of_day']
print('\n| 每笔（短线卖法，次日开盘买，来回0.2%） | 笔数 | 平均每笔 | 赚钱的笔数 | 2025-04-28前 | 2025-04-28起 |')
print('|---|---|---|---|---|---|')
for key, label in (('B1 top 5', '每天最缩量的5个 B1'), ('B1 others', '其余 B1'), ('all top 5', '每天全部股票里最缩量的5只')):
    x, p1, p2 = t[f'{key}|all'], t[f'{key}|before_2025-04-28'], t[f'{key}|from_2025-04-28']
    print(f"| {label} | {x['trades']} | {pct2(x['mean_pct'])} | {x['win_share']:.0%} | {pct2(p1['mean_pct'])}（{p1['trades']}笔） | {pct2(p2['mean_pct'])}（{p2['trades']}笔） |")
d = t['top5_minus_others']
print(f"\n同一天比，最缩量的5个 B1 每笔比其余 B1 多{d['mean_pp']:+.2f}个百分点（{d['days']}天，t {d['nw_t']}）；其中{t['spike_share_top5']:.0%}在之前20个交易日里有过异动（涨5%以上的阳线、成交额是之前20日平均的2倍以上）。")
print('全部 B1 按缩量程度分五档，平均每笔依次为' + '、'.join(pct2(x['mean_pct']) for x in o['b1_trades_by_shrink_fifth']) + '（最缩量一档在前）。')
print('换四个起步日，B1 最缩量的先买：' + '、'.join(f"{pct(x['cagr_pct'])}" for x in o['offsets']['B1, most shrunk first'])
      + '；全部股票里最缩量的先买：' + '、'.join(f"{pct(x['cagr_pct'])}" for x in o['offsets']['all stocks, most shrunk first']) + '。')
