"""The small-stock rotation run as a real 10,000-yuan account (declared before running).

Every 20 sessions, after the close of decision day t: rank eligible stocks (not ST, listed >= 120 days) by average
turnover over sessions t-19..t, keep the lowest fifth whose close is at most 20 yuan (so one lot of 100 shares
costs at most 2,000 yuan), draw 5 at random. At the open of t+1 sell everything held, then buy the 5 with
equity / 5 each, in whole lots, skipping any that open at the limit. Hold to the next rebalance.
Fees per trade: commission max(5 yuan, 0.025% of the amount) or, for a no-minimum account, 0.025%; stamp duty
0.05% on sells; transfer fee 0.001%; slippage 0.05% each side. Suspended days count as no change.
20 seeds; starts 2024-09-02 and 2024-01-31. Reported: final value, annualised return, max drawdown, the lowest
value reached, and how many runs ever fell below 8,000 and 7,000 yuan.
"""
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, load  # noqa: E402

PERIOD, START_CASH, NAMES, MAX_PRICE = 20, 10_000.0, 5, 20.0
h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
days, n = h['days'], len(h['days'])
amount = h['amount']
filled = np.where(np.isnan(amount), 0, amount)
cs = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(filled, axis=1)], axis=1)
cnt = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(~np.isnan(amount), axis=1)], axis=1)
avg20 = np.full(amount.shape, np.nan)
avg20[:, 19:] = (cs[:, 20:] - cs[:, :-20]) / np.maximum(cnt[:, 20:] - cnt[:, :-20], 1)
growth = np.where(np.isnan(h['returns']), 0.0, h['returns'] / 100)


def fee(value, side, minimum):
    commission = max(5.0, value * 0.00025) if minimum else value * 0.00025
    return commission + value * (0.0005 if side == 'sell' else 0) + value * 0.00001 + value * 0.0005


def run(first, seed, minimum, start_cash=START_CASH, names=NAMES, max_price=MAX_PRICE, values_out=False):
    rng = np.random.default_rng(seed)
    cash, holdings = start_cash, {}                  # code index -> [shares, last price]
    values = [start_cash]
    decisions = list(range(first, n - 1, PERIOD))
    for k, t in enumerate(decisions):
        d = t + 1                                   # trade at this open
        for i, (shares, last) in list(holdings.items()):
            o, pc = h['open'][i, d], h['pre'][i, d]
            price = last * (o / pc) if not (np.isnan(o) or np.isnan(pc)) else last
            value = shares * price
            cash += value - fee(value, 'sell', minimum)
        holdings = {}
        ok = h['eligible'][:, t] & ~np.isnan(avg20[:, t]) & ~np.isnan(h['close'][:, t])
        q20 = np.quantile(avg20[ok, t], 0.2)
        pool = np.flatnonzero(ok & (avg20[:, t] <= q20) & (h['close'][:, t] <= max_price))
        budget = cash / names
        for i in rng.permutation(pool):
            if len(holdings) == names:
                break
            o, pc = h['open'][i, d], h['pre'][i, d]
            if np.isnan(o) or np.isnan(pc) or (o / pc - 1) * 100 >= h['limit'][i] - 0.2:
                continue
            lots = int(budget // (o * 100))
            if lots < 1:
                continue
            value = lots * 100 * o
            if value + fee(value, 'buy', minimum) > cash:
                continue
            cash -= value + fee(value, 'buy', minimum)
            holdings[i] = [lots * 100, o]
        end = decisions[k + 1] + 1 if k + 1 < len(decisions) else n
        for day in range(d, end):
            for i, position in holdings.items():
                if day == d:
                    c = h['close'][i, day]
                    position[1] = c if not np.isnan(c) else position[1]
                else:
                    position[1] *= 1 + growth[i, day]
            values.append(cash + sum(s * p for s, p in holdings.values()))
    values = np.array(values)
    if values_out:
        return values
    years = (len(values) - 1) / 252
    return {'final': round(float(values[-1]), 0), 'cagr_pct': round(float((values[-1] / start_cash) ** (1 / years) * 100 - 100), 2),
            'max_drawdown_pct': round(float((values / np.maximum.accumulate(values) - 1).min() * 100), 2),
            'lowest': round(float(values.min()), 0)}


def main():
    result = {'inputs_sha256': h['inputs_sha256'], 'start_cash': START_CASH, 'names': NAMES, 'windows': {}}
    for label, first in (('from_2024-09-02', days.index('2024-09-02')), ('from_2024-01-31', 19)):
        block = {}
        for minimum, fee_label in ((True, '佣金最低5元'), (False, '免五')):
            runs = [run(first, seed, minimum) for seed in range(20)]
            block[fee_label] = {'runs': runs, 'negative_runs': sum(r['cagr_pct'] < 0 for r in runs),
                                'below_8000': sum(r['lowest'] < 8000 for r in runs), 'below_7000': sum(r['lowest'] < 7000 for r in runs),
                                **{m: {'median': float(np.median([r[m] for r in runs])), 'min': float(min(r[m] for r in runs)),
                                       'max': float(max(r[m] for r in runs))} for m in ('final', 'cagr_pct', 'max_drawdown_pct', 'lowest')}}
        result['windows'][label] = block
    out = Path(__file__).with_name('small_cap_account.json')
    out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
    for label, block in result['windows'].items():
        for fee_label, b in block.items():
            print(label, fee_label, 'final median', b['final']['median'], 'range', b['final']['min'], b['final']['max'],
                  '| cagr median', round(b['cagr_pct']['median'], 1), '| mdd median', round(b['max_drawdown_pct']['median'], 1),
                  'worst', round(b['max_drawdown_pct']['min'], 1), '| lowest median', b['lowest']['median'], 'min', b['lowest']['min'],
                  '| below 8000:', b['below_8000'], 'below 7000:', b['below_7000'], 'negative:', b['negative_runs'])


if __name__ == '__main__':
    main()
