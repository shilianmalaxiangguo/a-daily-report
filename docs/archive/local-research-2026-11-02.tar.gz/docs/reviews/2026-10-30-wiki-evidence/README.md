# 2026-10-30 Wiki 修订用的补充检验

用户看过日报回测结论后，要求据此修改 Wiki。修改前补做了下面几项检验，口径写在各脚本开头，运行前写定；结果不论支持还是反对都照实写进 `wiki/交易思想/回测与检验证据.md`。

| 脚本 | 检验什么 | 结果文件 |
|---|---|---|
| `wiki_evidence.py` | 高开时开盘卖与继续拿的比较（按开盘情况、之前5日涨幅、年份分组）；近期优势与各阶段之后5日的篮子收益；逐笔核对 | `wiki_evidence.json` |
| `ic_by_year.py` | 近20日独立收益等信号的排序相关，按年份拆开 | `ic_by_year.json` |
| `random_null.py` | 同规则同成本、每天随机挑10只（20次），每天买与只在进攻期买；等权平均持有全部可交易A股 | `random_null.json` |
| `random_decompose.py` | 随机挑选时，成本与失效价各拖累多少 | `random_decompose.json` |
| `equal_weight.py` | 等权平均与中证全指的分年份收益 | `equal_weight.json` |
| `exposure_days.py` | 各做法有持股的交易日比例与平均在场资金 | `exposure_days.json` |
| `tables.py` | 从上述结果和冻结回测直接生成 Wiki 证据页的表格 | 打印到终端 |
| `fetch_indices.py` | 取8个对照指数的日线（第一个参数是项目根目录，后两个是起止日期） | `.generated/backtest-history/indices.json`（不入库） |
| `market_checks.py` | 对照指数（两个起点）、外部材料的行情说法、ST与成交额分组、成交额择时、红利防守 | `market_checks.json` |
| `small_cap_rule.py` | 按能照做的方式检验“炒小”（每20个交易日换、扣成本、五个起点），以及只买10只的随机版本 | `small_cap_rule.json` |
| `tables_market.py` | 从上面两份结果生成对照指数、小盘、红利、成交额与材料核对的表格 | 打印到终端 |
| `style_rotation.py` | 37种风格切换与趋势写法（含“事后看”的国家队资金规则），收盘看信号、次日开盘成交 | `style_rotation.json` |
| `small_cap_account.py` | 一万元真实账户照做小盘轮换（整手、股价上限、最低佣金、印花税） | `small_cap_account.json` |
| `account_mix.py` | 一万元分成趋势与小盘两份的四种分法 | `account_mix.json` |
| `tables_style.py` | 从上面三份结果生成风格切换、国家队资金与一万元账户的表格 | 打印到终端 |
| `fetch_fina.py` | 取2023年中报至2026年三季报的财报指标（带公告日） | `.generated/backtest-history/fina_indicator.json`（不入库） |
| `industry_rotation.py` | 不买指数：18种选行业、选个股、业绩增长的写法，四个起点；另有3种标明的事后补测 | `industry_rotation.json` |
| `mix_small_growth.py` | 小盘轮换配业绩增长（事后看的组合） | `mix_small_growth.json` |
| `tables_industry.py` | 从 `industry_rotation.json` 生成选行业与选个股的表格 | 打印到终端 |
| `small_cap_design.py` | 持股几只、多久一换、亏的是哪种：换手周期、随机挑1至10只、按规则挑3只、两种防大亏开关，两个起点；另有业绩为正的5只、10只（事后补测） | `small_cap_design.json` |
| `outlier_check.py` | 事后补测：去掉最好的一两期后年化还剩多少，创业板指同样处理 | `outlier_check.json` |
| `execution_timing.py` | 事后补测：卖出从换手日收盘挪到下一个交易日开盘 | `execution_timing.json` |
| `tables_design.py` | 从上面三份结果生成证据页表16至表20 | 打印到终端 |
| `real_account.py` | 按1万元、10万元真实账户照做执行计划：整手、最低佣金、印花税、过户费、买不到卖不出、名单里没变的不动；可买板块、起步日、换手间隔、净值底线、每天按名单换 | `real_account.json` |
| `tables_real.py` | 从 `real_account.json` 生成证据页表21至表25 | 打印到终端 |
| `fetch_star.py` | 取科创50、科创100、科创200、科创综指日线与名称含“科创”的上市基金列表（第一个参数是项目根目录，后两个是起止日期） | `.generated/backtest-history/star_indices.json`（不入库） |
| `star_substitute.py` | 账户买不了科创板：跳过科创板股票，还是用科创50、科创200基金顶替 | `star_substitute.json` |
| `tables_star.py` | 从 `star_substitute.json` 生成证据页表26 | 打印到终端 |
| `fetch_star_etfs.py` | 取16只科创板ETF的日线、费率和最新份额（第一个参数是项目根目录，后两个是起止日期） | `.generated/backtest-history/star_etfs.json`（不入库） |
| `star_etf_compare.py` | 科创板ETF的规模、成交、费用、涨跌，以及用真实ETF价格逐只检验顶替 | `star_etf_compare.json` |
| `tables_etf.py` | 从 `star_etf_compare.json` 生成证据页表27、表28 | 打印到终端 |
| `selection_value.py` | 主板和创业板：池里最冷门的3只、随机挑3只、整个股票池、中证2000与创业板指的归因比较 | `selection_value.json` |
| `tables_selection.py` | 从 `selection_value.json` 生成证据页表29 | 打印到终端 |
| `leader_lives.py` | 龙头战法能用日线检验的部分：连板接力、空间龙头、断板后再买，持有1、3、5天 | `leader_lives.json` |
| `tables_leader.py` | 从 `leader_lives.json` 生成证据页表30 | 打印到终端 |
| `names_count.py` | 按用户账户（1万元，主板和创业板，真实下单）比较拿3、5、10只，每笔最低5元与免五 | `names_count.json` |
| `tables_names.py` | 从 `names_count.json` 生成证据页表31 | 打印到终端 |
| `account_names.py` | 用户的账户（1万元、万一免五）真实下单拿3、4、5、6、8、10只 | `account_names.json` |
| `tables_account.py` | 从 `account_names.json` 生成证据页表32 | 打印到终端 |
| `late_entry.py` | 一期中途才开始：用这一期的名单，还是用进场前一天收盘重新排的名单 | `late_entry.json` |
| `monthly_view.py` | 用户账户（5只）按自然月的收益、最好最差月份、连续12个月 | `monthly_view.json` |
| `tables_monthly.py` | 从上面两份结果生成证据页表33、表34 | 打印到终端 |
| `pool_order.py` | 股票池里按捡便宜、有辨识度、不追拉升挑5只，和最冷门、随机比较 | `pool_order.json` |
| `tables_order.py` | 从 `pool_order.json` 生成证据页表35 | 打印到终端 |
| `fetch_high_low.py` | 取每天全部A股的最高价、最低价和成交量（第一个参数是项目根目录，后两个是起止日期），收盘价与已有缓存逐只核对 | `.generated/market-hl/<日期>.json`（不入库） |
| `b1_point.py` | 少妇战法的 B1 买点：用文章配图核对公式、文章的例子、每个 B1 当一笔交易、按用户账户每天挑5只 | `b1_point.json` |
| `b1_order.py` | 看过 `b1_point.py` 的结果后补测：账户的收益来自哪种挑法、每天最缩量的5个 B1 | `b1_order.json` |
| `tables_b1.py` | 从上面两份结果生成证据页表36至表41 | 打印到终端 |
| `sell_rules.py` | 执行计划怎么卖：3种换法和11种持有期间按条件卖，用户账户8条路径加近18个月（用到 `b1_point.py` 算的 BBI） | `sell_rules.json` |
| `sell_checks.py` | 看过 `sell_rules.py` 的结果后补测：止盈和大阳线的门槛、分年度、每笔滑点0.5%、和高开兑现叠加 | `sell_checks.json` |
| `tables_sell.py` | 从上面两份结果生成证据页表42至表46 | 打印到终端 |
| `sell_refill.py` | 止盈10%之后钱留着还是马上补（本期名单、重排名单、行情好才补），止盈卖掉的股票之后的涨跌，最好20%交易日的贡献 | `sell_refill.json` |
| `tables_refill.py` | 从 `sell_refill.json` 生成证据页表47至表49 | 打印到终端 |

国家队资金的近似数据由同目录 `fetch_etf_flows.py` 取得（第一个参数是项目根目录，后两个是起止日期），缓存在 `.generated/backtest-history/etf_flows.json`（不入库）。

运行方式（项目根目录，只用 Python 3.14）：

```bash
.generated/venv-py314/bin/python3.14 docs/reviews/2026-10-30-wiki-evidence/wiki_evidence.py
.generated/venv-py314/bin/python3.14 docs/reviews/2026-10-30-wiki-evidence/tables.py
```

输入是本地缓存 `.generated/market-returns-v2/`（682个交易日的全部沪深A股日线）和 `.generated/backtest-history/`（交易日历、中证全指、基础资料、改名记录），不入库，约480MB。每个脚本先核对输入指纹 `85dcc793dbfda5b84885cd97ece1408adcfc76e92fca2541c5f7c362b750ca07`，与 `snapshots/replay/2026-10-29_replay.json` 里冻结回测的输入不一致就停止。脚本先在 `.generated/wiki-revision-20261030/` 跑过一次，搬到这里重跑后结果文件逐字节相同。

这些检验与冻结回测用同一份数据，不是独立来源的验证；只说明 2024-01 至 2026-10 这段行情。日报回测（`strategy_backtest.v3`）里的对照指数、等权平均和随机挑选，与这里的脚本同法计算，10-29 的数字一致；日报执行计划（`scripts/report/small_cap_rotation.py`）的净值与 `small_cap_design.py` 同一路径逐日相差0。`strategy_backtest.v4`（2026-10-31，执行计划 v0.3）加了止盈10%：不止盈的曲线与 v3 冻结曲线逐日相差0，止盈曲线与按规则文字另写的实现逐日一致（相差小于1e-14）；这两条是等权、每边0.1%成本的理想曲线，按用户账户整手下单的数字以 `sell_rules.py` 为准。
