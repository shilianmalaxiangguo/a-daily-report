"""Prints the round-sixteen tables (how to sell in the plan) from sell_rules.json and sell_checks.json."""
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'sell_rules.json').read_text(encoding='utf-8'))
c = json.loads((HERE / 'sell_checks.json').read_text(encoding='utf-8'))
TIME = {'base': '现行：持有到换手日，不在新名单的换掉', 'T10': '每10个交易日换一次', 'T40': '每40个交易日换一次',
        'REBAL': '换手日全部卖掉，按新名单等额重买'}
CONDITION = {'GAP': '高开兑现（用户的规则），钱留到下个换手日', 'GAP+': '高开兑现，钱马上买名单里的下一只',
             'UP7': '收盘涨7%以上，次日开盘卖', 'SPIKE': '放量收涨（成交额是之前20日平均的3倍以上），次日开盘卖',
             'TP10': '止盈：收盘比买价高10%，次日开盘卖', 'TP20': '止盈：收盘比买价高20%，次日开盘卖', 'SL10': '止损：收盘比买价低10%',
             'SL15': '止损：收盘比买价低15%', 'TRAIL': '从买入后最高收盘回落10%', 'BBI': '少妇战法：站上BBI后连续两天收在BBI下',
             'ST': '持有期间被戴帽，次日开盘卖'}
NAME = {'TP:0.05': '止盈：比买价高5%', 'TP:0.10': '止盈：比买价高10%', 'TP:0.15': '止盈：比买价高15%', 'TP:0.20': '止盈：比买价高20%',
        'TP:0.30': '止盈：比买价高30%', 'UP:5': '收盘涨5%以上，次日开盘卖', 'UP:7': '收盘涨7%以上，次日开盘卖', 'UP:9': '收盘涨9%以上，次日开盘卖',
        'base': '现行', 'GAP': '高开兑现', 'TP10': '止盈：比买价高10%', 'UP7': '收盘涨7%以上，次日开盘卖', 'GAP+TP10': '高开兑现＋止盈10%',
        'ChiNext': '一直拿创业板指'}
pct = lambda v: f'{v:+.1f}%'


def span(values):
    v = sorted(values)
    return f'{pct(float(np.median(v)))}（{pct(v[0])}至{pct(v[-1])}）'


def paths(key):
    return [(p['cagr_pct'], p['max_drawdown_pct']) for p in r[key]['paths']]


def versus(a, b):
    return f"更高{sum(x[0] > y[0] for x, y in zip(a, b))}/8，更深{sum(x[1] < y[1] for x, y in zip(a, b))}/8"


def row(key, label, extra):
    x = r[key]
    a, b = x['paths'][:4], x['paths'][4:]
    dd = [p['max_drawdown_pct'] for p in x['paths']]
    cells = [label, span([p['cagr_pct'] for p in a]), span([p['cagr_pct'] for p in b]), f'{pct(max(dd))}至{pct(min(dd))}',
             f"{min(p['lowest_nav'] for p in x['paths']):.2f}", f"{sum(p['beats_chinext'] for p in x['paths'])}/8",
             '—' if key == 'base' else versus(paths(key), paths('base')),
             f"{pct(x['recent']['cagr_pct'])}／{pct(x['recent']['max_drawdown_pct'])}"]
    return '| ' + ' | '.join(cells + extra(x)) + ' |'


HEAD = ('| 卖法 | 2024-07起年化（四个起步日：中位，最低至最高） | 含2024年2月（2024-01-31起） | 最大回撤（8条路径） | 最低净值 | 跑赢创业板指 | '
        '比现行（8条路径）：年化更高几条，回撤更深几条 | 2025-04-28起：年化／回撤 |')
print('表42 多久一换、换手日怎么卖（用户的账户：1万元，万一免五，主板和创业板，5只）\n')
print(HEAD + ' 费用占本金 | 平均空着的钱 |')
print('|---|---|---|---|---|---|---|---|---|---|')
for key, label in TIME.items():
    print(row(key, label, lambda x: [f"{np.median([p['fees_pct_of_start'] for p in x['paths']]):.1f}%",
                                     f"{np.median([p['idle_pct'] for p in x['paths']]):.0f}%"]))
print('\n表43 持有期间按条件卖（每20个交易日换；按条件卖掉的钱留到下个换手日，另注明的除外；同一期不再买回）\n')
print(HEAD + ' 按条件卖了几次（每条路径平均） | 卖掉的股票，到这一期结束又涨跌（平均） | 平均空着的钱 |')
print('|---|---|---|---|---|---|---|---|---|---|---|')


def condition_extra(x):
    gave = [p['gave_up_mean_pct'] for p in x['paths'] if p['gave_up_mean_pct'] is not None]
    return [f"{np.mean([p['rule_sales'] for p in x['paths']]):.1f}次", pct(float(np.mean(gave))) if gave else '—',
            f"{np.median([p['idle_pct'] for p in x['paths']]):.0f}%"]


for key, label in CONDITION.items():
    print(row(key, label, condition_extra))
better = [CONDITION.get(k) or TIME.get(k) for k, x in r.items() if x['vs_base']['better']]
print('\n“卖掉的股票，到这一期结束又涨跌”是负数，说明卖掉以后它跌了，卖对了；是正数，说明卖早了。'
      '按事先写定的标准（8条路径里至少6条年化更高、最多2条回撤更深、2025-04-28起不更低）算更好的：' + ('、'.join(better) if better else '没有') + '。')

print('\n表44 亏赚的形状（每20个交易日算一期，8条路径；大赚是一期超过+10%，大亏是一期超过-10%）\n')
print('| 卖法 | 大赚的期数（每条路径） | 大亏的期数（每条路径） | 最差的一期 | 平均空着的钱 | 费用占本金 |')
print('|---|---|---|---|---|---|')
for key in ('base', 'GAP', 'TP10', 'UP7', 'SPIKE', 'SL10', 'TRAIL', 'BBI'):
    p = r[key]['paths']
    print(f"| {TIME.get(key) or CONDITION[key]} | {min(x['big_gain'] for x in p)}至{max(x['big_gain'] for x in p)}，中位{np.median([x['big_gain'] for x in p]):g} | "
          f"{min(x['big_loss'] for x in p)}至{max(x['big_loss'] for x in p)}，中位{np.median([x['big_loss'] for x in p]):g} | {pct(min(x['worst_period_pct'] for x in p))} | "
          f"{np.median([x['idle_pct'] for x in p]):.0f}% | {np.median([x['fees_pct_of_start'] for x in p]):.1f}% |")

base_dd = [p['max_drawdown_pct'] for p in r['base']['paths']]
print('\n表45 冲高就卖稳不稳（看过表42至表44后补测；不用来挑门槛）\n')
print('| 卖法 | 2024-07起年化中位 | 2024-01-31起年化中位 | 最大回撤（8条路径） | 比对照（8条路径）：年化更高几条，回撤更深几条 | 2025-04-28起年化 | 每条路径卖几次 |')
print('|---|---|---|---|---|---|---|')
print(f"| 现行（对照） | {pct(float(np.median([x['cagr_pct'] for x in r['base']['paths'][:4]])))} | "
      f"{pct(float(np.median([x['cagr_pct'] for x in r['base']['paths'][4:]])))} | {pct(max(base_dd))}至{pct(min(base_dd))} | — | {pct(r['base']['recent']['cagr_pct'])} | 0 |")


def check_row(label, x):
    return (f"| {label} | {pct(x['from_2024-07_median'])} | {pct(x['from_2024-01-31_median'])} | {pct(x['drawdown_shallowest'])}至{pct(x['drawdown_deepest'])} | "
            f"更高{x['higher_than_ref']}/8，更深{x['deeper_than_ref']}/8 | {pct(x['recent_cagr'])} | {x['rule_sales_mean']:g} |")


for key, x in c['thresholds'].items():
    print(check_row(NAME[key], x))
print('| **每笔滑点0.5%（买卖都算），对照是同样滑点的现行** | | | | | | |')
for key, x in c['slippage'].items():
    print(check_row(NAME[key] + ('（对照）' if key == 'base' else ''), x).replace('更高0/8，更深0/8', '—') if key == 'base' else check_row(NAME[key], x))
print('| **两条一起用：高开兑现＋止盈10%** | | | | | | |')
for against, label in (('base', '对照是现行'), ('GAP', '对照是只用高开兑现'), ('TP10', '对照是只用止盈10%')):
    print(check_row(f'高开兑现＋止盈10%（{label}）', c['combined'][f'GAP+TP10|vs {against}']))
print('| **两条一起用：高开兑现＋收盘涨7%次日卖** | | | | | | |')
for against, label in (('base', '对照是现行'), ('GAP', '对照是只用高开兑现'), ('UP7', '对照是只用收盘涨7%次日卖')):
    print(check_row(f'高开兑现＋收盘涨7%次日卖（{label}）', c['combined'][f'GAP+UP7|vs {against}']))
print('\n表46 分年度（8条路径的中位；2024年从各自起步日算起，2026年到10-29）\n')
print('| 卖法 | 2024 | 2025 | 2026 |')
print('|---|---|---|---|')
for key, x in c['years'].items():
    print(f"| {NAME[key]} | {pct(x['2024'])} | {pct(x['2025'])} | {pct(x['2026'])} |")
tp, gap = paths('TP10'), paths('GAP')
print(f"\n止盈10%对只用高开兑现（8条路径）：{versus(tp, gap)}。")
