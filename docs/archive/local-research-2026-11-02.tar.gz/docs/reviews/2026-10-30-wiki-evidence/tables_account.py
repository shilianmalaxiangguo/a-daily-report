"""Prints the round-twelve table (names held for the user's 万一免五 account) from account_names.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'account_names.json').read_text(encoding='utf-8'))
WINDOW = {'from_2024-07': '2024-07-01起', 'from_2024-01-31': '2024-01-31起（含2024年2月小盘大跌）'}


def pct(v):
    return f"{v:+.1f}%"


def mid(values):
    values = sorted(values)
    return (values[1] + values[2]) / 2


print('表32 用户的账户拿几只（1万元，万一免五，主板和创业板；按规则挑为四个起步日，随手挑为20次）\n')
print('| 起点 | 只数 | 年化中位（最低至最高） | 最大回撤中位 | 净值最低 | 跑赢创业板指 | 费用合计占本金 | 一手钱不够跳过（四个起步日合计） | 名单最深用到第几 | 买入价中位数 | 随手挑：10%至90%的范围 | 随手挑：净值最低 |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|')
for window, label in WINDOW.items():
    for k in (3, 4, 5, 6, 8, 10):
        b = r[f'{window}|{k}']
        rule, s = b['rule'], b['random_spread']
        c = [x['cagr_pct'] for x in rule]
        print(f"| {label} | {k}只 | {pct(mid(c))}（{pct(min(c))}至{pct(max(c))}） | {pct(mid([x['max_drawdown_pct'] for x in rule]))} | "
              f"{min(x['lowest_nav'] for x in rule):.2f} | {sum(x['beats_chinext'] for x in rule)}/4 | {mid([x['fees_pct_of_start'] for x in rule]):.1f}% | "
              f"{sum(x['lot_skips'] for x in rule)} | {max(x['deepest_rank'] for x in rule)} | {mid([x['price_median'] for x in rule]):.1f}元 | "
              f"{pct(s['p10'])}至{pct(s['p90'])} | {s['lowest_nav']:.2f} |")
