"""Which five of the pool? Testing the user's housing analogy (declared before running, 2026-10-31, round fourteen).

The user likens leaders to popular housing estates (recognised, easy to resell), and value to an estate whose price
fell from 3.0 to 1.4 million with the same quality ("buyers feel they got a bargain"); retail buyers chase straight
rallies and get trapped. Inside the plan's pool (main board and ChiNext; lowest fifth of 20-session turnover; latest
quarter's revenue and profit growing), five names are picked every 20 sessions in these ways:
  coldest   the five with the lowest turnover (the plan);
  bargain   the five furthest below their highest close of the last 120 sessions (at least 60 sessions of history);
  known     the five closest to that high (the "recognised estate" side);
  no-chase  the coldest five after leaving out the quarter of the pool with the highest 20-session return.
  random    five drawn at random (20 draws) as the yardstick for luck.
Mechanics of small_cap_design.run: bought at the next open (limit-up opens passed over), held to the next decision
day's close, 0.2% per period. Windows: from 2024-07-01 (start offsets 0, 5, 10, 15) and from 2025-04-28 (offset 0).
Reported: annual return and max drawdown, where each way falls among the random draws, and beating ChiNext.
A way is only worth a closer look if it beats the median random draw in every window and offset; nothing is adopted
here because it scored best (the book's warning about objectives applies to backtests too).
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import selection_value as sv  # noqa: E402

sd, ir = sv.sd, sv.ir
h, days, n = ir.h, sv.days, sv.n
close = h['close']
high120 = np.full(close.shape, np.nan)
filled = np.where(np.isnan(close), -np.inf, close)
for t in range(n):
    window = filled[:, max(0, t - 119):t + 1]
    seen = (~np.isnan(close[:, max(0, t - 119):t + 1])).sum(axis=1)
    top = window.max(axis=1)
    high120[:, t] = np.where((seen >= 60) & np.isfinite(top), top, np.nan)
ret20 = np.full(close.shape, np.nan)
growth = np.where(np.isnan(h['returns']), 0.0, h['returns'] / 100)
logs = np.concatenate([np.zeros((close.shape[0], 1)), np.cumsum(np.log1p(growth), axis=1)], axis=1)
ret20[:, 20:] = np.exp(logs[:, 21:] - logs[:, 1:-20]) - 1


def order(rule, t, rng):
    pool = sv.pool(t)                                  # coldest first
    if rule == 'coldest':
        ranked = list(pool)
    elif rule in ('bargain', 'known'):
        ratio = close[pool, t] / high120[pool, t]
        keep = ~np.isnan(ratio)
        pool, ratio = pool[keep], ratio[keep]
        ranked = list(pool[np.argsort(ratio if rule == 'bargain' else -ratio, kind='stable')])
    elif rule == 'no_chase':
        r = ret20[pool, t]
        cut = np.nanquantile(r, 0.75) if np.isfinite(r).any() else np.inf
        ranked = [i for i, x in zip(pool, r) if not (np.isfinite(x) and x > cut)]
    else:
        ranked = list(rng.permutation(pool))
    picked = []
    for i in ranked:
        if sd.buyable(i, t):
            picked.append(i)
            if len(picked) == 5:
                break
    return picked


sd.choose = order


def run(rule, first, offset=0, seed=0):
    nav, span, periods = sd.run(rule, 20, first, None, seed, offset)
    d = sd.describe(nav, span, periods)
    ref = sd.describe(sd.chinext[first + offset:] / sd.chinext[first + offset], days[first + offset:], np.array([0.0]))
    return {'cagr_pct': round(d['cagr_pct'], 2), 'max_drawdown_pct': round(d['max_drawdown_pct'], 2),
            'beats_chinext': bool(d['cagr_pct'] > ref['cagr_pct'] and d['max_drawdown_pct'] > ref['max_drawdown_pct'])}


def main():
    out = {}
    anchor = days.index('2024-07-01')
    recent = next(t for t in range(anchor, n, 20) if days[t] >= '2025-04-28')
    for window, first, offsets in (('from_2024-07', anchor, (0, 5, 10, 15)), ('from_2025-04-28', recent, (0,))):
        random_runs = [run('random', first, 0, seed) for seed in range(20)]
        median = float(np.median([r['cagr_pct'] for r in random_runs]))
        block = {'random': random_runs, 'random_median': round(median, 2), 'ways': {}}
        for rule in ('coldest', 'bargain', 'known', 'no_chase'):
            runs = [run(rule, first, o) for o in offsets]
            rank = [int(sum(r['cagr_pct'] < x['cagr_pct'] for r in random_runs)) for x in runs]
            block['ways'][rule] = {'runs': runs, 'beats_random_median': [x['cagr_pct'] > median for x in runs], 'rank_among_20': rank}
            print(window, rule, [x['cagr_pct'] for x in runs], 'mdd', [x['max_drawdown_pct'] for x in runs], 'rank of 20', rank,
                  'beats ChiNext', [x['beats_chinext'] for x in runs], flush=True)
        print(window, 'random median', round(median, 2), 'range', min(r['cagr_pct'] for r in random_runs), max(r['cagr_pct'] for r in random_runs), flush=True)
        out[window] = block
    (HERE / 'pool_order.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written pool_order.json')


if __name__ == '__main__':
    main()
