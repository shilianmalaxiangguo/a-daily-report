"""Where the B1 account's return comes from (added after the first results of round fifteen were seen, 2026-10-31).

b1_point.py found that every B1 trade, on average, did no better than a random stock of the same day with the same
exits, yet the account that takes the day's B1 signals most shrunk first (amount / largest amount of the previous 20
sessions) made +26% a year from 2024-07-01, while taking them in random order made a median of -6.9%. Checks, with
the same account, exits and costs as b1_point.account (short exits, 3 sessions, 5 names):
  1. the most shrunk stocks of the whole universe each day, no B1 condition;
  2. the most shrunk stocks among those with white > yellow, no other B1 condition;
  3. B1 signals taken least shrunk first (the order reversed);
  4. the main B1 account and check 1 from start offsets 0, 5, 10, 15 sessions;
  5. every B1 trade of b1_point part A (short exits, bought at the next open) by fifth of the shrink ratio.
Windows from 2024-07-01 and from 2025-04-28 for checks 1 to 3.
Added after checks 1 to 5 were seen (they left the account's return unexplained):
  6. trade level, the same trades as part A: each day's five most shrunk B1 signals against the other B1 signals, and
     each day's five most shrunk stocks of the whole universe; before and from 2025-04-28; the five-most-shrunk B1
     minus the other B1 of the same day, Newey-West t with lag 10; whether a day's five most shrunk B1 had an 异动 day
     (up >= 5% with the amount at least twice its previous 20-session average) in the 20 sessions before.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import b1_point as b  # noqa: E402

KEYS = ('cagr_pct', 'max_drawdown_pct', 'lowest_nav', 'beats_chinext', 'trades', 'win_share', 'fees_pct_of_start')


def by_fifth():
    busy, rows = np.full(len(b.codes), -1), []
    for t in range(b.FIRST, b.n - 1):
        for i in np.flatnonzero(b.B1[:, t]):
            if t <= busy[i]:
                continue
            r = b.trade(int(i), t)
            if r is not None:
                busy[i] = t + r['held']
                rows.append((b.SHRINK[i, t], r['ret']))
    x = np.array([s for s, _ in rows])
    y = np.array([v for _, v in rows])
    ok = ~np.isnan(x)
    edges = np.quantile(x[ok], [0.2, 0.4, 0.6, 0.8])
    fifth = np.searchsorted(edges, x[ok], side='right')
    return [{'fifth': k + 1, 'shrink_upto': round(float(edges[k]), 3) if k < 4 else None, 'trades': int((fifth == k).sum()),
             'mean_pct': round(float(y[ok][fifth == k].mean()) * 100, 2), 'win_share': round(float((y[ok][fifth == k] > 0).mean()), 3)}
            for k in range(5)]


def top_of_day():
    with np.errstate(invalid='ignore'):
        prior = np.full(b.SHRINK.shape, np.nan)
        amount = b.h['amount']
        csum = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(np.nan_to_num(amount), axis=1)], axis=1)
        prior[:, 20:] = (csum[:, 20:-1] - csum[:, :-21]) / 20          # average of the previous 20 sessions
        spike = b.BIG & (amount >= 2 * prior)
    groups = {'B1 top 5': [], 'B1 others': [], 'all top 5': []}
    gap_by_day, busy = {}, {key: np.full(len(b.codes), -1) for key in groups}
    spiked = []
    for t in range(b.FIRST, b.n - 1):
        hits = np.flatnonzero(b.B1[:, t])
        order = hits[np.argsort(np.where(np.isnan(b.SHRINK[hits, t]), np.inf, b.SHRINK[hits, t]), kind='stable')]
        pool = np.flatnonzero(b.U[:, t])
        everyone = pool[np.argsort(np.where(np.isnan(b.SHRINK[pool, t]), np.inf, b.SHRINK[pool, t]), kind='stable')][:5]
        day = {'B1 top 5': order[:5], 'B1 others': order[5:], 'all top 5': everyone}
        spiked += [bool(spike[i, max(0, t - 20):t].any()) for i in order[:5]]
        rets = {}
        for key, members in day.items():
            for i in members:
                if t <= busy[key][i]:
                    continue
                r = b.trade(int(i), t)
                if r is None:
                    continue
                busy[key][i] = t + r['held']
                groups[key].append((t, r['ret']))
                rets.setdefault(key, []).append(r['ret'])
        if rets.get('B1 top 5') and rets.get('B1 others'):
            gap_by_day[t] = float(np.mean(rets['B1 top 5']) - np.mean(rets['B1 others']))
    out = {'spike_share_top5': round(float(np.mean(spiked)), 3)}
    for key, rows in groups.items():
        for part, test in (('all', lambda t: True), ('before_2025-04-28', lambda t: t < b.RECENT), ('from_2025-04-28', lambda t: t >= b.RECENT)):
            v = np.array([r for t, r in rows if test(t)])
            out[f'{key}|{part}'] = {'trades': int(len(v)), 'mean_pct': round(float(v.mean()) * 100, 2), 'median_pct': round(float(np.median(v)) * 100, 2),
                                    'win_share': round(float((v > 0).mean()), 3), 'gain_over_10_share': round(float((v > 0.10).mean()), 3)}
    series = [gap_by_day[t] for t in sorted(gap_by_day)]
    out['top5_minus_others'] = {'days': len(series), 'mean_pp': round(float(np.mean(series)) * 100, 2), 'nw_t': round(b.newey_west_t(series, 10), 2)}
    return out


def main():
    out = {'windows': {}, 'offsets': {}}
    for window, first in (('from_2024-07', b.FIRST), ('from_2025-04-28', b.RECENT)):
        block = {}
        for label, signal, order in (('all stocks, most shrunk first', b.U, 'shrink'), ('white > yellow, most shrunk first', b.TREND, 'shrink'),
                                     ('B1, least shrunk first', b.B1, 'reverse')):
            if order == 'reverse':
                saved = b.SHRINK.copy()
                b.SHRINK[:] = -np.where(np.isnan(saved), -np.inf, saved)
            try:
                run = b.account(signal, first)
            finally:
                if order == 'reverse':
                    b.SHRINK[:] = saved
            block[label] = {key: run[key] for key in KEYS}
            print(window, label, block[label], flush=True)
        out['windows'][window] = block
    for label, signal in (('B1, most shrunk first', b.B1), ('all stocks, most shrunk first', b.U)):
        runs = [b.account(signal, b.FIRST + offset) for offset in (0, 5, 10, 15)]
        out['offsets'][label] = [{key: r[key] for key in KEYS} for r in runs]
        print('offsets', label, [(r['cagr_pct'], r['max_drawdown_pct'], r['beats_chinext']) for r in runs], flush=True)
    out['b1_trades_by_shrink_fifth'] = by_fifth()
    print('by fifth', out['b1_trades_by_shrink_fifth'], flush=True)
    out['top_of_day'] = top_of_day()
    print('top of day', out['top_of_day'], flush=True)
    (HERE / 'b1_order.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written b1_order.json')


if __name__ == '__main__':
    main()
