"""Starting in the middle of a period: buy the period's list, or a list ranked at the latest close?
(declared before running, 2026-10-31, round thirteen)

Pool and ranking as in the plan (main board and ChiNext, coldest five with growing revenue and profit, financial data
known by the ranking day). For every period of the plan's schedule (decision day t, next decision day t+20), a late
starter buys at the open of t+k+1 and holds to the close of t+20, for k = 5 and 10:
  period list  the five names ranked at t (the published list), passing over names that cannot be bought then;
  fresh list   the five names ranked at the close of t+k with the data known then.
Equal weights, 0.2% for the round trip; start offsets 0, 5, 10, 15 sessions from 2024-07-01 and from 2024-01-31.
Reported: mean and median return per entry, share of entries where the fresh list did better, the mean gap, and how
many of the five names differ between the two lists. Also, for 2026-10-30: the fresh list against the 10-23 list.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import real_account as ra  # noqa: E402

h, days, n, codes = ra.h, ra.days, ra.n, ra.codes
growth = np.where(np.isnan(h['returns']), 0.0, h['returns'] / 100)
STAR, COST = ('688', '689'), 0.002


def five(t, e):
    picked = []
    for i in ra.ranked(t):
        if codes[i].startswith(STAR):
            continue
        g = ra.gap(i, e)
        if g is None or g >= h['limit'][i] - 0.2:
            continue
        picked.append(i)
        if len(picked) == 5:
            break
    return picked


def hold(members, e, end):
    if not members:
        return None
    value = [h['close'][i, e] / h['open'][i, e] * np.prod(1 + growth[i, e + 1:end + 1]) for i in members]
    return (float(np.mean(value)) * (1 - COST) - 1) * 100


def main():
    out = {}
    for window, label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        first = days.index(label)
        for k in (5, 10):
            rows = []
            for offset in (0, 5, 10, 15):
                for t in range(first + offset, n - 21, 20):
                    e, end = t + k + 1, t + 20
                    old, new = five(t, e), five(t + k, e)
                    a, b = hold(old, e, end), hold(new, e, end)
                    if a is not None and b is not None:
                        rows.append({'decision': days[t], 'period_pct': a, 'fresh_pct': b, 'differ': len(set(old) - set(new))})
            gap = np.array([r['fresh_pct'] - r['period_pct'] for r in rows])
            out[f'{window}|{k}'] = {'entries': len(rows), 'period_mean': round(float(np.mean([r['period_pct'] for r in rows])), 2),
                                    'fresh_mean': round(float(np.mean([r['fresh_pct'] for r in rows])), 2),
                                    'period_median': round(float(np.median([r['period_pct'] for r in rows])), 2),
                                    'fresh_median': round(float(np.median([r['fresh_pct'] for r in rows])), 2),
                                    'fresh_better_share': round(float((gap > 0).mean()), 3), 'mean_gap_pp': round(float(gap.mean()), 2),
                                    't': round(float(gap.mean() / (gap.std(ddof=1) / np.sqrt(len(gap)))), 2),
                                    'names_differ_mean': round(float(np.mean([r['differ'] for r in rows])), 2)}
            print(window, k, out[f'{window}|{k}'], flush=True)
    t = days.index('2026-10-23')
    last = days.index('2026-10-29')
    listed = lambda day: [codes[i] for i in ra.ranked(day) if not codes[i].startswith(STAR)][:8]
    out['latest'] = {'2026-10-23': listed(t), '2026-10-29': listed(last)}
    print('2026-10-23 list', out['latest']['2026-10-23'], '\n2026-10-29 list', out['latest']['2026-10-29'])
    (HERE / 'late_entry.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written late_entry.json')


if __name__ == '__main__':
    main()
