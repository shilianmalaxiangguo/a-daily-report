"""Prints the round-fourteen table (which five of the pool) from pool_order.json."""
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'pool_order.json').read_text(encoding='utf-8'))
LABEL = {'coldest': '最冷门的5只（现行）', 'bargain': '捡便宜：离半年最高收盘跌得最多的5只', 'known': '有辨识度：离半年最高收盘最近的5只',
         'no_chase': '不追拉升：去掉近20日涨得最多的四分之一，再取最冷门的5只'}


def pct(v):
    return f"{v:+.1f}%"


print('表35 股票池里怎样挑5只（主板和创业板，冷门且业绩增长；每20个交易日换，每期来回0.2%）\n')
print('| 挑法 | 2024-07起四个起步日年化 | 最大回撤 | 在随机挑5只（20次）里超过几次 | 跑赢创业板指 | 2025-04-28起（近18个月） | 最大回撤 |')
print('|---|---|---|---|---|---|---|')
a, b = r['from_2024-07'], r['from_2025-04-28']
for key, label in LABEL.items():
    runs, recent = a['ways'][key], b['ways'][key]
    c = [x['cagr_pct'] for x in runs['runs']]
    dd = [x['max_drawdown_pct'] for x in runs['runs']]
    print(f"| {label} | {'、'.join(pct(x) for x in c)} | {pct(max(dd))}至{pct(min(dd))} | {'、'.join(str(x) for x in runs['rank_among_20'])} | "
          f"{sum(x['beats_chinext'] for x in runs['runs'])}/4 | {pct(recent['runs'][0]['cagr_pct'])} | {pct(recent['runs'][0]['max_drawdown_pct'])} |")
rand_a = [x['cagr_pct'] for x in a['random']]
rand_b = [x['cagr_pct'] for x in b['random']]
print(f"| 随机挑5只（20次） | 中位{pct(a['random_median'])}（{pct(min(rand_a))}至{pct(max(rand_a))}） | — | — | — | "
      f"中位{pct(b['random_median'])}（{pct(min(rand_b))}至{pct(max(rand_b))}） | — |")
