"""A 10,000-yuan account split into two buckets that are never rebalanced against each other (declared before running).

Bucket T: ChiNext held only while its close is above its 60-session average (the index stands in for its fund;
execution as in style_rotation.py: signal at the close, trade at the next open, 0.1% each side, cash 1.5% a year;
cash until the average exists).
Bucket S: the small-stock rotation as a real account (small_cap_account.py, fees with the 5-yuan minimum):
5 names at most 20 yuan for 10,000; 5 names at most 10 yuan for 5,000; 4 names at most 10 yuan for 4,000.
Splits T/S: 10,000/0, 6,000/4,000, 5,000/5,000, 0/10,000. Starts 2024-09-02 and 2024-01-31; 20 seeds for S.
Reported: final value, annualised return, max drawdown, the lowest value, runs below 8,000 and 7,000 yuan.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import small_cap_account as sca  # noqa: E402
import style_rotation as sr  # noqa: E402

assert sca.days == sr.days
days, n = sr.days, len(sr.days)
ma = sr.moving_average(sr.px['399006.SZ']['close'], 60)
target = ['399006.SZ' if not np.isnan(ma[t]) and sr.px['399006.SZ']['close'][t] > ma[t] else None for t in range(n)]
trend_daily = sr.simulate(target)
SPLITS = {'T10000': (10_000, 0, 0, 0), 'T6000_S4000': (6_000, 4_000, 4, 10.0), 'T5000_S5000': (5_000, 5_000, 5, 10.0),
          'S10000': (0, 10_000, 5, 20.0)}


def summary(values):
    years = (len(values) - 1) / 252
    return {'final': float(values[-1]), 'cagr_pct': float((values[-1] / 10_000) ** (1 / years) * 100 - 100),
            'max_drawdown_pct': float((values / np.maximum.accumulate(values) - 1).min() * 100), 'lowest': float(values.min())}


result = {'windows': {}}
for label, first in (('from_2024-09-02', days.index('2024-09-02')), ('from_2024-01-31', 19)):
    trend_curve = np.concatenate([[1.0], np.cumprod(1 + trend_daily[first + 1:])])
    block = {}
    for name, (t_cash, s_cash, names, max_price) in SPLITS.items():
        runs = []
        for seed in range(20 if s_cash else 1):
            values = t_cash * trend_curve
            if s_cash:
                values = values + sca.run(first, seed, True, start_cash=float(s_cash), names=names, max_price=max_price, values_out=True)
            runs.append(summary(values))
        block[name] = {'below_8000': sum(r['lowest'] < 8000 for r in runs), 'below_7000': sum(r['lowest'] < 7000 for r in runs),
                       'negative_runs': sum(r['cagr_pct'] < 0 for r in runs), 'runs': len(runs),
                       **{m: {'median': round(float(np.median([r[m] for r in runs])), 2), 'min': round(float(min(r[m] for r in runs)), 2),
                              'max': round(float(max(r[m] for r in runs)), 2)} for m in ('final', 'cagr_pct', 'max_drawdown_pct', 'lowest')}}
    result['windows'][label] = block
out = HERE / 'account_mix.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
for label, block in result['windows'].items():
    for name, b in block.items():
        print(label, name, 'final', b['final']['median'], f"({b['final']['min']}-{b['final']['max']})", 'cagr', b['cagr_pct']['median'],
              'mdd', b['max_drawdown_pct']['median'], 'worst mdd', b['max_drawdown_pct']['min'], 'lowest', b['lowest']['median'],
              'min lowest', b['lowest']['min'], 'below8000', b['below_8000'], 'below7000', b['below_7000'], 'of', b['runs'])
