"""After a take-profit sale, buy the next name or keep the money; are the gains 80/20? (declared before running, 2026-10-31, round seventeen)

User, 2026-10-31: "持有的股票比买价高10%卖出之后没需要依次买入列表中下一个个股吗 还是说把钱留着……我觉得轮动起来的才是钱，
但确实垃圾行情也不值得买，28定律……20%的时间贡献了80%的涨幅".
Same account, paths and costs as sell_rules.py, with its take-profit rule TP10 (a close 10% or more above what was
paid sells at the next open). After such a sale:
  WAIT    the money waits for the next rotation (round sixteen);
  PERIOD  at the same open, buy down the period's list (names not held and not sold this period), as on a rotation day;
  FRESH   the same from a list ranked at the previous close (the plan's ranking, as for someone starting late);
  CALM    PERIOD only when the CSI 2000 closed above its 20-session average the day before, otherwise the money waits.
Names bought this way follow the same take-profit rule. The base (no take-profit) is shown for reference.
A refill counts as better than WAIT only if its annual return is higher on at least 6 of the 8 paths, its max drawdown
is deeper on at most 2 of them, and its return from 2025-04-28 is not lower.
Also reported:
  1. the names sold by TP10 (WAIT): what each did from the sale to the period's last close (what holding on would
     have given): median, mean, the share that rose another 10% or more, the share that fell;
  2. 80/20, per path, for the base, WAIT, PERIOD and ChiNext: the return made on the best 20% of sessions alone and
     on the other 80% (as if those days were spent in cash).
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import sell_rules as sr  # noqa: E402

days, n = sr.days, sr.n
VARIANTS = {'base': {}, 'WAIT': {'rule': 'TP10'}, 'PERIOD': {'rule': 'TP10', 'refill': 'period'},
            'FRESH': {'rule': 'TP10', 'refill': 'fresh'}, 'CALM': {'rule': 'TP10', 'refill': 'calm'}}


def split(nav):
    lr = np.diff(np.log(np.asarray(nav, dtype=float)))
    best = np.sort(lr)[::-1][:int(round(0.2 * len(lr)))].sum()
    return {'total_pct': round(float(np.expm1(lr.sum())) * 100, 1), 'best20_pct': round(float(np.expm1(best)) * 100, 1),
            'other80_pct': round(float(np.expm1(lr.sum() - best)) * 100, 1)}


def describe(runs, recent, ref):
    a, b = runs[:4], runs[4:]
    dd = [x['max_drawdown_pct'] for x in runs]
    out = {'from_2024-07_median': round(float(np.median([x['cagr_pct'] for x in a])), 1),
           'from_2024-01-31_median': round(float(np.median([x['cagr_pct'] for x in b])), 1),
           'drawdown_shallowest': max(dd), 'drawdown_deepest': min(dd), 'lowest_nav': min(x['lowest_nav'] for x in runs),
           'beats_chinext': sum(x['beats_chinext'] for x in runs), 'recent_cagr': recent['cagr_pct'], 'recent_drawdown': recent['max_drawdown_pct'],
           'big_gain_median': float(np.median([x['big_gain'] for x in runs])), 'big_loss_median': float(np.median([x['big_loss'] for x in runs])),
           'worst_period_pct': min(x['worst_period_pct'] for x in runs), 'idle_pct_median': float(np.median([x['idle_pct'] for x in runs])),
           'fees_pct_median': float(np.median([x['fees_pct_of_start'] for x in runs])), 'refills_mean': float(np.mean([x['refills'] for x in runs])),
           'paths': [[x['cagr_pct'], x['max_drawdown_pct']] for x in runs]}
    if ref is not None:
        out['higher_than_wait'] = sum(x['cagr_pct'] > y['cagr_pct'] for x, y in zip(runs, ref[0]))
        out['deeper_than_wait'] = sum(x['max_drawdown_pct'] < y['max_drawdown_pct'] for x, y in zip(runs, ref[0]))
        out['recent_not_lower'] = recent['cagr_pct'] >= ref[1]['cagr_pct']
        out['better_than_wait'] = out['higher_than_wait'] >= 6 and out['deeper_than_wait'] <= 2 and out['recent_not_lower']
    return out


def main():
    out, runs = {'variants': {}, 'eighty_twenty': {}}, {}
    for name, kw in VARIANTS.items():
        paths = [sr.simulate(days.index(label), offset, keep_nav=True, detail=True, **kw) for _, label, offset in sr.PATHS]
        runs[name] = (paths, sr.simulate(sr.RECENT, 0, detail=True, **kw))
    for name in VARIANTS:
        ref = runs['WAIT'] if name not in ('base', 'WAIT') else None
        out['variants'][name] = describe(*runs[name], ref)
        print(name, {k: v for k, v in out['variants'][name].items() if k != 'paths'}, flush=True)
    gave = np.array([g for x in runs['WAIT'][0] for g in x['gave_up']])
    out['tp10_sales'] = {'sales': int(len(gave)), 'median_pct': round(float(np.median(gave)) * 100, 2), 'mean_pct': round(float(gave.mean()) * 100, 2),
                         'rose_10_more_share': round(float((gave >= 0.10).mean()), 3), 'fell_share': round(float((gave < 0).mean()), 3),
                         'fell_10_more_share': round(float((gave <= -0.10).mean()), 3)}
    print('TP10 sales', out['tp10_sales'], flush=True)
    for name in ('base', 'WAIT', 'PERIOD'):
        per = [split(x['nav']) for x in runs[name][0]]
        out['eighty_twenty'][name] = {key: round(float(np.median([p[key] for p in per])), 1) for key in per[0]}
    per = []
    for _, label, offset in sr.PATHS:
        start = days.index(label) + offset
        per.append(split(sr.ra.chinext_window(start)))
    out['eighty_twenty']['ChiNext'] = {key: round(float(np.median([p[key] for p in per])), 1) for key in per[0]}
    print('80/20', out['eighty_twenty'], flush=True)
    (HERE / 'sell_refill.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written sell_refill.json')


if __name__ == '__main__':
    main()
