"""Fetch every A-share's daily high, low and volume (with close, for a cross-check) into .generated/market-hl/<date>.json.

One call per trading day (tushare.daily by trade_date); days already saved with volume are skipped, so it can be resumed.
Volume (vol) is in lots of 100 shares, as Tushare reports it.
Arguments: project root, first date, last date. The saved close is compared with the close in the existing
market-returns-v2 cache for the same day; a day with any disagreement is reported and not saved.
"""
import json
import sys
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'scripts'))
from market_data.tushare_client import create_tushare_pro_api  # noqa: E402
from report.market_returns import _pages  # noqa: E402

first, last = sys.argv[2], sys.argv[3]
out_dir = ROOT / '.generated/market-hl'
out_dir.mkdir(parents=True, exist_ok=True)
calendar = json.loads((ROOT / '.generated/backtest-history/calendar.json').read_text(encoding='utf-8'))
days = sorted(f"{r['cal_date'][:4]}-{r['cal_date'][4:6]}-{r['cal_date'][6:]}" for r in calendar['rows']
              if int(r['is_open']) == 1 and first.replace('-', '') <= r['cal_date'] <= last.replace('-', ''))
pro = create_tushare_pro_api(timeout_seconds=60)
done = mismatched = 0
for day in days:
    target = out_dir / f'{day}.json'
    if target.is_file() and 'vol' in json.loads(target.read_text(encoding='utf-8')).get('fields', []):
        continue
    for attempt in range(3):
        try:
            rows = _pages(pro, 'daily', trade_date=day.replace('-', ''), fields='ts_code,trade_date,high,low,close,vol')
            break
        except Exception as error:
            if attempt == 2:
                print(day, 'FAILED', type(error).__name__, str(error)[:120], flush=True)
                rows = None
            time.sleep(3)
    if not rows:
        continue
    cached = ROOT / f'.generated/market-returns-v2/{day}.json'
    if cached.is_file():
        value = json.loads(cached.read_text(encoding='utf-8'))
        known = {r['ts_code']: float(r['close']) for r in value.get('rows') or [] if r.get('close') is not None}
        bad = [r['ts_code'] for r in rows if r['ts_code'] in known and r.get('close') is not None
               and abs(float(r['close']) - known[r['ts_code']]) > 1e-6]
        if bad:
            mismatched += 1
            print(day, 'close differs from the cache for', len(bad), 'codes, e.g.', bad[:3], flush=True)
            continue
    target.write_text(json.dumps({'date': day, 'retrieved_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
                                  'source': 'tushare.daily', 'fields': ['ts_code', 'high', 'low', 'close', 'vol'],
                                  'rows': [[r['ts_code'], r['high'], r['low'], r['close'], r['vol']] for r in rows]},
                                 ensure_ascii=False), encoding='utf-8')
    done += 1
    if done % 50 == 0:
        print('saved', done, 'last', day, flush=True)
print('finished: saved', done, 'mismatched days', mismatched, 'total days', len(days), flush=True)
