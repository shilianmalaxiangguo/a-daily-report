"""Daily rank IC of the 20-session independent return, split by calendar year (same definition as the frozen backtest)."""
import json
from math import sqrt
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, load  # noqa: E402
from report.strategy_backtest import HOLD, daily_choices, signals  # noqa: E402

h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
s = signals(h)
choices = daily_choices(h, s)
start = next(t for t, c in enumerate(choices) if c is not None and c['stance'] is not None)
days, n = h['days'], len(h['days'])
out = {}
for name in ('own', 't_alpha', 'own5'):
    series = {}
    for t in range(start, n - HOLD):
        fwd = (h['close'][:, t + 1] / h['open'][:, t + 1] * np.prod(1 + h['returns'][:, t + 2:t + HOLD + 1] / 100, axis=1) - 1) * 100
        ok = s['complete'][:, t] & ~np.isnan(fwd) & ~np.isnan(s[name][:, t])
        if ok.sum() < 200:
            continue
        x, y = s[name][ok, t], fwd[ok]
        rx, ry = np.empty(len(x)), np.empty(len(y))
        rx[x.argsort(kind='stable')] = np.arange(len(x))
        ry[y.argsort(kind='stable')] = np.arange(len(y))
        series[days[t]] = float(np.corrcoef(rx, ry)[0, 1])
    for year in ('2024', '2025', '2026', 'all'):
        v = np.array([ic for d, ic in series.items() if year == 'all' or d.startswith(year)])
        t_stat = v.mean() / (v.std(ddof=1) / sqrt(max(len(v) / HOLD, 1)))
        out[f'{name}|{year}'] = {'days': len(v), 'mean_ic': round(float(v.mean()), 4), 't_overlap_adjusted': round(float(t_stat), 2),
                                 'positive_share': round(float((v > 0).mean()), 3)}
print(json.dumps(out, ensure_ascii=False, indent=1))
Path(__file__).with_name('ic_by_year.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
