"""Prints the round-eleven table (names held, luck and costs) from names_count.json."""
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'names_count.json').read_text(encoding='utf-8'))
WINDOW = {'from_2024-07': '2024-07-01起', 'from_2024-01-31': '2024-01-31起（含2024年2月小盘大跌）'}


def pct(v):
    return f"{v:+.1f}%"


print('表31 拿几只：运气和费用（1万元，主板和创业板；按规则挑为四个起步日，随手挑为20次）\n')
print('| 起点 | 佣金 | 只数 | 按规则挑：年化中位（最低至最高） | 最大回撤中位 | 费用合计占本金 | 随手挑：年化中位 | 随手挑：10%至90%的范围 | 随手挑：净值最低 |')
print('|---|---|---|---|---|---|---|---|---|')
for window, wlabel in WINDOW.items():
    for account, alabel in (('1万普通', '每笔最低5元'), ('1万免五', '免五')):
        for k in (3, 5, 10):
            b = r[f'{window}|{account}|{k}']
            c = sorted(x['cagr_pct'] for x in b['rule'])
            dd = sorted(x['max_drawdown_pct'] for x in b['rule'])
            fees = sorted(x['fees_pct_of_start'] for x in b['rule'])
            s = b['random_spread']
            print(f"| {wlabel} | {alabel} | {k}只 | {pct((c[1] + c[2]) / 2)}（{pct(c[0])}至{pct(c[-1])}） | {pct((dd[1] + dd[2]) / 2)} | "
                  f"{(fees[1] + fees[2]) / 2:.1f}% | {pct(s['median'])} | {pct(s['p10'])}至{pct(s['p90'])} | {min(x['lowest_nav'] for x in b['random']):.2f} |")
