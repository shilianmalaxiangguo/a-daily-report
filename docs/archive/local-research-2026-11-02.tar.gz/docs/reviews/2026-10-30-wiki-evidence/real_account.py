"""The execution plan run as a real account would run it (declared before running, 2026-10-30, round six).

Rule (as in the report): decision days every 20 sessions from 2024-07-01. After the close of a decision day t,
rank the cold basket (eligible stocks in the lowest fifth of 20-session average turnover) whose latest quarter
announced by t shows revenue and profit growth above zero, coldest first. Boards a variant may trade: all
(Shanghai and Shenzhen A shares, ChiNext 300/301/302 and STAR 688/689 included), no STAR, or main board only;
names on other boards are passed over.

Orders at the open of t+1 (the list is only known after the close of t):
1. Sell every held name that is not among the first three tradable names of the new list. A sale needs an open
   that is not at or near the limit down and not suspended; otherwise the name is kept and offered again at each
   following open. When such a late sale goes through, the freed money buys from the same list at that open.
2. Held names among the first three stay untouched; nothing is rebalanced.
3. Buy down the list until three names are held. A name is passed over when it opens at or near the limit up,
   is suspended, or one lot costs more than its share of the cash (cash / empty places): 100 shares per lot; STAR
   at least 200 shares, then 1-share steps. Whole lots only. Names past the first three are the backups.
Holdings are valued with close / previous close (splits and dividends count as price); a sale uses the open /
previous close of that day.

Costs: commission 0.025% of each order with a 5-yuan minimum ("普通"), or no minimum ("免五"); stamp duty 0.05% on
sales; transfer fee 0.001% both ways; slippage 0, or 0.2% against us on every order as a check. Idle cash earns
nothing; dividend tax is ignored.

Accounts: 10,000 yuan 普通, 10,000 免五, 100,000 普通; results as net value from 1. Stop rule: after a close with
the account's net value below the floor (0.8, 0.7 or none), sell everything from the next open and stay in cash.

Per run: annualised return, max drawdown, lowest net value, final net value, the 20-session loss profile, beating
ChiNext (higher annual return and a shallower max drawdown, same window), orders, fees as a share of the starting
money, average idle cash, names kept per switch, backups used and the deepest rank used, late sales, passed-over
buys by reason; and the idealised backtest (small_cap_design.run) of the same start.

Also: (a) how much the top three would change if recomputed every session (against the previous session and
against the current period's list); (b) switching every session to that session's top three, same costs;
(c) switching every 10, 20, 40 and 60 sessions; (d) start offsets 0, 5, 10, 15 sessions, from 2024-07-01 and from
2024-01-31; (e) the industries of the names bought; (f) prices of the names bought and how often one lot did not fit.
Added after the first run was seen: the four start offsets and the floors for "no STAR" as well (the first run had
them for all boards and the main board only).
"""
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import industry_rotation as ir  # noqa: E402
import small_cap_design as sd  # noqa: E402

h, days, n, codes = ir.h, ir.days, ir.n, ir.codes
RATE, STAMP, TRANSFER = 0.00025, 0.0005, 0.00001
BOARDS = {'all': lambda c: True, 'no_star': lambda c: not c.startswith(('688', '689')),
          'main': lambda c: not c.startswith(('688', '689', '300', '301', '302'))}
ACCOUNTS = {'1万普通': (10_000.0, 5.0), '1万免五': (10_000.0, 0.0), '10万普通': (100_000.0, 5.0)}
_ranked = {}


def ranked(t):
    """Growth-filtered cold basket at the close of t, coldest first (all boards)."""
    if t not in _ranked:
        members = sd.basket(t)
        sales, profit = ir.latest_growth(t)
        ok = members[(sales[members] > 0) & (profit[members] > 0)]
        _ranked[t] = [int(i) for i in ok[np.argsort(ir.avg20[ok, t], kind='stable')]]
    return _ranked[t]


def tradable(t, board):
    return [i for i in ranked(t) if BOARDS[board](codes[i])]


def gap(i, d):
    o, pc = h['open'][i, d], h['pre'][i, d]
    return None if np.isnan(o) or np.isnan(pc) or np.isnan(h['close'][i, d]) else (o / pc - 1) * 100


def fee(amount, minimum, sell):
    return max(minimum, RATE * amount) + TRANSFER * amount + (STAMP * amount if sell else 0.0)


def simulate(account, board, schedule=20, first=None, offset=0, floor=None, slip=0.0):
    start_cash, minimum = ACCOUNTS[account]
    first = days.index('2024-07-01') if first is None else first
    decisions = set(range(first + offset, n - 1, schedule))
    start = min(decisions)
    cash, held, pending, plan_list, stopped = start_cash, {}, set(), [], False   # held: index -> value at last close
    nav, stats, prices, industries, kept, depth = [1.0], Counter(), [], Counter(), [], []
    for d in range(start + 1, n):
        t = d - 1
        switch = t in decisions and not stopped
        if switch:
            plan_list = tradable(t, board)
            keep = set(plan_list[:3])
            kept.append(len(keep & set(held)))
            pending |= {i for i in held if i not in keep}
            stats['switches'] += 1
        freed = False
        for i in sorted(pending):                                   # sales at the open of d
            g = gap(i, d)
            if g is None or g <= -(h['limit'][i] - 0.2):
                stats['late_sale_days'] += 1
                continue
            gross = held.pop(i) * h['open'][i, d] / h['pre'][i, d] * (1 - slip)
            cost = fee(gross, minimum, True)
            cash += gross - cost
            stats['fees'] += cost
            stats['sells'] += 1
            pending.discard(i)
            freed = not switch
        bought_today = set()
        if not stopped and plan_list and len(held) < 3 and (switch or freed):
            for rank, i in enumerate(plan_list, start=1):            # buys at the open of d, down the list
                if len(held) >= 3:
                    break
                if i in held:
                    continue
                g = gap(i, d)
                if g is None:
                    stats['skip_suspended'] += 1
                    continue
                if g >= h['limit'][i] - 0.2:
                    stats['skip_limit_up'] += 1
                    continue
                price = h['open'][i, d] * (1 + slip)
                budget = cash / (3 - len(held))
                star = codes[i].startswith(('688', '689'))
                shares = np.floor(budget / price) if star else np.floor(budget / (price * 100)) * 100
                while shares > 0 and shares * price + fee(shares * price, minimum, False) > budget:
                    shares -= 1 if star else 100
                if shares <= 0 or (star and shares < 200):
                    stats['skip_one_lot_too_dear'] += 1
                    continue
                amount = shares * price
                cost = fee(amount, minimum, False)
                cash -= amount + cost
                stats['fees'] += cost
                stats['buys'] += 1
                held[i] = shares * h['close'][i, d]
                bought_today.add(i)
                prices.append(float(h['open'][i, d]))
                industries[ir.industry[i] or '未知'] += 1
                depth.append(rank)
            if not switch and bought_today:
                stats['refills'] += 1
        for i in held:                                              # value at the close of d
            c, p = h['close'][i, d], h['pre'][i, d]
            if i not in bought_today and not (np.isnan(c) or np.isnan(p)):
                held[i] *= c / p
        equity = cash + sum(held.values())
        nav.append(equity / start_cash)
        stats['idle_sum'] += cash / equity
        if floor and not stopped and nav[-1] < floor:
            stopped = True
            stats['stopped_on'] = days[d]
            pending |= set(held)
    stats['unsold_at_end'] = len(pending)
    return np.array(nav), days[start:], sorted(decisions), stats, prices, industries, kept, depth


def profile(nav, span, decisions, start):
    idx = [t - start for t in decisions] + [len(nav) - 1]
    periods = np.array([nav[idx[k + 1]] / nav[idx[k]] - 1 for k in range(len(idx) - 1)])
    return sd.describe(nav, span, periods)


def chinext_window(start):
    nav = sd.chinext[start:] / sd.chinext[start]
    return nav


def summary(account, board, schedule=20, first=None, offset=0, floor=None, slip=0.0):
    nav, span, decisions, stats, prices, industries, kept, depth = simulate(account, board, schedule, first, offset, floor, slip)
    start = days.index(span[0])
    d = profile(nav, span, decisions, start)
    ref = profile(chinext_window(start), span, decisions, start)
    out = {k: (round(v, 4) if isinstance(v, float) else v) for k, v in d.items()}
    out.update(start=span[0], final_nav=round(float(nav[-1]), 4), chinext_cagr_pct=round(ref['cagr_pct'], 2),
               chinext_max_drawdown_pct=round(ref['max_drawdown_pct'], 2),
               beats_chinext=bool(d['cagr_pct'] > ref['cagr_pct'] and d['max_drawdown_pct'] > ref['max_drawdown_pct']),
               orders=stats['buys'] + stats['sells'], buys=stats['buys'], sells=stats['sells'],
               fees_pct_of_start=round(stats['fees'] / ACCOUNTS[account][0] * 100, 2),
               idle_cash_pct=round(stats['idle_sum'] / (len(nav) - 1) * 100, 2),
               kept_per_switch=round(float(np.mean(kept)), 2) if kept else None,
               backups_used=int(sum(r > 3 for r in depth)), deepest_rank=max(depth) if depth else None,
               late_sale_days=stats['late_sale_days'], refills=stats['refills'], skip_limit_up=stats['skip_limit_up'],
               skip_suspended=stats['skip_suspended'], skip_one_lot_too_dear=stats['skip_one_lot_too_dear'],
               stopped_on=stats.get('stopped_on'), unsold_at_end=stats['unsold_at_end'],
               price_median=round(float(np.median(prices)), 2) if prices else None,
               industries=dict(industries.most_common(12)))
    return out, nav


def churn(first):
    """How many of the top three change from one session to the next, and against the period's list."""
    daily, against_period = [], []
    period_list = None
    for t in range(first, n - 1):
        top = ranked(t)[:3]
        if (t - first) % 20 == 0:
            period_list = set(top)
        if t > first:
            daily.append(3 - len(set(top) & set(ranked(t - 1)[:3])))
        against_period.append(3 - len(set(top) & period_list))
    daily = np.array(daily)
    return {'sessions': int(len(daily)), 'mean_changed_per_session': round(float(daily.mean()), 2),
            'share_of_sessions_with_a_change': round(float((daily > 0).mean()), 3),
            'mean_differing_from_period_list': round(float(np.mean(against_period)), 2)}


def main():
    result = {'grid': {}, 'offsets': {}, 'schedules': {}, 'floors': {}, 'daily': {}}
    first07, first01 = days.index('2024-07-01'), days.index('2024-01-31')
    for account in ACCOUNTS:
        for board in BOARDS:
            out, _ = summary(account, board)
            result['grid'][f'{account}|{board}'] = out
            print('grid', account, board, out['cagr_pct'], out['max_drawdown_pct'], out['lowest_nav'], out['final_nav'], 'fees', out['fees_pct_of_start'],
                  'idle', out['idle_cash_pct'], 'kept', out['kept_per_switch'], 'skips', out['skip_limit_up'], out['skip_one_lot_too_dear'], flush=True)
    out, _ = summary('1万普通', 'all', slip=0.002)
    result['grid']['1万普通|all|滑点0.2%'] = out
    print('slip', out['cagr_pct'], out['max_drawdown_pct'], flush=True)
    for window, first in (('from_2024-07', first07), ('from_2024-01-31', first01)):
        for board in ('all', 'no_star', 'main'):
            runs = []
            for offset in (0, 5, 10, 15):
                ideal = sd.describe(*sd.run('growth:3', 20, first, None, 0, offset)[:2],
                                    sd.run('growth:3', 20, first, None, 0, offset)[2])['cagr_pct'] if board == 'all' else None
                out, _ = summary('1万普通', board, first=first, offset=offset)
                out['idealised_cagr_pct'] = round(ideal, 2) if ideal is not None else None
                runs.append(out)
                print('offset', window, board, offset, out['cagr_pct'], out['max_drawdown_pct'], out['lowest_nav'], 'ideal', out['idealised_cagr_pct'],
                      'beats', out['beats_chinext'], flush=True)
            result['offsets'][f'{window}|{board}'] = runs
            for floor in (0.8, 0.7):
                stops = []
                for offset in (0, 5, 10, 15):
                    out, _ = summary('1万普通', board, first=first, offset=offset, floor=floor)
                    stops.append({'offset': offset, 'stopped_on': out['stopped_on'], 'final_nav': out['final_nav'], 'cagr_pct': out['cagr_pct']})
                result['floors'][f'{window}|{board}|{floor}'] = stops
                print('floor', window, board, floor, stops, flush=True)
    for schedule in (10, 20, 40, 60):
        for board in ('all', 'main'):
            runs = [summary('1万普通', board, schedule=schedule, offset=offset)[0] for offset in (0, 5, 10, 15)]
            result['schedules'][f'{schedule}|{board}'] = runs
            print('schedule', schedule, board, [(r['cagr_pct'], r['max_drawdown_pct'], r['fees_pct_of_start']) for r in runs], flush=True)
    out, _ = summary('1万普通', 'all', schedule=1)
    result['daily']['rebalance_every_session'] = out
    print('daily rebalance', out['cagr_pct'], out['max_drawdown_pct'], 'fees', out['fees_pct_of_start'], 'orders', out['orders'], flush=True)
    result['daily']['churn_from_2024-07'] = churn(first07)
    print('churn', result['daily']['churn_from_2024-07'], flush=True)
    (HERE / 'real_account.json').write_text(json.dumps(result, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written real_account.json')


if __name__ == '__main__':
    main()
