"""How many small stocks to hold, how long, and whether the losses are small ones or rare big ones (declared before running).

Basket: eligible stocks (not ST, listed >= 120 days) in the lowest fifth of 20-session average turnover, ranked at the
close of the decision day; bought equally at the next open (limit-up opens skipped), held to the close of the next
decision day, 0.2% per period for a full round trip; net value starts at 1.

Schedules (whole basket): every 10, 20, 40, 60 sessions, and the last trading day of each month.
Number of names (every 20 sessions): 1, 2, 3, 5, 10 drawn at random from the basket (20 seeds each), and the whole basket.
Three names by a rule (every 20 sessions): the 3 with the lowest 20-session volatility; the 3 with the lowest turnover
among those whose latest announced quarter has revenue and profit growth above zero; the 3 with the lowest turnover.
Guards against big losses (every 20 sessions; whole basket and the low-volatility three):
  MA20  sell everything at the next open after the CSI 2000 closes below its 20-session average; buy again only on
        a decision day on which it is back above.
  STOP  sell everything at the next open after the net value closes 10% below its high since the last purchase; buy
        again on the next decision day.
Windows: first decision 2024-07-01 (monthly: 2024-06-28) and 2024-01-31 (the February 2024 small-stock fall inside).

Per run: annualised return, max drawdown, lowest net value, longest time under water (sessions), and per-period
returns: share of losing periods, small loss (0 to -5%), medium loss (-5% to -10%), big loss (worse than -10%),
big gain (above +10%), arithmetic and geometric mean per period (the gap is what swings cost).
The anchor (user): beat ChiNext on annualised return AND have a shallower max drawdown than ChiNext, same window.
Rules that are not random are also run from four start offsets (0, 5, 10, 15 sessions).
Added after the first results were seen (hindsight, to see whether the growth filter holds beyond three names):
the growth rule with 5 and 10 names.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import industry_rotation as ir  # noqa: E402
from report.strategy_backtest import _metrics  # noqa: E402

h, days, n, growth, avg20 = ir.h, ir.days, ir.n, ir.growth, ir.avg20
COST, CASH = 0.002, 0.015 / 252
iso = lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
indices = json.loads((ir.HISTORY / 'indices.json').read_text(encoding='utf-8'))['indices']
c2000 = np.array([dict((iso(r['trade_date']), r['close']) for r in indices['932000.CSI']['rows'])[d] for d in days])
chinext = np.array([dict((iso(r['trade_date']), r['close']) for r in indices['399006.SZ']['rows'])[d] for d in days])
ma20_2000 = np.full(n, np.nan)
cs = np.cumsum(np.insert(c2000, 0, 0.0))
ma20_2000[19:] = (cs[20:] - cs[:-20]) / 20
seen = ~np.isnan(h['returns'])                      # volatility over traded days only; at least 15 of the last 20
g0 = np.where(seen, growth, 0.0)
s0 = np.concatenate([np.zeros((growth.shape[0], 1)), np.cumsum(seen, axis=1)], axis=1)
s1 = np.concatenate([np.zeros((growth.shape[0], 1)), np.cumsum(g0, axis=1)], axis=1)
s2 = np.concatenate([np.zeros((growth.shape[0], 1)), np.cumsum(g0 * g0, axis=1)], axis=1)
vol20 = np.full(growth.shape, np.nan)
count = s0[:, 20:] - s0[:, :-20]
with np.errstate(all='ignore'):
    mean = (s1[:, 20:] - s1[:, :-20]) / count
    vol20[:, 19:] = np.where(count >= 15, np.sqrt(np.maximum((s2[:, 20:] - s2[:, :-20]) / count - mean ** 2, 0)), np.nan)


def basket(t):
    ok = h['eligible'][:, t] & ~np.isnan(avg20[:, t]) & ~np.isnan(h['close'][:, t])
    q20 = np.quantile(avg20[ok, t], 0.2)
    return np.flatnonzero(ok & (avg20[:, t] <= q20))


def buyable(i, t):
    o, pc = h['open'][i, t + 1], h['pre'][i, t + 1]
    return not (np.isnan(o) or np.isnan(pc) or (o / pc - 1) * 100 >= h['limit'][i] - 0.2 or np.isnan(h['close'][i, t + 1]))


def choose(rule, t, rng):
    members = basket(t)
    base = rule.split(':')[0]
    if base == 'all':
        ranked = list(members)
    elif base == 'random':
        ranked = list(rng.permutation(members))
    elif base == 'lowvol':
        members = members[~np.isnan(vol20[members, t])]
        ranked = list(members[np.argsort(vol20[members, t], kind='stable')])
    elif base == 'coldest':
        ranked = list(members[np.argsort(avg20[members, t], kind='stable')])
    elif base == 'growth':
        sales, profit = ir.latest_growth(t)
        ok = members[(sales[members] > 0) & (profit[members] > 0)]
        ranked = list(ok[np.argsort(avg20[ok, t], kind='stable')])
    else:
        raise ValueError(rule)
    want = None if rule == 'all' else int(rule.split(':')[1]) if ':' in rule else 3
    picked = []
    for i in ranked:
        if buyable(i, t):
            picked.append(i)
            if want and len(picked) == want:
                break
    return picked


def decision_days(schedule, first):
    if schedule == 'month':
        return [t for t in range(first, n - 1) if days[t][:7] != days[t + 1][:7]]
    return list(range(first, n - 1, schedule))


def run(rule, schedule, first, guard=None, seed=0, offset=0):
    rng = np.random.default_rng(seed)
    decisions = decision_days(schedule, first + offset)
    start = decisions[0]
    nav, period_returns = [1.0], []
    for k, t in enumerate(decisions):
        end = decisions[k + 1] if k + 1 < len(decisions) else n - 1
        base = nav[-1]
        members = choose(rule, t, rng)
        if guard == 'ma20' and not (c2000[t] > ma20_2000[t]):
            members = []
        if not members:
            nav += [base * (1 + CASH) ** j for j in range(1, end - t + 1)]
            period_returns.append(nav[-1] / base - 1)
            continue
        value = np.array([h['close'][i, t + 1] / h['open'][i, t + 1] for i in members])
        nav.append(base * (1 - COST / 2) * value.mean())
        high, out = nav[-1], False
        for d in range(t + 2, end + 1):
            if out:
                nav.append(nav[-1] * (1 + CASH))
                continue
            exit_now = (guard == 'ma20' and c2000[d - 1] < ma20_2000[d - 1]) or (guard == 'stop' and nav[-1] < 0.9 * high)
            if exit_now:
                over = np.array([h['open'][i, d] / h['pre'][i, d] if not (np.isnan(h['open'][i, d]) or np.isnan(h['pre'][i, d])) else 1.0
                                 for i in members])
                nav.append(base * (1 - COST / 2) * (value * over).mean() * (1 - COST / 2))
                out = True
                continue
            value = value * (1 + growth[members, d])
            nav.append(base * (1 - COST / 2) * value.mean())
            high = max(high, nav[-1])
        if not out:
            nav[-1] *= 1 - COST / 2
        period_returns.append(nav[-1] / base - 1)
    nav = np.array(nav)
    span = days[start:start + len(nav)]
    assert len(span) == len(nav)
    return nav, span, np.array(period_returns)


def describe(nav, span, periods):
    m = _metrics(nav, span)
    peak = np.maximum.accumulate(nav)
    under, longest = 0, 0
    for v, p in zip(nav, peak):
        under = under + 1 if v < p else 0
        longest = max(longest, under)
    arith = float(periods.mean())
    geo = float(np.prod(1 + periods) ** (1 / len(periods)) - 1)
    return {'cagr_pct': float(m['cagr_pct']), 'max_drawdown_pct': float(m['max_drawdown_pct']), 'lowest_nav': float(nav.min()),
            'longest_underwater_sessions': longest, 'periods': len(periods),
            'losing_share': float((periods < 0).mean()), 'small_loss': int(((periods < 0) & (periods >= -0.05)).sum()),
            'medium_loss': int(((periods < -0.05) & (periods >= -0.10)).sum()), 'big_loss': int((periods < -0.10).sum()),
            'big_gain': int((periods > 0.10).sum()), 'worst_period_pct': float(periods.min() * 100), 'best_period_pct': float(periods.max() * 100),
            'arith_mean_pct': arith * 100, 'geo_mean_pct': geo * 100, 'swing_cost_pct': (arith - geo) * 100}


def chinext_ref(first, schedule):
    decisions = decision_days(schedule, first)
    start = decisions[0]
    span = days[start:]
    nav = chinext[start:] / chinext[start]
    idx = [days.index(days[t]) - start for t in decisions] + [len(span) - 1]
    periods = np.array([nav[idx[k + 1]] / nav[idx[k]] - 1 for k in range(len(idx) - 1)])
    return describe(nav, span, periods)


CONFIGS = {}
for schedule in (10, 20, 40, 60, 'month'):
    CONFIGS[f'整篮子|每{schedule}日换' if schedule != 'month' else '整篮子|每月末换'] = ('all', schedule, None, 1)
for count in (1, 2, 3, 5, 10):
    CONFIGS[f'随机{count}只|每20日换'] = (f'random:{count}', 20, None, 20)
CONFIGS['3只最低波动|每20日换'] = ('lowvol:3', 20, None, 1)
CONFIGS['3只业绩为正里最冷门|每20日换'] = ('growth:3', 20, None, 1)
CONFIGS['3只最冷门|每20日换'] = ('coldest:3', 20, None, 1)
for guard, label in (('ma20', '中证2000跌破20日均线清仓'), ('stop', '净值从高点回撤10%清仓')):
    CONFIGS[f'整篮子|每20日换|{label}'] = ('all', 20, guard, 1)
    CONFIGS[f'3只最低波动|每20日换|{label}'] = ('lowvol:3', 20, guard, 1)
CONFIGS['事后补测|5只业绩为正里最冷门|每20日换'] = ('growth:5', 20, None, 1)
CONFIGS['事后补测|10只业绩为正里最冷门|每20日换'] = ('growth:10', 20, None, 1)


def main():
    result = {'windows': {}}
    for window, first_label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        block = {'chinext': {}, 'configs': {}}
        for schedule in (20, 'month'):
            first = days.index('2024-06-28') if (schedule == 'month' and window == 'from_2024-07') else days.index(first_label)
            block['chinext'][str(schedule)] = chinext_ref(first, schedule)
        ref = block['chinext']['20']
        for name, (rule, schedule, guard, seeds) in CONFIGS.items():
            first = days.index('2024-06-28') if (schedule == 'month' and window == 'from_2024-07') else days.index(first_label)
            anchor = block['chinext']['month' if schedule == 'month' else '20']
            runs = []
            plan = [(seed, 0) for seed in range(seeds)] if seeds > 1 else [(0, off) for off in ((0, 5, 10, 15) if schedule != 'month' else (0,))]
            for seed, offset in plan:
                nav, span, periods = run(rule, schedule, first, guard, seed, offset)
                d = describe(nav, span, periods)
                d['beats_chinext'] = bool(d['cagr_pct'] > anchor['cagr_pct'] and d['max_drawdown_pct'] > anchor['max_drawdown_pct'])
                d['nav_above_0.8'] = bool(d['lowest_nav'] >= 0.8)
                d['drawdown_within_20'] = bool(d['max_drawdown_pct'] >= -20)
                d['drawdown_within_30'] = bool(d['max_drawdown_pct'] >= -30)
                runs.append(d)
            keys = [k for k in runs[0] if isinstance(runs[0][k], (int, float)) and not isinstance(runs[0][k], bool)]
            summary = {k: {'median': round(float(np.median([r[k] for r in runs])), 3), 'p10': round(float(np.percentile([r[k] for r in runs], 10)), 3),
                           'p90': round(float(np.percentile([r[k] for r in runs], 90)), 3), 'worst': round(float(min(r[k] for r in runs)), 3)}
                       for k in keys}
            for flag in ('beats_chinext', 'nav_above_0.8', 'drawdown_within_20', 'drawdown_within_30'):
                summary[flag + '_share'] = sum(r[flag] for r in runs) / len(runs)
            block['configs'][name] = {'runs': len(runs), 'summary': summary, 'all_runs': runs}
            s = summary
            print(window, name, 'cagr', s['cagr_pct']['median'], 'mdd', s['max_drawdown_pct']['median'], 'worst mdd', s['max_drawdown_pct']['worst'],
                  'big losses', s['big_loss']['median'], 'beats ChiNext', s['beats_chinext_share'], 'dd<=20', s['drawdown_within_20_share'],
                  'nav>=0.8', s['nav_above_0.8_share'], flush=True)
        result['windows'][window] = block
        print(window, 'ChiNext', {k: round(v['cagr_pct'], 1) for k, v in block['chinext'].items()},
              {k: round(v['max_drawdown_pct'], 1) for k, v in block['chinext'].items()}, flush=True)
    (HERE / 'small_cap_design.json').write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written small_cap_design.json')


if __name__ == '__main__':
    main()
