"""How often each simulated strategy holds anything at all, next to its average invested share."""
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, load  # noqa: E402
from report.strategy_backtest import daily_choices, mark_edges, signals, simulate  # noqa: E402

h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
s = signals(h)
choices = daily_choices(h, s)
mark_edges(h, choices)
start = next(t for t, c in enumerate(choices) if c is not None and c['stance'] is not None)
out = {'sessions': len(h['days']) - start,
       'offense_days': sum(1 for c in choices[start:] if c is not None and c['stance'] == 'offense')}
for strategy in ('beta_offense', 'live_rule', 'beta', 'alpha'):
    _, _, exposure = simulate(h, choices, strategy, start)
    out[strategy] = {'sessions_holding_share': round(float((exposure > 0.001).mean()), 3),
                     'mean_invested_share': round(float(exposure.mean()), 3)}
Path(__file__).with_name('exposure_days.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
print(json.dumps(out, ensure_ascii=False))
