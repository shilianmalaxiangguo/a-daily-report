"""How much of a result is luck, and what more names cost a small account (declared before running, 2026-10-31,
round eleven).

Pool and execution as in real_account.py for the user's account (main board and ChiNext; the list published after
the decision day's close and traded at the next open; whole lots; names still on the list are kept; limit-up opens
and unaffordable lots passed over; commission 0.025% with a 5-yuan minimum, or no minimum; stamp duty 0.05% on
sales; transfer fee 0.001%). Names held: 3, 5 or 10, equal shares of the cash.
  rule    the coldest names of the pool (the plan), start offsets 0, 5, 10, 15 sessions;
  random  names drawn at random from the pool on each decision day (20 draws, offset 0).
Windows from 2024-07-01 and from 2024-01-31; accounts of 10,000 yuan with the 5-yuan minimum and without it.
Reported: annual return, max drawdown, lowest net value, fees as a share of the starting money; for random, the
spread of annual returns (lowest, 10th percentile, median, 90th percentile, highest), which is the part left to luck.
"""
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import real_account as ra  # noqa: E402

h, days, n, codes = ra.h, ra.days, ra.n, ra.codes
STAR = ('688', '689')


def simulate(account, k, first, offset=0, seed=None):
    start_cash, minimum = ra.ACCOUNTS[account]
    rng = np.random.default_rng(seed) if seed is not None else None
    decisions = set(range(first + offset, n - 1, 20))
    start = min(decisions)
    cash, held, pending, plan_list = start_cash, {}, set(), []
    nav, stats = [1.0], Counter()
    for d in range(start + 1, n):
        t = d - 1
        switch = t in decisions
        if switch:
            pool = [i for i in ra.ranked(t) if not codes[i].startswith(STAR)]
            plan_list = list(rng.permutation(pool)) if rng is not None else pool
            keep = set(plan_list[:k])
            pending |= {i for i in held if i not in keep}
        freed = False
        for i in sorted(pending):
            g = ra.gap(i, d)
            if g is None or g <= -(h['limit'][i] - 0.2):
                continue
            gross = held.pop(i) * h['open'][i, d] / h['pre'][i, d]
            cost = ra.fee(gross, minimum, True)
            cash += gross - cost
            stats['fees'] += cost
            pending.discard(i)
            freed = not switch
        bought = set()
        if plan_list and len(held) < k and (switch or freed):
            for i in plan_list:
                if len(held) >= k:
                    break
                if i in held:
                    continue
                g = ra.gap(i, d)
                if g is None or g >= h['limit'][i] - 0.2:
                    continue
                price = h['open'][i, d]
                budget = cash / (k - len(held))
                shares = np.floor(budget / (price * 100)) * 100
                while shares > 0 and shares * price + ra.fee(shares * price, minimum, False) > budget:
                    shares -= 100
                if shares <= 0:
                    continue
                amount = shares * price
                cost = ra.fee(amount, minimum, False)
                cash -= amount + cost
                stats['fees'] += cost
                held[i] = shares * h['close'][i, d]
                bought.add(i)
        for i in held:
            c, p = h['close'][i, d], h['pre'][i, d]
            if i not in bought and not (np.isnan(c) or np.isnan(p)):
                held[i] *= c / p
        nav.append((cash + sum(held.values())) / start_cash)
    nav = np.array(nav)
    d = ra.profile(nav, days[start:], sorted(decisions), start)
    return {'cagr_pct': round(d['cagr_pct'], 2), 'max_drawdown_pct': round(d['max_drawdown_pct'], 2), 'lowest_nav': round(d['lowest_nav'], 3),
            'fees_pct_of_start': round(stats['fees'] / start_cash * 100, 2)}


def main():
    out = {}
    for window, label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        first = days.index(label)
        for account in ('1万普通', '1万免五'):
            for k in (3, 5, 10):
                rule = [simulate(account, k, first, o) for o in (0, 5, 10, 15)]
                rand = [simulate(account, k, first, 0, seed) for seed in range(20)]
                c = np.array([x['cagr_pct'] for x in rand])
                key = f'{window}|{account}|{k}'
                out[key] = {'rule': rule, 'random': rand,
                            'random_spread': {'min': round(float(c.min()), 1), 'p10': round(float(np.percentile(c, 10)), 1),
                                              'median': round(float(np.median(c)), 1), 'p90': round(float(np.percentile(c, 90)), 1),
                                              'max': round(float(c.max()), 1)}}
                print(key, 'rule', [x['cagr_pct'] for x in rule], 'mdd', [x['max_drawdown_pct'] for x in rule], 'fees', [x['fees_pct_of_start'] for x in rule],
                      '| random', out[key]['random_spread'], 'mdd median', float(np.median([x['max_drawdown_pct'] for x in rand])),
                      'lowest', min(x['lowest_nav'] for x in rand), flush=True)
    (HERE / 'names_count.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written names_count.json')


if __name__ == '__main__':
    main()
