"""Null model: identical execution, costs and slots, but the ten names are drawn at random each day.

Pool on day t = the same filters every list uses (full 20-session window, not ST, listed >= 120 days,
20-session average turnover >= 1e8 yuan, not closed at the limit). 'random' buys from it every day;
'random_offense' only on offense days. 20 seeds each, compared with the frozen strategies, plus an
equal-weight average of all eligible stocks (daily rebalanced, no cost) as a second benchmark.
"""
from copy import copy
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, ROOT, load  # noqa: E402
from report.strategy_backtest import (LIMIT_MARGIN, LIQUIDITY_K, _metrics, daily_choices, mark_edges,  # noqa: E402
                                      signals, simulate)

h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
s = signals(h)
choices = daily_choices(h, s)
mark_edges(h, choices)
start = next(t for t, c in enumerate(choices) if c is not None and c['stance'] is not None)
days = h['days'][start:]
assert days[0] == '2024-03-04' and days[-1] == '2026-10-29'

def keep(m):
    return {k: round(float(m[k]), 2) for k in ('cagr_pct', 'max_drawdown_pct', 'sharpe', 'exposure_pct') if m.get(k) is not None}

result = {}
for name, field, strategy in (('random', 'alpha', 'alpha'), ('random_offense', 'beta', 'beta_offense')):
    runs = []
    for seed in range(20):
        rng = np.random.default_rng(seed)
        mod = []
        for t, c in enumerate(choices):
            if c is None:
                mod.append(None)
                continue
            pool = np.flatnonzero(s['complete'][:, t] & (s['amount'][:, t] >= LIQUIDITY_K)
                                  & (h['returns'][:, t] < h['limit'] - LIMIT_MARGIN))
            c2 = copy(c)
            c2[field] = rng.permutation(pool)[:13]
            mod.append(c2)
        curve, trades, exposure = simulate(h, mod, strategy, start)
        runs.append(keep(_metrics(curve, days, exposure, trades)))
    result[name] = {'runs': runs, **{k: {'median': round(float(np.median([r[k] for r in runs])), 2),
                                         'min': round(float(min(r[k] for r in runs)), 2),
                                         'max': round(float(max(r[k] for r in runs)), 2)}
                                     for k in ('cagr_pct', 'max_drawdown_pct', 'sharpe', 'exposure_pct')}}
r = np.where(h['eligible'] & ~np.isnan(h['returns']), h['returns'], np.nan)
eq = np.nanmean(r, axis=0)[start + 1:] / 100
curve = np.concatenate([[1.0], np.cumprod(1 + eq)])
result['equal_weight_daily'] = keep(_metrics(curve, days))
frozen = json.load(open(ROOT / 'snapshots/replay/2026-10-29_replay.json', encoding='utf-8'))['data']['reading_backtest']
result['frozen'] = {k: keep(v['full']) for k, v in frozen['stats'].items()}
Path(__file__).with_name('random_null.json').write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
for k, v in result.items():
    if k in ('random', 'random_offense'):
        print(k, {m: v[m] for m in ('cagr_pct', 'max_drawdown_pct', 'sharpe', 'exposure_pct')})
    else:
        print(k, v)
