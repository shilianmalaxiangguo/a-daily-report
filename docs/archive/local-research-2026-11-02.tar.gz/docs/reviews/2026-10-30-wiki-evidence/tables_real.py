"""Prints the real-account tables used in the Wiki (round six) from real_account.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'real_account.json').read_text(encoding='utf-8'))
BOARD = {'all': '全部板块', 'no_star': '不含科创板', 'main': '只做主板'}
WINDOW = {'from_2024-07': '2024-07-01起', 'from_2024-01-31': '2024-01-31起（含2024年2月小盘大跌）'}


def pct(v, digits=1):
    return '—' if v is None else f"{v:+.{digits}f}%"


def spread(values, fmt=pct):
    values = sorted(values)
    k = len(values)
    mid = values[k // 2] if k % 2 else (values[k // 2 - 1] + values[k // 2]) / 2
    return f"{fmt(mid)}（{fmt(values[0])}至{fmt(values[-1])}）"


g = r['grid']
base = g['1万普通|all']
print('表21 按真实账户照做执行计划（起点2024-07-01，每20个交易日；名单在换手日收盘后出，下一个交易日开盘成交）\n')
print('| 账户与可买板块 | 年化 | 最大回撤 | 净值最低 | 期末净值 | 费用合计占本金 | 平均闲置现金 | 每次换股留下几只 | 用到备选 | 一手钱不够而跳过 | 跑赢创业板指 |')
print('|---|---|---|---|---|---|---|---|---|---|---|')
print(f"| 对照：一直持有创业板指 | {pct(base['chinext_cagr_pct'])} | {pct(base['chinext_max_drawdown_pct'])} | — | — | — | — | — | — | — | — |")
for key, label in (('1万普通|all', '1万元，每笔最低5元，全部板块'), ('1万普通|no_star', '1万元，每笔最低5元，不含科创板'),
                   ('1万普通|main', '1万元，每笔最低5元，只做主板'), ('1万免五|all', '1万元，免五，全部板块'),
                   ('1万免五|main', '1万元，免五，只做主板'), ('10万普通|all', '10万元，每笔最低5元，全部板块'),
                   ('10万普通|main', '10万元，每笔最低5元，只做主板'), ('1万普通|all|滑点0.2%', '1万元，每笔最低5元，全部板块，每笔再吃0.2%滑点')):
    x = g[key]
    print(f"| {label} | {pct(x['cagr_pct'])} | {pct(x['max_drawdown_pct'])} | {x['lowest_nav']:.2f} | {x['final_nav']:.2f} | {x['fees_pct_of_start']:.1f}% | "
          f"{x['idle_cash_pct']:.1f}% | {x['kept_per_switch']:.1f} | {x['backups_used']}次 | {x['skip_one_lot_too_dear']}次 | {'是' if x['beats_chinext'] else '否'} |")

print('\n表22 换四个起步日（1万元，每笔最低5元）\n')
print('| 起点 | 可买板块 | 年化中位（最低至最高） | 最大回撤中位（最差） | 净值最低（最差） | 跑赢创业板指 | 理想回测年化中位（同起步日） |')
print('|---|---|---|---|---|---|---|')
for key, runs in r['offsets'].items():
    window, board = key.split('|')
    ideal = [x['idealised_cagr_pct'] for x in runs if x['idealised_cagr_pct'] is not None]
    worst_dd = min(x['max_drawdown_pct'] for x in runs)
    dd = sorted(x['max_drawdown_pct'] for x in runs)
    print(f"| {WINDOW[window]} | {BOARD[board]} | {spread([x['cagr_pct'] for x in runs])} | {pct((dd[1] + dd[2]) / 2)}（{pct(worst_dd)}） | "
          f"{min(x['lowest_nav'] for x in runs):.2f} | {sum(x['beats_chinext'] for x in runs)}/4 | {spread(ideal) if ideal else '—'} |")

print('\n表23 净值底线：跌破就全部卖出、停下（1万元，每笔最低5元，四个起步日）\n')
print('| 起点 | 可买板块 | 底线 | 触发次数 | 触发日 | 期末净值（四个起步日） |')
print('|---|---|---|---|---|---|')
for key, stops in r['floors'].items():
    window, board, floor = key.split('|')
    hit = [s for s in stops if s['stopped_on']]
    print(f"| {WINDOW[window]} | {BOARD[board]} | {floor} | {len(hit)}/4 | {'、'.join(s['stopped_on'] for s in hit) or '—'} | "
          f"{'、'.join(f'{s['final_nav']:.2f}' for s in stops)} |")

print('\n表24 多久换一次（1万元，每笔最低5元，2024-07-01起四个起步日）\n')
print('| 换股间隔 | 可买板块 | 年化中位（最低至最高） | 最大回撤中位 | 费用合计占本金（中位） | 跑赢创业板指 |')
print('|---|---|---|---|---|---|')
for key, runs in r['schedules'].items():
    schedule, board = key.split('|')
    dd = sorted(x['max_drawdown_pct'] for x in runs)
    fees = sorted(x['fees_pct_of_start'] for x in runs)
    print(f"| 每{schedule}个交易日 | {BOARD[board]} | {spread([x['cagr_pct'] for x in runs])} | {pct((dd[1] + dd[2]) / 2)} | "
          f"{(fees[1] + fees[2]) / 2:.1f}% | {sum(x['beats_chinext'] for x in runs)}/4 |")

d = r['daily']
x, c = d['rebalance_every_session'], d['churn_from_2024-07']
print('\n表25 如果每天按当天的名单换（1万元，每笔最低5元，2024-07-01起）\n')
print('| 做法 | 年化 | 最大回撤 | 买卖笔数 | 费用合计占本金 |')
print('|---|---|---|---|---|')
print(f"| 每20个交易日换（执行计划） | {pct(base['cagr_pct'])} | {pct(base['max_drawdown_pct'])} | {base['orders']} | {base['fees_pct_of_start']:.1f}% |")
print(f"| 每天按当天名单换 | {pct(x['cagr_pct'])} | {pct(x['max_drawdown_pct'])} | {x['orders']} | {x['fees_pct_of_start']:.1f}% |")
print(f"\n名单若每天重算：平均每天有{c['mean_changed_per_session']:.2f}只和前一天不同，{c['share_of_sessions_with_a_change'] * 100:.0f}%的交易日至少变一只；"
      f"和这一期定下的名单相比，平均有{c['mean_differing_from_period_list']:.2f}只不同。")
print('\n买过的股票所属行业（1万元、全部板块、起点2024-07-01，按买入次数）：'
      + '、'.join(f'{k}{v}次' for k, v in base['industries'].items()))
print(f"买入价中位数{base['price_median']:.2f}元，一手约{base['price_median'] * 100:,.0f}元。")
