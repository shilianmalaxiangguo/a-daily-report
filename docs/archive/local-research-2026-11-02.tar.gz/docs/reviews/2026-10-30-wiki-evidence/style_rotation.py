"""Style switching with index funds: which plain rules would have stepped aside in July-October 2026, and at what cost.

Declared before running. Indices stand in for their exchange-traded funds. A signal is read at the close and
traded at the next open; switching costs 0.1% on each side; cash earns 1.5% a year. All variants are reported.

A  Trend on one index: hold it while its close is above its N-session average, otherwise cash.
   Indices: CSI All Share, ChiNext, STAR 50, CSI 300, CSI 2000, CSI Dividend; N in 20, 60, 120.  (18 variants)
B  Momentum rotation among ChiNext, STAR 50, CSI 300, CSI 2000, CSI Dividend: every K sessions hold the one with
   the highest M-session return if that return is positive, otherwise cash; K in 5, 20; M in 20, 60. Each also
   with the extra condition that the chosen index is above its 60-session average.  (8 variants)
C  Two-index rotation, weekly (K = 5): CSI 300 vs CSI 2000, and ChiNext vs CSI Dividend; M in 20, 60.  (4 variants)
H  Hindsight only (the data were seen before this rule was written): leave the CSI All Share for cash while the
   five large CSI 300 / SSE 50 funds lost more than 10% of their value to net redemptions over 20 sessions.

Windows: from 2024-09-02 (the user's window) and from 2024-07-01 (first day every average exists) to 2026-10-29.
Episodes: 2024-09-18..2024-10-08, 2025-04-01..2025-04-30, 2026-03-02..2026-03-31, 2026-07-01..2026-10-29.
The worst loss from the starting value is reported for a 10,000-yuan account starting on 2024-09-02.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from wiki_evidence import HISTORY, ROOT  # noqa: E402

sys.path.insert(0, str(ROOT / 'scripts'))
from report.strategy_backtest import _metrics  # noqa: E402

COST, CASH = 0.001, 0.015 / 252
iso = lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
bench = json.loads((HISTORY / 'benchmark.json').read_text(encoding='utf-8'))['rows']
indices = json.loads((HISTORY / 'indices.json').read_text(encoding='utf-8'))['indices']
NAMES = {'000985.CSI': '中证全指', '399006.SZ': '创业板指', '000688.SH': '科创50', '000300.SH': '沪深300',
         '932000.CSI': '中证2000', '000922.CSI': '中证红利'}
raw = {'000985.CSI': {iso(str(r['trade_date'])): r for r in bench}}
raw.update({code: {iso(r['trade_date']): r for r in indices[code]['rows']} for code in NAMES if code != '000985.CSI'})
days = sorted(d for d in raw['000985.CSI'] if '2024-01-02' <= d <= '2026-10-29')
for code in NAMES:
    assert all(d in raw[code] for d in days), code
n = len(days)
px = {code: {k: np.array([float(raw[code][d][k]) for d in days]) for k in ('open', 'close', 'pre_close')} for code in NAMES}


def moving_average(x, window):
    out = np.full(n, np.nan)
    c = np.cumsum(np.insert(x, 0, 0.0))
    out[window - 1:] = (c[window:] - c[:-window]) / window
    return out


def past_return(x, window):
    out = np.full(n, np.nan)
    out[window:] = x[window:] / x[:-window] - 1
    return out


def simulate(target):
    """target[t] = index code (or None for cash) decided at the close of t; traded at the open of t+1."""
    daily = np.zeros(n)
    held = None
    for t in range(1, n):
        want = target[t - 1]
        if want == held:
            daily[t] = CASH if held is None else px[held]['close'][t] / px[held]['pre_close'][t] - 1
            continue
        value = 1.0
        if held is not None:                     # overnight move, then sell at the open
            value *= px[held]['open'][t] / px[held]['pre_close'][t] * (1 - COST)
        if want is not None:                     # buy at the open, hold to the close
            value *= (1 - COST) * px[want]['close'][t] / px[want]['open'][t]
        else:
            value *= 1 + CASH
        daily[t] = value - 1
        held = want
    return daily


def evaluate(daily, target, first):
    span = days[first:]
    curve = np.concatenate([[1.0], np.cumprod(1 + daily[first + 1:])])
    out = {k: round(float(v), 2) for k, v in _metrics(curve, span).items() if k in ('cagr_pct', 'max_drawdown_pct', 'sharpe', 'total_pct')}
    out['worst_from_start_pct'] = round(float((curve.min() - 1) * 100), 2)
    out['switches'] = int(sum(target[t] != target[t - 1] for t in range(first + 1, n)))
    out['invested_pct'] = round(float(np.mean([target[t] is not None for t in range(first, n)]) * 100), 1)
    return out


def episode(daily, a, b):
    i, j = days.index(a), days.index(b)
    return round(float((np.prod(1 + daily[i + 1:j + 1]) - 1) * 100), 2)


def main():
    EPISODES = {'2024-09反弹': ('2024-09-18', '2024-10-08'), '2025-04关税冲击': ('2025-04-01', '2025-04-30'),
                '2026-03下跌': ('2026-03-02', '2026-03-31'), '2026-07起大跌': ('2026-07-01', '2026-10-29')}
    variants = {}
    for code in NAMES:
        for window in (20, 60, 120):
            ma = moving_average(px[code]['close'], window)
            variants[f'A|{NAMES[code]}|均线{window}'] = [code if not np.isnan(ma[t]) and px[code]['close'][t] > ma[t] else None
                                                          for t in range(n)]
        variants[f'持有|{NAMES[code]}'] = [code] * n
    pool = ['399006.SZ', '000688.SH', '000300.SH', '932000.CSI', '000922.CSI']
    ma60 = {code: moving_average(px[code]['close'], 60) for code in NAMES}
    for k in (5, 20):
        for m in (20, 60):
            ret = {code: past_return(px[code]['close'], m) for code in pool}
            for filtered in (False, True):
                target, current = [], None
                for t in range(n):
                    if t % k == 0 and t >= max(m, 60):
                        best = max(pool, key=lambda c: ret[c][t])
                        ok = ret[best][t] > 0 and (not filtered or px[best]['close'][t] > ma60[best][t])
                        current = best if ok else None
                    target.append(current)
                variants[f"B|五指数轮动|每{k}日|看{m}日{'|且在60日均线上' if filtered else ''}"] = target
    for pair, label in ((('000300.SH', '932000.CSI'), '沪深300对中证2000'), (('399006.SZ', '000922.CSI'), '创业板指对中证红利')):
        for m in (20, 60):
            ret = {code: past_return(px[code]['close'], m) for code in pair}
            target, current = [], None
            for t in range(n):
                if t % 5 == 0 and t >= m:
                    best = max(pair, key=lambda c: ret[c][t])
                    current = best if ret[best][t] > 0 else None
                target.append(current)
            variants[f'C|{label}|看{m}日'] = target

    flows = json.loads((HISTORY / 'etf_flows.json').read_text(encoding='utf-8'))['etfs']
    FIVE = ['510300.SH', '510310.SH', '510330.SH', '159919.SZ', '510050.SH']
    value_by_day, flow_by_day = np.zeros(n), np.zeros(n)
    for code in FIVE:
        share = {iso(r['trade_date']): r['fd_share'] * 1e4 for r in flows[code]['shares']}
        close = {iso(r['trade_date']): r['close'] for r in flows[code]['prices']}
        last = None
        for t, d in enumerate(days):
            s = share.get(d, last)
            if s is None or d not in close:
                continue
            value_by_day[t] += s * close[d]
            if last is not None and t > 0:
                change = s - last
                if abs(change / last) > 0.4 and abs(close[d] / close.get(days[t - 1], close[d]) - 1) < 0.02:
                    change = 0.0                      # 2024-09-20 style unit break, not a flow
                flow_by_day[t] += change * close[d]
            last = s
    flow20 = np.array([flow_by_day[max(0, t - 19):t + 1].sum() for t in range(n)])
    ratio = np.where(value_by_day > 0, flow20 / value_by_day, 0.0)
    variants['H|事后看|国家队ETF20日净赎回超过10%就空仓|否则中证全指'] = [None if ratio[t] < -0.10 else '000985.CSI' for t in range(n)]

    result = {'cash_yield_pct': 1.5, 'cost_each_side_pct': COST * 100, 'variants': {},
              'flows': {'months_over_10pct': sorted({days[t][:7] for t in range(n) if ratio[t] < -0.10}),
                        'monthly_net_yi': {}}}
    for t in range(n):
        month = days[t][:7]
        result['flows']['monthly_net_yi'][month] = round(result['flows']['monthly_net_yi'].get(month, 0) + flow_by_day[t] / 1e8, 1)
    for name, target in variants.items():
        daily = simulate(target)
        result['variants'][name] = {'from_2024-09-02': evaluate(daily, target, days.index('2024-09-02')),
                                    'from_2024-07-01': evaluate(daily, target, days.index('2024-07-01')),
                                    'episodes': {k: episode(daily, a, b) for k, (a, b) in EPISODES.items()},
                                    'holding_on_2026-06-30': NAMES.get(target[days.index('2026-06-30')]) or '现金',
                                    'holding_on_2026-10-29': NAMES.get(target[-1]) or '现金'}
    close, ma = px['399006.SZ']['close'], moving_average(px['399006.SZ']['close'], 60)
    state = ['持有' if not np.isnan(ma[t]) and close[t] > ma[t] else '空着' for t in range(n)]
    result['chinext_ma60_since_2025-12'] = {
        'changes': [{'decided_at_close': days[t], 'to': state[t], 'close': round(float(close[t]), 1), 'ma60': round(float(ma[t]), 1),
                     'trade_at_open': days[t + 1] if t + 1 < n else None}
                    for t in range(1, n) if state[t] != state[t - 1] and days[t] >= '2025-12-01'],
        'latest': {'date': days[-1], 'state': state[-1], 'close': round(float(close[-1]), 1), 'ma60': round(float(ma[-1]), 1),
                   'gap_pct': round(float((close[-1] / ma[-1] - 1) * 100), 1)}}
    out = HERE / 'style_rotation.json'
    out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written', out.name, len(variants), 'variants')


if __name__ == '__main__':
    main()
