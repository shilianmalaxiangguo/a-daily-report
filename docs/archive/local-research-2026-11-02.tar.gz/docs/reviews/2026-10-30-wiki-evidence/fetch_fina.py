"""Quarterly growth indicators for every listed company with their announcement dates (point-in-time use only)."""
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'scripts'))
from market_data.tushare_client import create_tushare_pro_api  # noqa: E402
from report.market_returns import _pages  # noqa: E402

PERIODS = ['20230630', '20230930', '20231231', '20240331', '20240630', '20240930', '20241231', '20250331', '20250630',
           '20250930', '20251231', '20260331', '20260630', '20260930']
pro = create_tushare_pro_api(timeout_seconds=120)
out = {'retrieved_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(), 'source': 'tushare.fina_indicator_vip', 'periods': {}}
for period in PERIODS:
    rows = _pages(pro, 'fina_indicator_vip', period=period, fields='ts_code,ann_date,end_date,q_profit_yoy,q_sales_yoy,netprofit_yoy')
    assert all(r.get('end_date') == period for r in rows), period
    out['periods'][period] = rows
    print(period, len(rows), 'distinct codes', len({r['ts_code'] for r in rows}), 'ann range',
          min((r['ann_date'] for r in rows if r.get('ann_date')), default=None), max((r['ann_date'] for r in rows if r.get('ann_date')), default=None))
target = ROOT / '.generated/backtest-history/fina_indicator.json'
target.write_text(json.dumps(out, ensure_ascii=False), encoding='utf-8')
print('written', target.relative_to(ROOT))
