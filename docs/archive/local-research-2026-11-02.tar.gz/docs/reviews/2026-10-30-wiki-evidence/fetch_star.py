"""Fetch STAR market index bars and the list of listed ETFs whose name mentions 科创 (own file; other caches untouched)."""
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'scripts'))
from market_data.tushare_client import create_tushare_pro_api  # noqa: E402
from report.market_returns import _pages  # noqa: E402

INDICES = {'000688.SH': '科创50', '000698.SH': '科创100', '000699.SH': '科创200', '000680.SH': '科创综指'}
start, end = sys.argv[2], sys.argv[3]
pro = create_tushare_pro_api(timeout_seconds=60)
out = {'retrieved_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(), 'start': start, 'end': end,
       'source': 'tushare.index_daily / tushare.fund_basic', 'indices': {}, 'etfs': []}
for code, name in INDICES.items():
    try:
        rows = _pages(pro, 'index_daily', ts_code=code, start_date=start.replace('-', ''), end_date=end.replace('-', ''),
                      fields='ts_code,trade_date,open,close,pre_close')
    except Exception as error:
        print(code, name, 'FAILED', type(error).__name__, str(error)[:120])
        continue
    rows = sorted(rows, key=lambda r: r['trade_date'])
    assert [r['trade_date'] for r in rows] == sorted({r['trade_date'] for r in rows}), code
    out['indices'][code] = {'name': name, 'rows': rows}
    print(code, name, len(rows), rows[0]['trade_date'] if rows else None, rows[-1]['trade_date'] if rows else None)
try:
    funds = _pages(pro, 'fund_basic', market='E', fields='ts_code,name,list_date,benchmark,status')
    out['etfs'] = sorted((f for f in funds if '科创' in str(f.get('name') or '') and str(f.get('ts_code', '')).endswith(('.SH', '.SZ'))),
                         key=lambda f: str(f.get('list_date') or ''))
    print('ETFs with 科创 in the name:', len(out['etfs']))
except Exception as error:
    print('fund_basic FAILED', type(error).__name__, str(error)[:120])
target = ROOT / '.generated/backtest-history/star_indices.json'
target.write_text(json.dumps(out, ensure_ascii=False, default=str), encoding='utf-8')
print('written', target.relative_to(ROOT))
