"""Checks of the comparison indices and of the market claims in two outside articles (declared before running).

C1 Indices over the backtest window (2024-03-04..2026-10-29, first session as the base) and from 2024-01-02:
   annualised return, max drawdown, Sharpe (same convention as the backtest), calendar-year returns.
   The equal-weight average of eligible stocks (no ST, listed >= 120 days, daily rebalanced, no cost) from both starts.
C2 Article claims that market data can check:
   - The Economist (2026-10-28): ChiNext "lost about 40% in four months"; CSI 300 "fell by 20% from its June peak"
     in October; CSI 300 "back above 4,000".
   - Blog post: "14 consecutive weekly declines" (weekly close = last close of the calendar week); "5000+ stocks
     down every day" (all SH/SZ A-shares in the cache, ST included, counted on each of the last 60 sessions).
C3 "Small and poor": daily equal-weight returns of ST stocks, of non-ST stocks in the lowest and highest fifth of
   20-session average turnover (a proxy for size, formed with data up to the previous session), and of all
   non-ST stocks; whole window, by year, and 2026-07-28..2026-10-29. No costs.
C4 Turnover regimes ("no volume: leave; healthy volume: come back; boiling volume: leave"): total turnover of all
   SH/SZ A-shares each day, ranked inside the trailing 120 sessions. Low < 30th percentile, high >= 90th,
   middle otherwise. Next-5-session close-to-close return of the CSI All Share and of the equal-weight average after
   each regime, entered at the next open (date-level Newey-West t, lag 5); and a timing rule that is invested from
   the next open after a middle-regime day and leaves at the next open after a low or high one, no cost, versus
   holding. Index trades use its own open; the equal-weight average uses the average open-to-close, open-to-previous-
   close and close-to-close moves of eligible stocks.
C5 Dividend defence: CSI Dividend against the CSI All Share - window statistics, beta of daily returns, average
   return on days the CSI All Share fell more than 1%, and 2026-07-28..2026-10-29.
"""
import json
from datetime import date
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, HISTORY, load, newey_west_t  # noqa: E402
from report.strategy_backtest import _iso, _metrics  # noqa: E402

h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
days, n = h['days'], len(h['days'])
indices = json.loads((HISTORY / 'indices.json').read_text(encoding='utf-8'))
iso = lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
series = {'000985.CSI': ('中证全指', {d: c for d, c in zip(days, h['m_close'])})}
for code, item in indices['indices'].items():
    series[code] = (item['name'], {iso(r['trade_date']): float(r['close']) for r in item['rows']})
for code, (_, closes) in series.items():
    assert set(closes) == set(days), code
start, design = days.index('2024-03-04'), days.index('2026-07-28')


def keep(m):
    return {k: round(float(m[k]), 2) for k in ('total_pct', 'cagr_pct', 'max_drawdown_pct', 'sharpe') if m.get(k) is not None}


def years_of(curve, span):
    out = {}
    for year in ('2024', '2025', '2026'):
        idx = [k for k, d in enumerate(span) if d.startswith(year)]
        first = idx[0] - 1 if idx[0] > 0 else idx[0]
        out[year] = round(float((curve[idx[-1]] / curve[first] - 1) * 100), 1)
    return out


result = {'inputs_sha256': h['inputs_sha256'], 'indices_retrieved_at': indices['retrieved_at'], 'C1': {}, 'C2': {}, 'C3': {},
          'C4': {}, 'C5': {}}
eligible_r = np.where(h['eligible'] & ~np.isnan(h['returns']), h['returns'], np.nan)
eq_daily = np.nanmean(eligible_r, axis=0) / 100
for label, s0 in (('from_2024-03-04', start), ('from_2024-01-02', 0)):
    span = days[s0:]
    block = {}
    for code, (name, closes) in series.items():
        curve = np.array([closes[d] for d in span]) / closes[span[0]]
        block[code] = {'name': name, **keep(_metrics(curve, span)), 'years': years_of(curve, span)}
    curve = np.concatenate([[1.0], np.cumprod(1 + eq_daily[s0 + 1:])])
    block['equal_weight'] = {'name': '等权平均（理论参照）', **keep(_metrics(curve, span)), 'years': years_of(curve, span)}
    result['C1'][label] = block

# C2 article claims
cl = {code: closes for code, (_, closes) in series.items()}
upto = [d for d in days if d <= '2026-10-28']
chinext = cl['399006.SZ']
year = [d for d in upto if d >= '2026-01-01']
peak_day = max(year, key=lambda d: chinext[d])
low_day = min([d for d in upto if d >= peak_day], key=lambda d: chinext[d])
four_back = max(d for d in upto if d <= '2026-06-28')
result['C2']['chinext_four_months'] = {
    'year_peak': [peak_day, chinext[peak_day]], 'low_after_peak': [low_day, chinext[low_day]],
    'peak_to_low_pct': round((chinext[low_day] / chinext[peak_day] - 1) * 100, 1),
    'peak_to_10-28_pct': round((chinext[upto[-1]] / chinext[peak_day] - 1) * 100, 1),
    'four_months': [four_back, upto[-1], round((chinext[upto[-1]] / chinext[four_back] - 1) * 100, 1)],
    'close_10-28': chinext[upto[-1]]}
hs300 = cl['000300.SH']
june = [d for d in days if d.startswith('2026-06')]
june_peak = max(june, key=lambda d: hs300[d])
october = [d for d in days if d.startswith('2026-10')]
oct_low = min(october, key=lambda d: hs300[d])
result['C2']['csi300_bear'] = {'june_peak': [june_peak, hs300[june_peak]], 'october_low': [oct_low, hs300[oct_low]],
                               'drawdown_pct': round((hs300[oct_low] / hs300[june_peak] - 1) * 100, 1),
                               'year_peak': max(((d, hs300[d]) for d in days if d.startswith('2026')), key=lambda x: x[1]),
                               'closes_10-26_to_10-29': {d: hs300[d] for d in days if '2026-10-26' <= d <= '2026-10-29'}}
weekly = {}
for code, (name, closes) in series.items():
    weeks = {}
    for d in days:
        key = date.fromisoformat(d).isocalendar()[:2]
        weeks[key] = d                                      # last session of each calendar week
    ends = [weeks[k] for k in sorted(weeks)]
    changes = [(ends[k], closes[ends[k]] / closes[ends[k - 1]] - 1) for k in range(1, len(ends))]
    streak = 0
    for _, change in reversed(changes):
        if change < 0:
            streak += 1
        else:
            break
    complete = [c for c in changes if c[0] <= '2026-10-23']
    streak_complete = 0
    for _, change in reversed(complete):
        if change < 0:
            streak_complete += 1
        else:
            break
    weekly[code] = {'name': name, 'streak_incl_week_to_10-29': streak, 'streak_to_10-23': streak_complete,
                    'last_weeks': [(d, round(c * 100, 2)) for d, c in changes[-16:]]}
result['C2']['weekly_streaks'] = weekly
valid = ~np.isnan(h['returns'])
down = (h['returns'] < 0) & valid
last60 = list(range(n - 60, n))
counts = [(days[t], int(down[:, t].sum()), int(valid[:, t].sum())) for t in last60]
result['C2']['decliners_last60'] = {'sessions': 60, 'days_over_5000': sum(c[1] > 5000 for c in counts),
                                    'days_over_4000': sum(c[1] > 4000 for c in counts),
                                    'median_decliners': int(np.median([c[1] for c in counts])),
                                    'median_universe': int(np.median([c[2] for c in counts])),
                                    'over_5000_dates': [c[0] for c in counts if c[1] > 5000]}

# C3 small and poor
amount = h['amount']
avg20 = np.full(amount.shape, np.nan)
filled = np.where(np.isnan(amount), 0, amount)
cs = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(filled, axis=1)], axis=1)
cnt = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(~np.isnan(amount), axis=1)], axis=1)
avg20[:, 20:] = ((cs[:, 20:-1] - cs[:, :-21]) / np.maximum(cnt[:, 20:-1] - cnt[:, :-21], 1))   # sessions t-20..t-1
group_daily = {k: np.full(n, np.nan) for k in ('st', 'small', 'large', 'non_st')}
for t in range(21, n):
    r = h['returns'][:, t]
    ok = h['eligible'][:, t] & ~np.isnan(r) & ~np.isnan(avg20[:, t])
    if ok.sum() < 500:
        continue
    q20, q80 = np.quantile(avg20[ok, t], [0.2, 0.8])
    group_daily['non_st'][t] = np.mean(r[ok]) / 100
    group_daily['small'][t] = np.mean(r[ok & (avg20[:, t] <= q20)]) / 100
    group_daily['large'][t] = np.mean(r[ok & (avg20[:, t] >= q80)]) / 100
names_rows = json.loads((HISTORY / 'namechange.json').read_text(encoding='utf-8'))['rows']
code_index = {c: i for i, c in enumerate(h['codes'])}
st_mask = np.zeros(h['returns'].shape, dtype=bool)
for row in names_rows:
    i = code_index.get(row.get('ts_code'))
    name = str(row.get('name') or '').upper()
    if i is None or not (name.lstrip('S*').startswith('ST') or name.startswith(('ST', '*ST', 'SST', 'S*ST'))):
        continue                                       # same ST test as load_history
    s_ = _iso(row.get('start_date') or '00000000')
    e_ = _iso(row.get('end_date')) if row.get('end_date') else '9999-12-31'
    for j, d in enumerate(days):
        if s_ <= d <= e_:
            st_mask[i, j] = True
for t in range(21, n):
    r = h['returns'][:, t]
    m = st_mask[:, t] & ~np.isnan(r)
    if m.sum() >= 20:
        group_daily['st'][t] = np.mean(r[m]) / 100
for label, s0, s1 in (('window', start, n - 1), ('design_2026-07-28', design, n - 1)):
    block = {}
    for k, label_cn in (('st', 'ST股'), ('small', '成交额最小五分之一'), ('large', '成交额最大五分之一'), ('non_st', '全部非ST')):
        seq = group_daily[k][s0 + 1:s1 + 1]
        seq = np.where(np.isnan(seq), 0, seq)
        curve = np.concatenate([[1.0], np.cumprod(1 + seq)])
        span = days[s0:s1 + 1]
        block[k] = {'name': label_cn, **keep(_metrics(curve, span)),
                    **({'years': years_of(curve, span)} if label == 'window' else {})}
    result['C3'][label] = block
result['C3']['st_count_median'] = int(np.median(st_mask[:, start:].sum(axis=0)))

# C4 turnover regimes
total = np.nansum(amount, axis=0)
pct = np.full(n, np.nan)
for t in range(119, n):
    window = total[t - 119:t + 1]
    pct[t] = (window < total[t]).mean() + 0.5 * (window == total[t]).mean()
regime = np.where(np.isnan(pct), None, np.where(pct < 0.3, 'low', np.where(pct >= 0.9, 'high', 'mid')))
m_ret, eq = h['m_ret'] / 100, eq_daily
with np.errstate(all='ignore'):
    ok_open = h['eligible'] & ~np.isnan(h['open']) & ~np.isnan(h['close']) & ~np.isnan(h['pre'])
    moves = {'index': {'full': m_ret, 'intraday': h['m_close'] / h['m_open'] - 1, 'overnight': h['m_open'] / h['m_pre'] - 1},
             'equal_weight': {'full': eq,
                              'intraday': np.nanmean(np.where(ok_open, h['close'] / h['open'] - 1, np.nan), axis=0),
                              'overnight': np.nanmean(np.where(ok_open, h['open'] / h['pre'] - 1, np.nan), axis=0)}}
fwd = {}
for name, mv in moves.items():
    f = np.full(n, np.nan)
    for t in range(n - 5):
        f[t] = ((1 + mv['intraday'][t + 1]) * np.prod(1 + mv['full'][t + 2:t + 6]) - 1) * 100   # in at t+1 open, out at t+5 close
    fwd[name] = f
block = {}
for g in ('low', 'mid', 'high'):
    ts = [t for t in range(start, n - 5) if regime[t] == g]
    block[g] = {'days': len(ts)}
    for name in ('index', 'equal_weight'):
        vals = [fwd[name][t] for t in range(start, n - 5) if regime[t] == g]
        per = np.array([fwd[name][t] if regime[t] == g else np.nan for t in range(start, n - 5)])
        block[g][name] = {'mean_pct': round(float(np.mean(vals)), 3), 'nw_t': round(newey_west_t(per[~np.isnan(per)], 5), 2)}
result['C4']['forward_5'] = block
timing = {}
for name, mv in moves.items():
    hold, inside = [], False
    for t in range(start + 1, n):
        want = regime[t - 1] == 'mid'                      # decided after the close of t-1, traded at the open of t
        if want and inside:
            hold.append(mv['full'][t])
        elif want:
            hold.append(mv['intraday'][t])
        elif inside:
            hold.append(mv['overnight'][t])
        else:
            hold.append(0.0)
        inside = want
    hold = np.array(hold)
    base = mv['full'][start + 1:n]
    span = days[start:]
    timing[name] = {'timed': keep(_metrics(np.concatenate([[1.0], np.cumprod(1 + hold)]), span)),
                    'held': keep(_metrics(np.concatenate([[1.0], np.cumprod(1 + base)]), span)),
                    'in_market_share': round(float(np.mean([regime[t - 1] == 'mid' for t in range(start + 1, n)])), 3),
                    'switches': int(sum(1 for t in range(start + 2, n) if (regime[t - 1] == 'mid') != (regime[t - 2] == 'mid')))}
result['C4']['timing'] = timing
result['C4']['regime_share'] = {g: round(float(np.mean([regime[t] == g for t in range(start, n)])), 3) for g in ('low', 'mid', 'high')}
result['C4']['latest'] = {d: regime[days.index(d)] for d in days[-10:]}

# C5 dividend defence
div = np.array([cl['000922.CSI'][d] for d in days])
div_ret = np.concatenate([[np.nan], div[1:] / div[:-1] - 1])
x, y = m_ret[start + 1:], div_ret[start + 1:]
beta = float(np.cov(x, y)[0, 1] / np.var(x, ddof=1))
big_down = x < -0.01
result['C5'] = {'beta_to_csi_all': round(beta, 2), 'big_down_days': int(big_down.sum()),
                'div_on_big_down_pct': round(float(np.mean(y[big_down]) * 100), 2),
                'csi_all_on_big_down_pct': round(float(np.mean(x[big_down]) * 100), 2),
                'design_period': {k: round((cl[k]['2026-10-29'] / cl[k]['2026-07-27'] - 1) * 100, 1)
                                  for k in ('000922.CSI', '000985.CSI', '399006.SZ', '000688.SH', '932000.CSI')}}
out = Path(__file__).with_name('market_checks.json')
out.write_text(json.dumps(result, ensure_ascii=False, indent=1, default=str), encoding='utf-8')
print('written', out.name)
