"""Does picking stocks add anything for an account limited to the main board and ChiNext?
(declared before running, 2026-10-31, round nine)

Pool on each decision day: eligible stocks (not ST, listed >= 120 days) not on STAR (688/689), in the lowest fifth of
20-session average turnover (the fifth taken over all eligible stocks, as in the plan), whose latest quarter announced
by then shows revenue and profit growth above zero.
Every 20 sessions with the plan's mechanics (decide at the close, buy at the next open, a limit-up open is passed over,
hold to the close of the next decision day, 0.2% per period for the round trip; small_cap_design.run):
  rule    the 3 coldest of the pool (the execution plan);
  random  3 drawn at random from the pool (20 draws);
  pool    the whole pool, equal weights;
and holding CSI 2000 (small caps) and ChiNext (the user's anchor) over the same span.
Windows: from 2024-07-01 and from 2024-01-31 (start offsets 0, 5, 10, 15 for rule and pool; random at offset 0),
and from 2025-04-28 (the last 18 months, offset 0).
Reported: annual return and max drawdown; where the rule falls among the 20 random draws; the pool's size.
The question is attribution, not a new rule: nothing here is adopted because it scores best.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import industry_rotation as ir  # noqa: E402
import small_cap_design as sd  # noqa: E402

STAR = ('688', '689')
days, n = sd.days, sd.n
_pool = {}


def pool(t):
    if t not in _pool:
        members = sd.basket(t)
        sales, profit = ir.latest_growth(t)
        ok = members[(sales[members] > 0) & (profit[members] > 0)]
        ok = np.array([i for i in ok if not ir.codes[i].startswith(STAR)], dtype=int)
        _pool[t] = ok[np.argsort(sd.avg20[ok, t], kind='stable')] if len(ok) else ok
    return _pool[t]


def choose(rule, t, rng):
    members = pool(t)
    if rule == 'rule':
        ranked, want = list(members), 3
    elif rule == 'random':
        ranked, want = list(rng.permutation(members)), 3
    else:
        ranked, want = list(members), None
    picked = []
    for i in ranked:
        if sd.buyable(i, t):
            picked.append(i)
            if want and len(picked) == want:
                break
    return picked


sd.choose = choose


def hold(index, start):
    nav = index[start:] / index[start]
    d = sd.describe(nav, days[start:], np.array([nav[-1] - 1]))
    return {'cagr_pct': round(d['cagr_pct'], 2), 'max_drawdown_pct': round(d['max_drawdown_pct'], 2)}


def run(rule, first, offset=0, seed=0):
    nav, span, periods = sd.run(rule, 20, first, None, seed, offset)
    d = sd.describe(nav, span, periods)
    return {'cagr_pct': round(d['cagr_pct'], 2), 'max_drawdown_pct': round(d['max_drawdown_pct'], 2), 'start': span[0]}


def main():
    out = {}
    anchor = days.index('2024-07-01')
    recent = next(t for t in range(anchor, n, 20) if days[t] >= '2025-04-28')
    for window, first, offsets in (('from_2024-07', anchor, (0, 5, 10, 15)), ('from_2024-01-31', days.index('2024-01-31'), (0, 5, 10, 15)),
                                   ('from_2025-04-28', recent, (0,))):
        block = {'rule': [run('rule', first, o) for o in offsets], 'pool': [run('pool', first, o) for o in offsets],
                 'random': [run('random', first, 0, seed) for seed in range(20)],
                 'csi2000': [hold(sd.c2000, first + o) for o in offsets], 'chinext': [hold(sd.chinext, first + o) for o in offsets],
                 'pool_size_median': int(np.median([len(pool(t)) for t in range(first, n - 1, 20)]))}
        rule0 = block['rule'][0]['cagr_pct']
        block['rule_rank_among_random'] = int(sum(r['cagr_pct'] < rule0 for r in block['random']))
        out[window] = block
        med = lambda xs, k: round(float(np.median([x[k] for x in xs])), 1)
        print(window, 'pool size', block['pool_size_median'], '| rule', [x['cagr_pct'] for x in block['rule']], 'mdd', [x['max_drawdown_pct'] for x in block['rule']],
              '| pool', [x['cagr_pct'] for x in block['pool']], '| random median', med(block['random'], 'cagr_pct'),
              'range', min(x['cagr_pct'] for x in block['random']), max(x['cagr_pct'] for x in block['random']),
              '| rule beats', block['rule_rank_among_random'], 'of 20 random', '| csi2000', block['csi2000'][0], '| chinext', block['chinext'][0], flush=True)
    (HERE / 'selection_value.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written selection_value.json')


if __name__ == '__main__':
    main()
