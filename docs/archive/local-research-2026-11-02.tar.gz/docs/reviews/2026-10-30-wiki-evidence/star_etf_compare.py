"""Which STAR ETF, if any, should stand in for a STAR name the account cannot buy? (declared before running,
2026-10-30, round eight; the user named 588170 and 588000)

ETFs: one or two per tracked index, fetched with fetch_star_etfs.py (actual fund prices, not the index).
Facts per ETF: listing date, yearly management plus custody fee, latest size (shares x close), average daily turnover
over the last 60 sessions.
Performance from fund prices (close / previous close chained): from 2025-04-24 to 2026-10-30 (all but the
innovative-drug ETF were trading by then) with annual return, max drawdown and annual volatility; and the two 2026
phases, end of February to end of June, and end of June to 2026-10-30.
Stand-in test: the engine of star_substitute.py (10,000 yuan, commission 0.025% with a 5-yuan minimum, whole lots,
names on the new list stay, the list is traded at the next open) with each ETF's own prices in the place of every STAR
name among the first three, against skipping the STAR names. Decision days follow the plan's schedule; the first is
the first decision day on or after 2025-04-24; start offsets 0, 5, 10 and 15 sessions; stock data end 2026-10-29.
Only about 18 months and one rise and one fall are covered: the ranking of the ETFs here is not a forecast.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import star_substitute as ss  # noqa: E402

ra, days, n = ss.ra, ss.days, ss.n
etfs = json.loads((ra.ir.HISTORY / 'star_etfs.json').read_text(encoding='utf-8'))['etfs']
iso = lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
WINDOW_START = '2025-04-24'


def chain(rows, start, end):
    """Close-to-close values from the close before `start` (or the first close on/after it) to `end`."""
    rows = [r for r in rows if iso(r['trade_date']) <= end]
    before = [r for r in rows if iso(r['trade_date']) < start]
    inside = [r for r in rows if iso(r['trade_date']) >= start]
    if not inside:
        return None
    nav = [1.0]
    for r in inside if before else inside[1:]:
        nav.append(nav[-1] * float(r['close']) / float(r['pre_close']))
    return np.array(nav)


def stats(nav):
    if nav is None or len(nav) < 2:
        return None
    daily = nav[1:] / nav[:-1] - 1
    years = len(daily) / 252
    return {'total_pct': round((nav[-1] - 1) * 100, 2), 'annual_pct': round((nav[-1] ** (1 / years) - 1) * 100, 2),
            'max_drawdown_pct': round(float((nav / np.maximum.accumulate(nav) - 1).min() * 100), 2),
            'vol_pct': round(float(daily.std(ddof=1) * np.sqrt(252) * 100), 2)}


def facts(code, item):
    rows = item['rows']
    last = rows[-1]
    recent = rows[-60:]
    share = (item.get('latest_share') or {}).get('fd_share')
    return {'name': item['name'], 'theme': item['theme'], 'list_date': iso(str(item['list_date'])) if item.get('list_date') else None,
            'fee_pct': round(float(item['m_fee'] or 0) + float(item['c_fee'] or 0), 2),
            'size_yi': round(float(share) * 1e4 * float(last['close']) / 1e8, 1) if share else None,
            'turnover_yi': round(float(np.mean([float(r['amount']) for r in recent])) * 1e3 / 1e8, 2),
            'since_window': stats(chain(rows, WINDOW_START, '2026-10-30')),
            'rise_2026': stats(chain(rows, '2026-03-01', '2026-06-30')),
            'fall_2026': stats(chain(rows, '2026-07-01', '2026-10-30'))}


def series(rows):
    by_day = {iso(r['trade_date']): r for r in rows}
    get = lambda key: np.array([float(by_day[d][key]) * 1000 if d in by_day else np.nan for d in days])
    return {'open': get('open'), 'close': get('close'), 'pre': get('pre_close')}   # x1000: the engine prices units at 1/1000


def main():
    out = {'facts': {code: facts(code, item) for code, item in etfs.items()}, 'stand_in': {}, 'window_start': WINDOW_START}
    for code, f in out['facts'].items():
        print(code, f['name'], f['fee_pct'], f['size_yi'], f['turnover_yi'], f['since_window'], f['rise_2026'] and f['rise_2026']['total_pct'],
              f['fall_2026'] and f['fall_2026']['total_pct'], flush=True)
    anchor = days.index('2024-07-01')
    first = next(t for t in range(anchor, n, 20) if days[t] >= WINDOW_START)
    out['first_decision'] = days[first]
    skip = [ra.summary('1万普通', 'no_star', first=first, offset=o)[0] for o in (0, 5, 10, 15)]
    out['stand_in']['skip'] = [{k: x[k] for k in ('start', 'cagr_pct', 'max_drawdown_pct', 'lowest_nav', 'beats_chinext', 'chinext_cagr_pct',
                                                   'chinext_max_drawdown_pct')} for x in skip]
    print('skip', [(x['cagr_pct'], x['max_drawdown_pct'], x['beats_chinext']) for x in skip], flush=True)
    for code, item in etfs.items():
        if out['facts'][code]['list_date'] and out['facts'][code]['list_date'] > days[first]:
            continue
        ss.INDEX[code] = series(item['rows'])
        runs = [ss.simulate(code, first, o) for o in (0, 5, 10, 15)]
        out['stand_in'][code] = runs
        print(code, item['name'], [(r['cagr_pct'], r['max_drawdown_pct'], r['lowest_nav'], r['beats_chinext'], r['index_share_pct']) for r in runs], flush=True)
    (HERE / 'star_etf_compare.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written star_etf_compare.json')


if __name__ == '__main__':
    main()
