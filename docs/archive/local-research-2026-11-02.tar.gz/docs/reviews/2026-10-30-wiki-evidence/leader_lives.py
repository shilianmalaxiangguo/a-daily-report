"""Do limit-up leaders have "more lives"? What daily bars can say about the leader style (declared before running,
2026-10-31, round ten).

Stocks: eligible (not ST, listed >= 120 days). A limit-up close: close / previous close - 1 >= the stock's limit - 0.2
points (10% main board, 20% ChiNext and STAR). Board count on day t: consecutive limit-up closes ending at t.
Events (each stock-day counted once per definition):
  relay k     board count exactly k on day t (k = 2, 3, 4, and 5 or more); bought at the open of t+1 unless it opens at
              or near the limit up (then it cannot be bought and is left out; how many is reported);
  first break board count >= 3 on t-1 and day t not a limit-up close; bought at the close of t;
  top board   the stock(s) with the highest board count in the market on day t (at least 3); bought at the open of
              t+1 unless it opens at the limit.
Held to the close of the 1st, 3rd and 5th session after the buying session (T+1: nothing bought is sold the same
day; a day without trading keeps the value); 0.2% for the round trip.
Each trade is also compared with the CSI All Share over the same span (excess, percentage points).
Reported per event and horizon: trades, mean and median return, share of winning trades, share losing more than 10%,
mean excess; and by year (2024, 2025, 2026). Only daily bars: intraday entries (buying on the board, half-way), queue
positions and theme sentiment are outside this test.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from wiki_evidence import FROZEN_INPUTS, load  # noqa: E402

h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
days, n = h['days'], len(h['days'])
R = h['returns']
limit_up = (R >= h['limit'][:, None] - 0.2) & h['eligible']
boards = np.zeros(R.shape, dtype=int)
for t in range(n):
    boards[:, t] = np.where(limit_up[:, t], (boards[:, t - 1] if t else 0) + 1, 0)
growth = np.where(np.isnan(R), 0.0, R / 100)
m_growth = np.where(np.isnan(h['m_ret']), 0.0, h['m_ret'] / 100)
COST = 0.002
HORIZONS = (1, 3, 5)


def opens_at_limit(i, t):
    o, pc = h['open'][i, t], h['pre'][i, t]
    return np.isnan(o) or np.isnan(pc) or (o / pc - 1) * 100 >= h['limit'][i] - 0.2


def trade(i, t, at_open, hold):
    """Buy on day t (open or close), sell at the close `hold` sessions after the buying session."""
    end = t + hold
    if end >= n:
        return None
    if at_open:
        stock = h['close'][i, t] / h['open'][i, t] * np.prod(1 + growth[i, t + 1:end + 1])
        market = h['m_close'][t] / h['m_open'][t] * np.prod(1 + m_growth[t + 1:end + 1]) if not np.isnan(h['m_open'][t]) else np.nan
    else:
        stock = np.prod(1 + growth[i, t + 1:end + 1])
        market = np.prod(1 + m_growth[t + 1:end + 1])
    value = (stock * (1 - COST) - 1) * 100
    return value, (value - (market - 1) * 100) if not np.isnan(market) else np.nan, days[t][:4]


def summarize(rows):
    if not rows:
        return None
    v = np.array([r[0] for r in rows])
    x = np.array([r[1] for r in rows])
    return {'trades': int(len(v)), 'mean_pct': round(float(v.mean()), 2), 'median_pct': round(float(np.median(v)), 2),
            'win_share': round(float((v > 0).mean()), 3), 'loss_over_10_share': round(float((v < -10).mean()), 3),
            'mean_excess_pp': round(float(np.nanmean(x)), 2)}


def main():
    events = {f'relay_{k}': [] for k in ('2', '3', '4', '5+')}
    events.update(first_break=[], top_board=[])
    skipped = {key: 0 for key in events}
    for t in range(1, n - 1):
        column = boards[:, t]
        for k, key in ((2, 'relay_2'), (3, 'relay_3'), (4, 'relay_4')):
            for i in np.flatnonzero(column == k):
                if opens_at_limit(i, t + 1):
                    skipped[key] += 1
                else:
                    events[key].append((i, t + 1, True))
        for i in np.flatnonzero(column >= 5):
            if opens_at_limit(i, t + 1):
                skipped['relay_5+'] += 1
            else:
                events['relay_5+'].append((i, t + 1, True))
        for i in np.flatnonzero((boards[:, t - 1] >= 3) & ~limit_up[:, t] & ~np.isnan(R[:, t])):
            events['first_break'].append((i, t, False))
        top = column.max()
        if top >= 3:
            for i in np.flatnonzero(column == top):
                if opens_at_limit(i, t + 1):
                    skipped['top_board'] += 1
                else:
                    events['top_board'].append((i, t + 1, True))
    out = {'skipped_opening_at_limit': skipped, 'results': {}}
    for key, items in events.items():
        out['results'][key] = {}
        for hold in HORIZONS:
            rows = [r for r in (trade(i, t, at_open, hold) for i, t, at_open in items) if r is not None]
            entry = {'all': summarize(rows)}
            for year in ('2024', '2025', '2026'):
                entry[year] = summarize([r for r in rows if r[2] == year])
            out['results'][key][str(hold)] = entry
            a = entry['all']
            print(key, f'hold {hold}', a and (a['trades'], a['mean_pct'], a['median_pct'], a['win_share'], a['loss_over_10_share'], a['mean_excess_pp']),
                  {y: entry[y] and (entry[y]['trades'], entry[y]['mean_pct'], entry[y]['win_share']) for y in ('2024', '2025', '2026')}, flush=True)
    print('skipped (opened at the limit, could not be bought):', skipped)
    (HERE / 'leader_lives.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written leader_lives.json')


if __name__ == '__main__':
    main()
