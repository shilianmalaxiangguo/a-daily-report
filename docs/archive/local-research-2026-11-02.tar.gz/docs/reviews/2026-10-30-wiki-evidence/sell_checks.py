"""Robustness of the sell rules that beat the base (added after tables 42 and 43 were seen, 2026-10-31, round sixteen).

Not for picking a threshold; to see whether the result is a knife-edge or holds broadly. Same account, paths and
comparisons as sell_rules.py:
  1. take profit at 5, 10, 15, 20, 30% above what was paid, and selling after a close up 5, 7, 9%;
  2. calendar years 2024 (from the path's start), 2025 and 2026 (to 10-29): base, GAP, TP10, UP7, GAP with TP10, and
     ChiNext over the same days;
  3. 0.5% slippage on every order, buys and sales: base, GAP, TP10, UP7, GAP with TP10;
  4. the user's GAP rule with TP10 or UP7 added, against GAP alone.
Added after the first run of 1 to 4 (the combinations looked weaker than the single rules): every summary also keeps
the values of each path, and the two combinations are compared with the base and with TP10 or UP7 alone as well.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import sell_rules as sr  # noqa: E402

days = sr.days


def run(rule=None, **kw):
    runs = [sr.simulate(days.index(label), offset, rule=rule, **kw) for _, label, offset in sr.PATHS]
    return runs, sr.simulate(sr.RECENT, 0, rule=rule, **kw)


def summary(runs, recent, ref):
    a, b = runs[:4], runs[4:]
    dd = [x['max_drawdown_pct'] for x in runs]
    return {'from_2024-07_median': round(float(np.median([x['cagr_pct'] for x in a])), 1),
            'from_2024-01-31_median': round(float(np.median([x['cagr_pct'] for x in b])), 1),
            'drawdown_shallowest': max(dd), 'drawdown_deepest': min(dd), 'lowest_nav': min(x['lowest_nav'] for x in runs),
            'beats_chinext': sum(x['beats_chinext'] for x in runs),
            'higher_than_ref': sum(x['cagr_pct'] > y['cagr_pct'] for x, y in zip(runs, ref[0])),
            'deeper_than_ref': sum(x['max_drawdown_pct'] < y['max_drawdown_pct'] for x, y in zip(runs, ref[0])),
            'recent_cagr': recent['cagr_pct'], 'recent_drawdown': recent['max_drawdown_pct'], 'recent_ref': ref[1]['cagr_pct'],
            'big_gain_median': float(np.median([x['big_gain'] for x in runs])), 'big_loss_max': max(x['big_loss'] for x in runs),
            'rule_sales_mean': round(float(np.mean([x['rule_sales'] for x in runs])), 1),
            'paths': [[x['cagr_pct'], x['max_drawdown_pct']] for x in runs]}


def years(nav, span):
    nav, out = np.asarray(nav), {}
    for year in ('2024', '2025', '2026'):
        idx = [k for k, day in enumerate(span) if day.startswith(year)]
        if idx:
            out[year] = round(float(nav[idx[-1]] / nav[max(idx[0] - 1, 0)] - 1) * 100, 1)
    return out


def main():
    out = {'thresholds': {}, 'years': {}, 'slippage': {}, 'combined': {}}
    base = run()
    for rule in ('TP:0.05', 'TP:0.10', 'TP:0.15', 'TP:0.20', 'TP:0.30', 'UP:5', 'UP:7', 'UP:9'):
        out['thresholds'][rule] = summary(*run(rule), base)
        print('threshold', rule, out['thresholds'][rule], flush=True)
    for label, rule in (('base', None), ('GAP', 'GAP'), ('TP10', 'TP10'), ('UP7', 'UP7'), ('GAP+TP10', ('GAP', 'TP10'))):
        runs = [sr.simulate(days.index(first), offset, rule=rule, keep_nav=True) for _, first, offset in sr.PATHS]
        per = [years(x['nav'], x['span']) for x in runs]
        out['years'][label] = {y: round(float(np.median([p[y] for p in per if y in p])), 1) for y in ('2024', '2025', '2026')}
        print('years', label, out['years'][label], flush=True)
    chinext = []
    for _, first, offset in sr.PATHS:
        start = days.index(first) + offset
        chinext.append(years(sr.ra.chinext_window(start), days[start:]))
    out['years']['ChiNext'] = {y: round(float(np.median([p[y] for p in chinext if y in p])), 1) for y in ('2024', '2025', '2026')}
    print('years ChiNext', out['years']['ChiNext'], flush=True)
    slipped_base = run(slip=0.005)
    for label, rule in (('base', None), ('GAP', 'GAP'), ('TP10', 'TP10'), ('UP7', 'UP7'), ('GAP+TP10', ('GAP', 'TP10'))):
        out['slippage'][label] = summary(*(slipped_base if rule is None else run(rule, slip=0.005)), slipped_base)
        print('slippage 0.5%', label, out['slippage'][label], flush=True)
    gap = run('GAP')
    for label, rule, single in (('GAP+TP10', ('GAP', 'TP10'), 'TP10'), ('GAP+UP7', ('GAP', 'UP7'), 'UP7')):
        runs = run(rule)
        for against, ref in (('GAP', gap), ('base', base), (single, run(single))):
            out['combined'][f'{label}|vs {against}'] = summary(*runs, ref)
            print('combined', label, 'vs', against, out['combined'][f'{label}|vs {against}'], flush=True)
    (HERE / 'sell_checks.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written sell_checks.json')


if __name__ == '__main__':
    main()
