"""How to sell in the plan: hold to the next rotation, or sell on a condition? (declared before running, 2026-10-31, round sixteen)

User, 2026-10-31: "你来回测下如何卖出，还是按照你说的 一定时间之后 下一个轮换周期集体卖出".
The account of account_names.py: 10,000 yuan, commission 0.01% without minimum, stamp duty 0.05% on sales, transfer
0.001%; main board and ChiNext; the plan's list (coldest names whose latest quarter grew), five names, whole lots,
each buy gets cash / empty places, a name whose lot does not fit or that opens at the limit up is passed over.
Base (the plan): rotation every 20 sessions; at the open after a rotation day, names off the new list's first five are
sold and the places filled down the list; names still among the first five are kept.
Time:  T10, T40   rotation every 10 or 40 sessions instead of 20;
       REBAL      at each rotation sell every name, then buy the new list afresh in equal amounts.
Conditions, on top of the 20-session rotation. A signal at a close sells at the next open; an open at the limit down
cannot sell and waits. The money waits for the next rotation unless noted, and a name sold this way is not bought
again in the same period:
  GAP     the user's high-open rule, at each open: up 5% or more but below the limit, or up at all after a rise of 10%
          or more over the previous five sessions, sells at that open; a limit-up open after a smaller rise is kept
          and looked at again the next day;
  GAP+    the same, and the money buys the next names of the period's list at that open;
  UP7     a close up 7% or more;
  SPIKE   a close up on an amount at least three times the average of the previous 20 sessions ("追的人来了");
  TP10, TP20   the position closes 10% or 20% above what was paid for it (dividends counted);
  SL10, SL15   the position closes 10% or 15% below what was paid for it;
  TRAIL   the position closes 10% below its highest close since it was bought;
  BBI     after a close above BBI since bought, two closes in a row below it (少妇战法1.0);
  ST      the name turns ST while held.
Paths: from 2024-07-01 and from 2024-01-31 with start offsets 0, 5, 10, 15 sessions (8 paths), and from 2025-04-28.
Reported per run: annual return, max drawdown, lowest net value, 20-session periods losing more than 10%, beating
ChiNext (higher annual return and a shallower max drawdown, same window), fees, idle cash, sales made by the rule,
and what the sold names did from the sale to the close of the period's last day (what selling gave up; negative
means a loss avoided).
A rule counts as better than the base only if its annual return is higher on at least 6 of the 8 paths, its max
drawdown is deeper on at most 2 of them, and its return from 2025-04-28 is not lower. Fourteen rules are tried, so
even then it is tracked forward before the plan changes. The base must reproduce account_names.simulate(5) exactly.
"""
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import account_names as an  # noqa: E402
import b1_point as b1  # noqa: E402  (BBI on adjusted prices, from round fifteen)

ra = an.ra
h, days, n, codes = an.h, an.days, an.n, an.codes
STAR = ('688', '689')
R = h['returns']
G = 1 + np.where(np.isnan(R), 0.0, R) / 100              # missing days count as no change
grow = 1 + R / 100
prior5 = np.full(R.shape, np.nan)
prior5[:, 5:] = (np.prod([grow[:, j:n - 5 + j] for j in range(5)], axis=0) - 1) * 100   # sessions d-5 .. d-1
amount = h['amount']
cs = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(np.nan_to_num(amount), axis=1)], axis=1)
cnt = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(~np.isnan(amount), axis=1)], axis=1)
before20 = np.full(amount.shape, np.nan)
with np.errstate(invalid='ignore', divide='ignore'):
    before20[:, 20:] = (cs[:, 20:-1] - cs[:, :-21]) / (cnt[:, 20:-1] - cnt[:, :-21])
    SPIKE = (amount >= 3 * before20) & (R > 0)
    UP7 = R >= 7
    ABOVE = b1.A > b1.BBI
ST = ~h['eligible']                                      # held names are old enough, so not eligible means ST


def hit(rule, i, d, value, paid, peak):
    if rule.startswith('TP:'):
        return value >= paid * (1 + float(rule[3:]))
    if rule.startswith('UP:'):
        return R[i, d] >= float(rule[3:])
    if rule == 'UP7':
        return UP7[i, d]
    if rule == 'SPIKE':
        return SPIKE[i, d]
    if rule in ('TP10', 'TP20'):
        return value >= paid * (1.10 if rule == 'TP10' else 1.20)
    if rule in ('SL10', 'SL15'):
        return value <= paid * (0.90 if rule == 'SL10' else 0.85)
    if rule == 'TRAIL':
        return value <= 0.9 * peak
    if rule == 'ST':
        return ST[i, d]
    return False


def simulate(first, offset=0, rule=None, refill=False, schedule=20, k=5, slip=0.0, keep_nav=False, detail=False):
    rules = set(rule) if isinstance(rule, tuple) else ({rule} if rule else set())
    source = 'period' if refill is True else refill          # False, 'period', 'fresh' or 'calm' (round seventeen)
    refills, log, period_start, holdings = 0, [], None, []
    start_cash = cash = 10_000.0
    decisions = list(range(first + offset, n - 1, schedule))
    marks, start = set(decisions), decisions[0]
    held, paid, peak, streak, seen = {}, {}, {}, {}, set()
    pending, due, plan_list, sold, end = set(), set(), [], set(), n - 1
    nav, fees, idle, gave_up, sales = [1.0], 0.0, [], [], 0
    for d in range(start + 1, n):
        t = d - 1
        switch = t in marks
        if switch:
            plan_list = [i for i in ra.ranked(t) if not codes[i].startswith(STAR)]
            keep = set() if 'REBAL' in rules else set(plan_list[:k])
            pending |= {i for i in held if i not in keep}
            sold, end = set(), next((x for x in decisions if x > t), n - 1)
            period_start = t
        if 'GAP' in rules:                                  # the high-open rule acts at the open itself
            for i in held:
                g = ra.gap(i, d)
                if i in pending or i in due or g is None:
                    continue
                if 5 <= g < h['limit'][i] - 0.2 or (g > 0 and prior5[i, d] >= 10):
                    due.add(i)
        freed_rotation = freed_rule = False
        for i in sorted(pending | due):                    # sales at the open
            g = ra.gap(i, d)
            if g is None or g <= -(h['limit'][i] - 0.2):
                continue
            gross = held.pop(i) * h['open'][i, d] / h['pre'][i, d] * (1 - slip)
            cost = ra.fee(gross, 0.0, True)
            cash, fees = cash + gross - cost, fees + cost
            for store in (paid, peak, streak):
                store.pop(i, None)
            seen.discard(i)
            if i in pending:
                pending.discard(i)
                freed_rotation = freed_rotation or not switch
            else:
                freed_rule, sales = True, sales + 1
                sold.add(i)
                log.append((int(i), d, end, period_start))
                if d <= end:
                    gave_up.append(float(h['close'][i, d] / h['open'][i, d] * np.prod(G[i, d + 1:end + 1]) - 1))
            due.discard(i)
        bought = set()
        refill_now = bool(source) and freed_rule and (source != 'calm' or ra.sd.c2000[t] > ra.sd.ma20_2000[t])
        if plan_list and len(held) < k and (switch or freed_rotation or refill_now):
            listing = plan_list
            if source == 'fresh' and not (switch or freed_rotation):
                listing = [i for i in ra.ranked(t) if not codes[i].startswith(STAR)]
            for i in listing:                                   # buys at the open, down the list
                if len(held) >= k:
                    break
                if i in held or i in sold:
                    continue
                g = ra.gap(i, d)
                if g is None or g >= h['limit'][i] - 0.2:
                    continue
                price = h['open'][i, d] * (1 + slip)
                budget = cash / (k - len(held))
                shares = np.floor(budget / (price * 100)) * 100
                while shares > 0 and shares * price + ra.fee(shares * price, 0.0, False) > budget:
                    shares -= 100
                if shares <= 0:
                    continue
                cost = ra.fee(shares * price, 0.0, False)
                cash, fees = cash - shares * price - cost, fees + cost
                held[i], paid[i] = shares * h['close'][i, d], shares * price
                peak[i] = held[i]
                bought.add(i)
                refills += not (switch or freed_rotation)
        if detail and switch:                                   # who is held after a switch day's open (the report)
            holdings.append((t, [(int(i), 'new' if i in bought else 'unsold' if i in pending else 'kept') for i in held]))
        for i in held:                                          # the close
            c, p = h['close'][i, d], h['pre'][i, d]
            if i not in bought and not (np.isnan(c) or np.isnan(p)):
                held[i] *= c / p
            if np.isnan(c) or i in pending or i in due:
                continue
            peak[i] = max(peak[i], held[i])
            if 'BBI' in rules:
                if ABOVE[i, d]:
                    seen.add(i)
                    streak[i] = 0
                elif i in seen:
                    streak[i] = streak.get(i, 0) + 1
                    if streak[i] >= 2:
                        due.add(i)
            elif any(hit(x, i, d, held[i], paid[i], peak[i]) for x in rules - {'GAP', 'REBAL'}):
                due.add(i)
        equity = cash + sum(held.values())
        nav.append(equity / start_cash)
        idle.append(cash / equity)
    nav = np.array(nav)
    span, marks20 = days[start:], list(range(start, n - 1, 20))
    prof = ra.profile(nav, span, marks20, start)
    ref = ra.profile(ra.chinext_window(start), span, marks20, start)
    return {'start': span[0], 'cagr_pct': round(prof['cagr_pct'], 2), 'max_drawdown_pct': round(prof['max_drawdown_pct'], 2),
            'lowest_nav': round(prof['lowest_nav'], 3), 'final_nav': round(float(nav[-1]), 3),
            'beats_chinext': bool(prof['cagr_pct'] > ref['cagr_pct'] and prof['max_drawdown_pct'] > ref['max_drawdown_pct']),
            'big_loss': prof['big_loss'], 'big_gain': prof['big_gain'], 'periods': prof['periods'],
            'worst_period_pct': round(prof['worst_period_pct'], 1), 'fees_pct_of_start': round(fees / start_cash * 100, 2),
            'idle_pct': round(float(np.mean(idle)) * 100, 1), 'rule_sales': sales,
            'gave_up_mean_pct': round(float(np.mean(gave_up)) * 100, 2) if gave_up else None,
            'gave_up_median_pct': round(float(np.median(gave_up)) * 100, 2) if gave_up else None,
            **({'nav': nav, 'span': span} if keep_nav else {}),
            **({'gave_up': gave_up, 'refills': refills, 'log': log, 'holdings': holdings} if detail else {})}


RULES = {'base': {}, 'T10': {'schedule': 10}, 'T40': {'schedule': 40}, 'REBAL': {'rule': 'REBAL'}, 'GAP': {'rule': 'GAP'},
         'GAP+': {'rule': 'GAP', 'refill': True}, 'UP7': {'rule': 'UP7'}, 'SPIKE': {'rule': 'SPIKE'}, 'TP10': {'rule': 'TP10'},
         'TP20': {'rule': 'TP20'}, 'SL10': {'rule': 'SL10'}, 'SL15': {'rule': 'SL15'}, 'TRAIL': {'rule': 'TRAIL'},
         'BBI': {'rule': 'BBI'}, 'ST': {'rule': 'ST'}}
PATHS = [(window, label, offset) for window, label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31'))
         for offset in (0, 5, 10, 15)]
RECENT = next(t for t in range(days.index('2024-07-01'), n, 20) if days[t] >= '2025-04-28')


def main():
    out = {}
    for name, kw in RULES.items():
        runs = [simulate(days.index(label), offset, **kw) for _, label, offset in PATHS]
        out[name] = {'paths': runs, 'recent': simulate(RECENT, 0, **kw)}
        print(name, [(r['cagr_pct'], r['max_drawdown_pct']) for r in runs], 'recent', out[name]['recent']['cagr_pct'],
              out[name]['recent']['max_drawdown_pct'], 'sales', [r['rule_sales'] for r in runs],
              'gave up', [r['gave_up_mean_pct'] for r in runs], flush=True)
    for (window, label, offset), run in zip(PATHS, out['base']['paths']):
        ref = an.simulate(5, days.index(label), offset)
        assert (ref['cagr_pct'], ref['max_drawdown_pct']) == (run['cagr_pct'], run['max_drawdown_pct']), (window, offset, ref, run)
    print('base reproduces account_names.simulate(5) on all 8 paths', flush=True)
    base = out['base']
    for name, x in out.items():
        pairs = list(zip(x['paths'], base['paths']))
        higher = sum(a['cagr_pct'] > b['cagr_pct'] for a, b in pairs)
        deeper = sum(a['max_drawdown_pct'] < b['max_drawdown_pct'] for a, b in pairs)
        recent_ok = x['recent']['cagr_pct'] >= base['recent']['cagr_pct']
        x['vs_base'] = {'higher_return_paths': higher, 'deeper_drawdown_paths': deeper, 'recent_not_lower': recent_ok,
                        'median_return_gap_pp': round(float(np.median([a['cagr_pct'] - b['cagr_pct'] for a, b in pairs])), 2),
                        'median_drawdown_gap_pp': round(float(np.median([a['max_drawdown_pct'] - b['max_drawdown_pct'] for a, b in pairs])), 2),
                        'better': bool(name != 'base' and higher >= 6 and deeper <= 2 and recent_ok)}
        print(name, x['vs_base'], 'beats ChiNext', sum(r['beats_chinext'] for r in x['paths']), '/ 8, lowest',
              min(r['lowest_nav'] for r in x['paths']), flush=True)
    (HERE / 'sell_rules.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written sell_rules.json')


if __name__ == '__main__':
    main()
