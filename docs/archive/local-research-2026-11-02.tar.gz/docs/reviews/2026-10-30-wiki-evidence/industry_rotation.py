"""Picking sectors and stocks instead of holding an index: can it beat ChiNext and the CSI All Share? (declared before running)

Net value starts at 1. Every 20 sessions, decide at the close of day t, buy at the open of t+1 (stocks opening at
the limit are skipped), hold equal weights to the close of t+20, then form the next basket; 0.2% per period for a
full round trip. Stocks: not ST, listed >= 120 days; "liquid" means 20-session average turnover >= 1e8 yuan.
Industries: the latest Tushare label of each stock; an industry's daily return is the equal-weight mean of its
eligible stocks (at least 10 that day); its M-session return compounds those.

I-A  sector only:        the top N industries by M-session return, all their liquid stocks.          N 1,3; M 60,120
I-B  sector + strongest: in each of those industries, the 5 liquid stocks with the highest M return.  N 1,3; M 60,120
I-C  sector + pullback:  in each, among liquid stocks in the industry's top half by M return, the 5 with the lowest
                         5-session return.                                                            N 1,3; M 60,120
I-D  I-C (N 3) plus a market switch: after a close of the CSI All Share below its 60-session average, sell at the
     next open and stay in cash until a rebalance day on which it is back above.                         M 60,120
II   stock momentum: the 20 liquid stocks with the highest return from t-M to t-5.                         M 60,120
III-A growth: the 20 liquid stocks with the highest latest single-quarter revenue growth, profit growth > 0.
III-B sector + growth: top 3 industries by 120-session return, in each the 5 liquid stocks with the highest
      revenue growth and profit growth > 0.
Reference: the small-stock rotation (lowest fifth of 20-session turnover among eligible stocks, all of them).
Added after the results above were seen (hindsight, to answer whether optical modules could have been picked):
P   leaders: an industry's signal is the M-session return of its 10 most-traded liquid stocks (equal weight); hold
    the 5 most-traded liquid stocks of each of the top 3 industries.                                       M 60,120
P-D the same (M 60) with the market switch of I-D.
Financial data are used only once announced (announcement date <= t, and after the period end); for each stock the
latest period, latest version known at t.
First decision 2024-07-01 (every lookback exists); four start offsets (0, 5, 10, 15 sessions), mean and range.
Also reported from 2024-09-02, for March-June 2026 and July-October 2026, and the industries held in 2026.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from wiki_evidence import FROZEN_INPUTS, HISTORY, load  # noqa: E402
from report.strategy_backtest import _metrics  # noqa: E402

PERIOD, COST, LIQUID = 20, 0.002, 100_000.0
h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
days, n, codes = h['days'], len(h['days']), h['codes']
basics = {r['ts_code']: r for r in json.loads((HISTORY / 'basics.json').read_text(encoding='utf-8'))['rows']}
industry = np.array([(basics.get(c) or {}).get('industry') or '' for c in codes])
R = h['returns']
growth = np.where(np.isnan(R), 0.0, R / 100)
valid = ~np.isnan(R)
amount = h['amount']
filled = np.where(np.isnan(amount), 0, amount)
cs = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(filled, axis=1)], axis=1)
cnt = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(~np.isnan(amount), axis=1)], axis=1)
avg20 = np.full(amount.shape, np.nan)
avg20[:, 19:] = (cs[:, 20:] - cs[:, :-20]) / np.maximum(cnt[:, 20:] - cnt[:, :-20], 1)
logg = np.log1p(growth)
clog = np.concatenate([np.zeros((len(codes), 1)), np.cumsum(logg, axis=1)], axis=1)


def stock_return(t, back, skip=0):
    """Compounded return over sessions t-back+1 .. t-skip (NaN-free: missing days count as no change)."""
    return np.exp(clog[:, t + 1 - skip] - clog[:, t + 1 - back]) - 1


names = sorted({g for g in industry if g})
ind_daily = {}
for g in names:
    members = industry == g
    m = h['eligible'] & valid & members[:, None]
    count = m.sum(axis=0)
    ind_daily[g] = np.where(count >= 10, np.where(m, R, 0).sum(axis=0) / np.maximum(count, 1) / 100, np.nan)
ind_log = {g: np.concatenate([[0.0], np.cumsum(np.log1p(np.where(np.isnan(v), 0.0, v)))]) for g, v in ind_daily.items()}


def industry_return(t, back):
    out = {}
    for g in names:
        window = ind_daily[g][t + 1 - back:t + 1]
        if len(window) and np.isnan(window).mean() <= 0.2:
            out[g] = float(np.exp(ind_log[g][t + 1] - ind_log[g][t + 1 - back]) - 1)
    return out


fina = json.loads((HISTORY / 'fina_indicator.json').read_text(encoding='utf-8'))['periods']
records = {}
for period, rows in fina.items():
    for r in rows:
        ann = r.get('ann_date')
        if not ann or ann <= period or r.get('q_sales_yoy') is None or r.get('q_profit_yoy') is None:
            continue
        records.setdefault(r['ts_code'], []).append((f'{ann[:4]}-{ann[4:6]}-{ann[6:]}', period, float(r['q_sales_yoy']), float(r['q_profit_yoy'])))
for rows in records.values():
    rows.sort()


def latest_growth(t):
    """(sales growth, profit growth) per stock from the latest period announced on or before day t."""
    day = days[t]
    sales, profit = np.full(len(codes), np.nan), np.full(len(codes), np.nan)
    for i, c in enumerate(codes):
        best = None
        for ann, period, s, p in records.get(c, ()):
            if ann > day:
                break
            if best is None or period >= best[0]:
                best = (period, s, p)
        if best:
            sales[i], profit[i] = best[1], best[2]
    return sales, profit


m_close = h['m_close']
m_ma60 = np.full(n, np.nan)
c = np.cumsum(np.insert(m_close, 0, 0.0))
m_ma60[59:] = (c[60:] - c[:-60]) / 60


def pick(kind, t, N=3, M=120):
    liquid = h['eligible'][:, t] & (avg20[:, t] >= LIQUID) & ~np.isnan(h['close'][:, t])
    held_industries = []
    if kind in ('P', 'PD'):
        r_m = stock_return(t, M)
        signal, leaders = {}, {}
        for g in names:
            members = np.flatnonzero(liquid & (industry == g))
            if len(members) < 5:
                continue
            top = members[np.argsort(-avg20[members, t], kind='stable')][:10]
            signal[g], leaders[g] = float(np.mean(r_m[top])), list(top[:5])
        held_industries = [g for g, _ in sorted(signal.items(), key=lambda kv: -kv[1])[:N]]
        return [i for g in held_industries for i in leaders[g]], held_industries
    if kind in ('A', 'B', 'C', 'D', 'IIIB'):
        ranked = sorted(industry_return(t, M).items(), key=lambda kv: -kv[1])
        held_industries = [g for g, _ in ranked[:N]]
        if kind == 'IIIB':
            sales, profit = latest_growth(t)
        out = []
        r_m, r_5 = stock_return(t, M), stock_return(t, 5)
        for g in held_industries:
            members = np.flatnonzero(liquid & (industry == g))
            if kind == 'A':
                out += list(members)
            elif kind == 'B':
                out += list(members[np.argsort(-r_m[members], kind='stable')][:5])
            elif kind in ('C', 'D'):
                top = members[r_m[members] >= np.median(r_m[members])] if len(members) else members
                out += list(top[np.argsort(r_5[top], kind='stable')][:5])
            else:
                ok = members[(profit[members] > 0) & ~np.isnan(sales[members])]
                out += list(ok[np.argsort(-sales[ok], kind='stable')][:5])
        return out, held_industries
    if kind == 'II':
        r = stock_return(t, M, skip=5)
        pool = np.flatnonzero(liquid)
        return list(pool[np.argsort(-r[pool], kind='stable')][:20]), []
    if kind == 'IIIA':
        sales, profit = latest_growth(t)
        pool = np.flatnonzero(liquid & (profit > 0) & ~np.isnan(sales))
        return list(pool[np.argsort(-sales[pool], kind='stable')][:20]), []
    if kind == 'SMALL':
        ok = h['eligible'][:, t] & ~np.isnan(avg20[:, t]) & ~np.isnan(h['close'][:, t])
        q20 = np.quantile(avg20[ok, t], 0.2)
        return list(np.flatnonzero(ok & (avg20[:, t] <= q20))), []
    raise ValueError(kind)


def run(kind, offset, N=3, M=120):
    first = days.index('2024-07-01') + offset
    nav, log, inside = [1.0], [], True
    for t in range(first, n - 1, PERIOD):
        end = min(t + PERIOD, n - 1)
        members, held = pick(kind, t, N, M)
        if kind in ('D', 'PD') and not (m_close[t] > m_ma60[t]):
            members = []
        bought = [i for i in members if not (np.isnan(h['open'][i, t + 1]) or np.isnan(h['pre'][i, t + 1])
                                             or (h['open'][i, t + 1] / h['pre'][i, t + 1] - 1) * 100 >= h['limit'][i] - 0.2)]
        log.append({'date': days[t], 'industries': held, 'stocks': len(bought),
                    'names': [(basics.get(codes[i]) or {}).get('name') for i in bought[:8]]})
        base = nav[-1]
        if not bought:
            nav += [base * (1 + 0.015 / 252) ** k for k in range(1, end - t + 1)]
            continue
        value = np.array([h['close'][i, t + 1] / h['open'][i, t + 1] if not np.isnan(h['close'][i, t + 1]) else 1.0 for i in bought])
        nav.append(base * (1 - COST / 2) * value.mean())
        out_at = None
        for d in range(t + 2, end + 1):
            if kind in ('D', 'PD') and out_at is None and d - 1 > t and m_close[d - 1] < m_ma60[d - 1]:
                over = np.array([h['open'][i, d] / h['pre'][i, d] if not (np.isnan(h['open'][i, d]) or np.isnan(h['pre'][i, d])) else 1.0
                                 for i in bought])
                nav.append(base * (1 - COST / 2) * (value * over).mean() * (1 - COST / 2))
                out_at = d
                continue
            if out_at is not None:
                nav.append(nav[-1] * (1 + 0.015 / 252))
                continue
            value = value * (1 + growth[bought, d])
            nav.append(base * (1 - COST / 2) * value.mean())
        if out_at is None:
            nav[-1] *= 1 - COST / 2
    span = days[first:first + len(nav)]
    return np.array(nav), span, log


def window_return(nav, span, a, b):
    ia = max(k for k, d in enumerate(span) if d <= a)
    ib = max(k for k, d in enumerate(span) if d <= b)
    return float((nav[ib] / nav[ia] - 1) * 100)


def stats(nav, span):
    m = _metrics(nav, span)
    out = {k: round(float(m[k]), 2) for k in ('cagr_pct', 'max_drawdown_pct', 'sharpe', 'total_pct')}
    out['lowest_nav'] = round(float(nav.min()), 3)
    k9 = next(k for k, d in enumerate(span) if d >= '2024-09-02')
    m9 = _metrics(nav[k9:] / nav[k9], span[k9:])
    out['from_2024-09-02'] = {'cagr_pct': round(float(m9['cagr_pct']), 2), 'max_drawdown_pct': round(float(m9['max_drawdown_pct']), 2)}
    out['2026-03_to_06_pct'] = round(window_return(nav, span, '2026-02-27', '2026-06-30'), 1)
    out['2026-07_to_10_pct'] = round(window_return(nav, span, '2026-06-30', '2026-10-29'), 1)
    return out


VARIANTS = {}
for N in (1, 3):
    for M in (60, 120):
        VARIANTS[f'I-A|只选行业|前{N}个|看{M}日'] = ('A', N, M)
        VARIANTS[f'I-B|行业里追强|前{N}个|看{M}日'] = ('B', N, M)
        VARIANTS[f'I-C|行业里回调买|前{N}个|看{M}日'] = ('C', N, M)
for M in (60, 120):
    VARIANTS[f'I-D|回调买＋大盘趋势开关|前3个|看{M}日'] = ('D', 3, M)
    VARIANTS[f'II|个股中期动量|前20只|看{M}日去掉最近5日'] = ('II', 3, M)
VARIANTS['III-A|业绩：单季收入增长最高20只'] = ('IIIA', 3, 120)
VARIANTS['III-B|主线＋业绩：前3个行业里收入增长最高的各5只'] = ('IIIB', 3, 120)
VARIANTS['参照|小盘轮换（成交额最小五分之一）'] = ('SMALL', 3, 120)
VARIANTS['事后补测P|行业龙头：前3个行业成交最活跃的各5只|看60日'] = ('P', 3, 60)
VARIANTS['事后补测P|行业龙头：前3个行业成交最活跃的各5只|看120日'] = ('P', 3, 120)
VARIANTS['事后补测P-D|行业龙头＋大盘趋势开关|看60日'] = ('PD', 3, 60)


def main():
    result = {'inputs_sha256': h['inputs_sha256'], 'first_decision': '2024-07-01', 'variants': {}, 'benchmarks': {}}
    indices = json.loads((HISTORY / 'indices.json').read_text(encoding='utf-8'))['indices']
    iso = lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
    closes = {'中证全指': dict(zip(days, m_close)), '创业板指': {iso(r['trade_date']): r['close'] for r in indices['399006.SZ']['rows']},
              '科创50': {iso(r['trade_date']): r['close'] for r in indices['000688.SH']['rows']}}
    for name, cl in closes.items():
        span = days[days.index('2024-07-01'):]
        nav = np.array([cl[d] for d in span]) / cl[span[0]]
        result['benchmarks'][name] = stats(nav, span)
    for name, (kind, N, M) in VARIANTS.items():
        runs, logs = [], None
        for offset in (0, 5, 10, 15):
            nav, span, log = run(kind, offset, N, M)
            runs.append(stats(nav, span))
            if offset == 0:
                logs = [entry for entry in log if entry['date'] >= '2025-12-01']
        summary = {key: {'mean': round(float(np.mean([r[key] for r in runs])), 2), 'min': round(float(min(r[key] for r in runs)), 2),
                         'max': round(float(max(r[key] for r in runs)), 2)}
                   for key in ('cagr_pct', 'max_drawdown_pct', 'sharpe', 'lowest_nav', '2026-03_to_06_pct', '2026-07_to_10_pct')}
        summary['from_2024-09-02_cagr_mean'] = round(float(np.mean([r['from_2024-09-02']['cagr_pct'] for r in runs])), 2)
        result['variants'][name] = {'summary': summary, 'runs': runs, 'holdings_since_2025-12': logs}
        print(name, summary['cagr_pct'], summary['max_drawdown_pct'], summary['2026-03_to_06_pct']['mean'], summary['2026-07_to_10_pct']['mean'], flush=True)
    top = sorted(((g, float(np.exp(ind_log[g][days.index('2026-06-30') + 1] - ind_log[g][days.index('2026-02-27') + 1]) - 1))
                  for g in names), key=lambda kv: -kv[1])
    result['industries_2026-03_to_06'] = [(g, round(v * 100, 1)) for g, v in top[:12]]
    out = HERE / 'industry_rotation.json'
    out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written', out.name)


if __name__ == '__main__':
    main()
