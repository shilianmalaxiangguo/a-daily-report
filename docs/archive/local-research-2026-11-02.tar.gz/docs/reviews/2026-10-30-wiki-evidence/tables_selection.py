"""Prints the round-nine attribution table from selection_value.json."""
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'selection_value.json').read_text(encoding='utf-8'))
WINDOW = {'from_2024-07': '2024-07-01起', 'from_2024-01-31': '2024-01-31起（含2024年2月小盘大跌）', 'from_2025-04-28': '2025-04-28起（近18个月）'}


def pct(v):
    return f"{v:+.1f}%"


def mid(xs, key):
    return float(np.median([x[key] for x in xs]))


def spread(xs, key):
    values = [x[key] for x in xs]
    return pct(mid(xs, key)) + (f"（{pct(min(values))}至{pct(max(values))}）" if len(values) > 1 else '')


print('表29 钱从哪里来：主板和创业板（每20个交易日换，每期来回0.2%；规则和股票池按起步日，随机挑3只20次）\n')
print('| 起点 | 股票池每期约几只 | 执行计划：池里最冷门的3只 | 最大回撤 | 随机挑3只（20次） | 执行计划超过几次随机 | 整个股票池等权 | 最大回撤 | 中证2000 | 创业板指 |')
print('|---|---|---|---|---|---|---|---|---|---|')
for window, label in WINDOW.items():
    b = r[window]
    print(f"| {label} | {b['pool_size_median']} | {spread(b['rule'], 'cagr_pct')} | {pct(mid(b['rule'], 'max_drawdown_pct'))} | "
          f"{spread(b['random'], 'cagr_pct')} | {b['rule_rank_among_random']}/20 | {spread(b['pool'], 'cagr_pct')} | {pct(mid(b['pool'], 'max_drawdown_pct'))} | "
          f"{pct(b['csi2000'][0]['cagr_pct'])}（回撤{pct(b['csi2000'][0]['max_drawdown_pct'])}） | {pct(b['chinext'][0]['cagr_pct'])}（回撤{pct(b['chinext'][0]['max_drawdown_pct'])}） |")
