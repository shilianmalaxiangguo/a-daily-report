"""事后补测 (written after small_cap_design.json was seen): how much of each rule's return rests on its best periods.

For the whole basket and the three rule-picked variants (every 20 sessions, start offsets 0, 5, 10, 15, both windows),
recompute the compound return per year after removing the single best period, and the best two periods, replacing
each removed period with zero return. ChiNext gets the same treatment over the same decision days, since its own
return also rests on a few periods. The question is whether a rule still beats ChiNext without the luckiest months;
nothing here changes a rule.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import small_cap_design as sd  # noqa: E402

RULES = {'整篮子': 'all', '3只业绩为正里最冷门': 'growth:3', '3只最冷门': 'coldest:3', '3只最低波动': 'lowvol:3'}


def per_year(periods, years):
    return (np.prod(1 + periods) ** (1 / years) - 1) * 100


def chinext_run(first, offset):
    decisions = sd.decision_days(20, first + offset)
    idx = decisions + [sd.n - 1]
    periods = np.array([sd.chinext[idx[k + 1]] / sd.chinext[idx[k]] - 1 for k in range(len(decisions))])
    return np.ones(sd.n - decisions[0]), sd.days[decisions[0]:], periods


def main():
    out = {}
    for window, first_label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        first = sd.days.index(first_label)
        block = {}
        for label, rule in {**RULES, '创业板指（同样的换手日）': None}.items():
            runs = []
            for offset in (0, 5, 10, 15):
                nav, span, periods = sd.run(rule, 20, first, None, 0, offset) if rule else chinext_run(first, offset)
                years = (len(nav) - 1) / 252
                order = np.argsort(periods)[::-1]
                drop1, drop2 = periods.copy(), periods.copy()
                drop1[order[:1]] = 0.0
                drop2[order[:2]] = 0.0
                runs.append({'offset': offset, 'start': span[0], 'all_pct': round(per_year(periods, years), 1),
                             'without_best_pct': round(per_year(drop1, years), 1), 'without_best_two_pct': round(per_year(drop2, years), 1),
                             'best_two_periods_pct': [round(float(periods[k] * 100), 1) for k in order[:2]]})
            block[label] = runs
            print(window, label, [(r['all_pct'], r['without_best_pct'], r['without_best_two_pct'], r['best_two_periods_pct']) for r in runs], flush=True)
        out[window] = block
    (HERE / 'outlier_check.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written outlier_check.json')


if __name__ == '__main__':
    main()
