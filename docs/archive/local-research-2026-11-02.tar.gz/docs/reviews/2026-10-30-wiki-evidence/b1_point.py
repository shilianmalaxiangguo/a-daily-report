"""B1 buy point (少妇战法1.0): does it make money on the user's account? (declared before running, 2026-10-31, round fifteen)

Source (user, 2026-10-31): the text of two paid WeChat articles by 知行课代表 on Z哥's method, "【策略篇】三、深度理解
少妇战法1.0" and "【实战篇】七、实战完美图形" (https://mp.weixin.qq.com/s/hrmWA7tJLsioI1p8sb1ViA), and that page's charts,
which show the settings: 知行趋势线(14,28,57,114) with 知行短期趋势线 (white) and 知行多空线 (yellow), KDJ(9,3,3), daily
bars, 前复权. Lines, on each stock's own trading days, prices adjusted for splits and dividends:
  white  EMA(EMA(C,10),10); yellow (MA14+MA28+MA57+MA114)/4; BBI (MA3+MA6+MA12+MA24)/4;
  KDJ    RSV = (C-LLV(L,9))/(HHV(H,9)-LLV(L,9))*100, K = SMA(RSV,3,1), D = SMA(K,3,1), J = 3K-2D.
  The formulas are checked against the values printed on four of the article's charts before anything else runs.
B1 on a day (the article's "必备条件" and the ranges it gives from its ten "perfect" charts): white > yellow;
J < 13 ("并没有小于13，不符合我们的规则"); change -2% to +1.8%; amplitude (high-low)/previous close <= 7%.
Shrink variant: also the day's amount <= half the largest daily amount of the previous 20 sessions ("越缩量……胜率越高";
the charts' lower panel is AMO, the amount, so amount is used rather than shares).
Exits (少妇战法1.0), signals at a close, orders at the next open (an open at the limit down cannot sell and waits):
  stop       a close below the B1 day's low minus 0.05 yuan ("只输一根"; its example: low 4.20, stop 4.15);
  time       short-term only: no close at least 3% above the buy price by the third close after buying
             ("三个交易日（或者……5个交易日）还没有脱离成本区"; 5 as a check);
  fall back  short-term only: after a close above the buy price, a close at or below it ("跌回成本价……立刻拍掉");
  half       once above BBI, the second 中大阳线 closing above BBI (up >= 5% on the previous close, close above the
             open) sells half (whole lots: half the lots, nothing if one lot is held);
  BBI        once the stock has closed above BBI after buying, two closes in a row below BBI sell the rest.
  short = stop + time + fall back + half + BBI; medium = stop + half + BBI. A trade still open on the last day is
  valued at the last close. The first full-exit reason in the order stop, time, fall back, BBI is the one counted.
Buying at the open after the B1 close, passed over at the limit up or at or below the stop. Check: buying at the B1
close and selling the half at the close of the second 中大阳线, as the article does on the day.
Not tested: the timing filter (活跃市值 of the 指南针 software is not public data), picking by policy, industry and
leaders, weekly B1, the N-shape stop. Universe: main board and ChiNext, not ST, listed >= 120 days, lines available.

A. Every B1 signal from 2024-07-01 as one trade, no account limits (a stock already in a trade gives no new trade
   until that one ends), 0.2% per round trip: return per trade, sessions held, win rate, mean win and loss, losses
   worse than -10%, gains above +10%, exit reasons; against the same exits from three random stocks of the same day,
   and from three random stocks of the same day with white > yellow; the B1 minus null difference paired by signal
   day, Newey-West t with lag 10; by calendar year. Runs: short (3 and 5 sessions), medium, the shrink variant, and
   the check of buying at the B1 close (part A only).
B. The user's account: 10,000 yuan, commission 0.01% without minimum, stamp duty 0.05% on sales, transfer 0.001%;
   at most 5 names (3 as a check); each buy gets cash / empty places, whole lots, passed over when one lot does not
   fit; the day's B1 signals taken most shrunk first (amount / largest of the previous 20), or in random order (20
   draws); null: random stocks of the same day with the same exits, any stock or one with white > yellow, as many
   candidates as that day's B1 signals (20 draws each); check with 0.1% slippage per order.
   Windows from 2024-07-01 and from 2025-04-28. Reported: annual return, max drawdown, lowest net value and the first
   close below 0.7, 20-session loss profile, beating ChiNext (higher annual return and shallower max drawdown), trades,
   win rate, fees, time invested; references: the plan's five-name rotation, ChiNext, CSI 2000.
C. The article's own eleven B1 examples: whether each meets the rule above, and what the short exits made of it.
"""
import json
from collections import Counter
from pathlib import Path
import sys
import warnings

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import account_names as an  # noqa: E402
from wiki_evidence import ROOT, newey_west_t  # noqa: E402

ra, sd = an.ra, an.ra.sd                     # account_names has set the user's commission (0.01%, no minimum)
h, days, n, codes = an.h, an.days, an.n, an.codes
R, COST, TICK = h['returns'], 0.002, 0.05
FIRST = days.index('2024-07-01')
RECENT = next(t for t in range(FIRST, n, 20) if days[t] >= '2025-04-28')   # same start as round fourteen
BOARD = np.array([c[:2] in ('60', '00', '30') and c.endswith(('.SH', '.SZ')) for c in codes])
row_of = {c: i for i, c in enumerate(codes)}
shape = h['close'].shape
high, low = np.full(shape, np.nan), np.full(shape, np.nan)
differ = 0
for j, day in enumerate(days):
    doc = json.loads((ROOT / f'.generated/market-hl/{day}.json').read_text(encoding='utf-8'))
    assert doc['date'] == day and doc['fields'] == ['ts_code', 'high', 'low', 'close', 'vol']
    for code, hi, lo, c, _ in doc['rows']:
        i = row_of.get(code)
        if i is None or None in (hi, lo, c) or np.isnan(h['close'][i, j]):
            continue
        if abs(c - h['close'][i, j]) > 1e-6:
            differ += 1
            continue
        high[i, j], low[i, j] = hi, lo


def ma(x, k):
    out = np.full(len(x), np.nan)
    if len(x) >= k:
        s = np.cumsum(np.insert(x, 0, 0.0))
        out[k - 1:] = (s[k:] - s[:-k]) / k
    return out


def smooth(x, a):
    """Y = a*X + (1-a)*Y' from the first value: EMA(X,N) with a = 2/(N+1), SMA(X,3,1) with a = 1/3."""
    out, y = [], None
    for v in x.tolist():
        y = v if y is None else a * v + (1 - a) * y
        out.append(y)
    return np.array(out)


WHITE, YELLOW, BBI, K, D, J, F, SHRINK = (np.full(shape, np.nan) for _ in range(8))
view = np.lib.stride_tricks.sliding_window_view
for i in range(len(codes)):
    idx = np.flatnonzero(~np.isnan(h['close'][i]) & ~np.isnan(h['pre'][i]) & ~np.isnan(high[i]) & ~np.isnan(low[i]))
    if len(idx) < 120:
        continue
    raw = h['close'][i, idx]
    adj = raw[0] * np.cumprod(np.r_[1.0, raw[1:] / h['pre'][i, idx[1:]]])   # adjusted for splits and dividends
    f = adj / raw
    lo9 = view(np.r_[np.full(8, np.inf), low[i, idx] * f], 9).min(axis=1)
    hi9 = view(np.r_[np.full(8, -np.inf), high[i, idx] * f], 9).max(axis=1)
    rng = hi9 - lo9
    k_ = smooth(np.where(rng > 0, (adj - lo9) / np.where(rng > 0, rng, 1) * 100, 50.0), 1 / 3)
    d_ = smooth(k_, 1 / 3)
    WHITE[i, idx] = smooth(smooth(adj, 2 / 11), 2 / 11)
    YELLOW[i, idx] = (ma(adj, 14) + ma(adj, 28) + ma(adj, 57) + ma(adj, 114)) / 4
    BBI[i, idx] = (ma(adj, 3) + ma(adj, 6) + ma(adj, 12) + ma(adj, 24)) / 4
    K[i, idx], D[i, idx], J[i, idx], F[i, idx] = k_, d_, 3 * k_ - 2 * d_, f
    amt = h['amount'][i, idx]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        SHRINK[i, idx] = amt / np.nanmax(view(np.r_[np.full(20, np.nan), amt[:-1]], 20), axis=1)
A = h['close'] * F                                          # adjusted close
AMP = (high - low) / h['pre'] * 100
U = h['eligible'] & BOARD[:, None] & ~np.isnan(YELLOW) & ~np.isnan(BBI) & ~np.isnan(A)
with np.errstate(invalid='ignore'):
    TREND = U & (WHITE > YELLOW)
    B1 = TREND & (J < 13) & (R >= -2) & (R <= 1.8) & (AMP <= 7)
    SIGNALS = {'b1': B1, 'shrink': B1 & (SHRINK <= 0.5)}

# Values printed on four of the article's charts: white, yellow (前复权), K, D, J; the article's date for the chart.
CHARTS = {'宁波韵升': ('600366.SH', '2025-08-06', 11.90, 10.81, 27.59, 36.48, 9.83),
          '野马电池': ('605378.SH', '2025-07-31', 20.52, 19.41, 21.78, 25.81, 13.72),
          '澄天伟业': ('300689.SZ', '2025-07-16', 42.43, 40.58, 12.31, 15.48, 5.96),
          '方正科技': ('600601.SH', '2025-07-23', 5.41, 5.11, 25.24, 33.09, 9.53)}
EXAMPLES = [('华纳药厂', '688799.SH', '2025-05-09'), ('宁波韵升', '600366.SH', '2025-08-06'), ('微芯生物', '688321.SH', '2025-06-20'),
            ('方正科技', '600601.SH', '2025-07-23'), ('欧林生物', '688319.SH', '2025-08-12'), ('澄天伟业', '300689.SZ', '2025-07-16'),
            ('国轩高科', '002074.SZ', '2025-08-01'), ('野马电池', '605378.SH', '2025-07-31'), ('光电股份', '600184.SH', '2025-07-10'),
            ('新瀚新材', '301076.SZ', '2025-08-01'), ('昂利康', '002940.SZ', '2025-07-11')]


def check_charts():
    """For each chart, the session within 30 of the article's date whose K, D, J come closest to the printed ones."""
    out = {}
    for name, (code, day, w, y, k, d, jv) in CHARTS.items():
        i, t = row_of[code], days.index(day)
        best = min((t2 for t2 in range(t - 30, t + 31) if not np.isnan(J[i, t2])),
                   key=lambda t2: abs(K[i, t2] - k) + abs(D[i, t2] - d) + abs(J[i, t2] - jv))
        f = F[i, best]
        out[name] = {'date': days[best], 'kdj': [round(float(x[i, best]), 2) for x in (K, D, J)], 'printed_kdj': [k, d, jv],
                     'white_yellow': [round(float(WHITE[i, best] / f), 2), round(float(YELLOW[i, best] / f), 2)], 'printed_white_yellow': [w, y]}
    return out


AO = h['open'] * F                                          # adjusted open
GAP = (h['open'] / h['pre'] - 1) * 100
LIMIT = h['limit']
with np.errstate(invalid='ignore'):
    ABOVE = A > BBI
    BIG = (R >= 5) & (h['close'] > h['open'])


class Hold:
    """Exit signals of one B1 position, on adjusted prices (the same for the trade list and the account)."""

    def __init__(self, i, t, price, mode, window):
        self.i, self.price, self.mode, self.window = i, price, mode, window
        self.stop = (low[i, t] - TICK) * F[i, t]
        self.closes = self.big = self.streak = 0
        self.left_cost = self.was_up = self.seen_above = self.half_done = False

    def at_close(self, s):
        i, c = self.i, A[self.i, s]
        if np.isnan(c):
            return None
        self.closes += 1
        reason = 'stop' if c < self.stop else None
        if self.mode == 'short':
            if not self.left_cost:
                if c >= 1.03 * self.price:
                    self.left_cost = True
                elif self.closes >= self.window and reason is None:
                    reason = 'time'
            if self.was_up and c <= self.price and reason is None:
                reason = 'fall back'
            self.was_up = self.was_up or c > self.price
        if ABOVE[i, s]:
            self.seen_above, self.streak = True, 0
        elif self.seen_above:
            self.streak += 1
            if self.streak >= 2 and reason is None:
                reason = 'BBI'
        if reason is None and not self.half_done and BIG[i, s] and ABOVE[i, s]:
            self.big += 1
            if self.big == 2:
                self.half_done = True
                return 'half'
        return reason


def can_buy(i, d, stop):
    return (d < n and not np.isnan(AO[i, d]) and not np.isnan(A[i, d]) and GAP[i, d] < LIMIT[i] - 0.2 and AO[i, d] > stop)


def can_sell(i, s):
    return not np.isnan(AO[i, s]) and not np.isnan(A[i, s]) and GAP[i, s] > -(LIMIT[i] - 0.2)


def trade(i, t, mode='short', entry='open', window=3):
    """One trade from a signal at the close of t, fractional halves, 0.2% per round trip; None if it cannot be bought."""
    stop = (low[i, t] - TICK) * F[i, t]
    if entry == 'open':
        if not can_buy(i, t + 1, stop):
            return None
        price, begin = AO[i, t + 1], t + 1
    else:
        price, begin = A[i, t], t + 1
    pos, left, value, pending = Hold(i, t, price, mode, window), 1.0, 0.0, None
    for s in range(begin, n):
        if pending and can_sell(i, s):                      # orders decided at the previous close
            frac = left / 2 if pending == 'half' else left
            value, left = value + frac * AO[i, s] / price, left - frac
            if pending != 'half':
                return {'ret': value - 1 - COST, 'held': s - t, 'reason': pending, 'half': pos.half_done}
            pending = None
        signal = pos.at_close(s)
        if signal == 'half' and entry == 'close':
            value, left = value + left / 2 * A[i, s] / price, left / 2
        elif signal == 'half':
            pending = pending or 'half'
        elif signal and pending in (None, 'half'):
            pending = signal
    last = max((s for s in range(begin, n) if not np.isnan(A[i, s])), default=t)
    return {'ret': value + left * A[i, last] / price - 1 - COST, 'held': last - t, 'reason': 'end', 'half': pos.half_done}


def stats(rets, held=None, reasons=None):
    r = np.asarray(rets, dtype=float)
    if not len(r):
        return {'trades': 0}
    out = {'trades': int(len(r)), 'mean_pct': round(float(r.mean() * 100), 2), 'median_pct': round(float(np.median(r) * 100), 2),
           'win_share': round(float((r > 0).mean()), 3), 'mean_win_pct': round(float(r[r > 0].mean() * 100), 2) if (r > 0).any() else None,
           'mean_loss_pct': round(float(r[r <= 0].mean() * 100), 2) if (r <= 0).any() else None,
           'loss_over_10_share': round(float((r < -0.10).mean()), 3), 'gain_over_10_share': round(float((r > 0.10).mean()), 3),
           'worst_pct': round(float(r.min() * 100), 1), 'best_pct': round(float(r.max() * 100), 1)}
    if held is not None:
        out['held_mean'] = round(float(np.mean(held)), 1)
    if reasons is not None:
        out['reasons'] = dict(Counter(reasons).most_common())
    return out


def draw(rng, pool, t, mode, entry, window, want=3, tries=10):
    rets = []
    for j in pool[rng.integers(len(pool), size=tries)] if len(pool) else ():
        r = trade(int(j), t, mode, entry, window)
        if r is not None:
            rets.append(r['ret'])
            if len(rets) == want:
                break
    return rets


def trade_list(signal, mode='short', entry='open', window=3):
    """Part A: one position per stock at a time; each B1 trade paired with random stocks of the same day."""
    rng = np.random.default_rng(0)
    rows, busy = [], np.full(len(codes), -1)
    for t in range(FIRST, n - 1):
        hits = np.flatnonzero(signal[:, t])
        if not len(hits):
            continue
        pool_u, pool_t = np.flatnonzero(U[:, t]), np.flatnonzero(TREND[:, t])
        for i in hits:
            if t <= busy[i]:
                continue
            r = trade(int(i), t, mode, entry, window)
            if r is None:
                continue
            busy[i] = t + r['held']
            rows.append({**r, 't': t, 'any': draw(rng, pool_u, t, mode, entry, window), 'trend': draw(rng, pool_t, t, mode, entry, window)})
    out = {'b1': stats([x['ret'] for x in rows], [x['held'] for x in rows], [x['reason'] for x in rows]),
           'half_share': round(float(np.mean([x['half'] for x in rows])), 3) if rows else None}
    for key in ('any', 'trend'):
        out[f'null_{key}'] = stats([v for x in rows for v in x[key]])
        paired = [x for x in rows if x[key]]
        by_day = {}
        for x in paired:
            by_day.setdefault(x['t'], []).append(x['ret'] - np.mean(x[key]))
        series = [float(np.mean(v)) for _, v in sorted(by_day.items())]
        out[f'minus_{key}'] = {'pairs': len(paired), 'mean_pp': round(float(np.mean(series)) * 100, 2) if series else None,
                               'nw_t': round(newey_west_t(series, 10), 2) if len(series) > 13 else None}
    for year in ('2024', '2025', '2026'):
        part = [x for x in rows if days[x['t']].startswith(year)]
        out[year] = {'trades': len(part), 'mean_pct': round(float(np.mean([x['ret'] for x in part])) * 100, 2) if part else None,
                     'null_any_pct': round(float(np.mean([v for x in part for v in x['any']])) * 100, 2) if part else None,
                     'win_share': round(float(np.mean([x['ret'] > 0 for x in part])), 3) if part else None}
    return out


def account(signal, first, k=5, order='shrink', seed=None, mode='short', window=3, slip=0.0, null=None):
    """Part B: the user's account, net value from 1."""
    rng = np.random.default_rng(seed)
    start_cash = cash = 10_000.0
    pos, nav, fees, invested, done, skips, floor_day = {}, [1.0], 0.0, [], [], 0, None
    for d in range(first + 1, n):
        t = d - 1
        for i in sorted(pos):                                   # sales at the open, decided at the previous close
            p = pos[i]
            if not p['pending'] or not can_sell(i, d):
                continue
            if p['pending'] == 'half' and p['lots'] < 2:
                p['pending'] = None
                continue
            part = (p['lots'] // 2) / p['lots'] if p['pending'] == 'half' else 1.0
            gross = p['value'] * part * h['open'][i, d] / h['pre'][i, d] * (1 - slip)
            cost = ra.fee(gross, 0.0, True)
            cash, fees, p['back'] = cash + gross - cost, fees + cost, p['back'] + gross - cost
            if p['pending'] == 'half':
                p['value'], p['lots'], p['pending'] = p['value'] * (1 - part), p['lots'] - p['lots'] // 2, None
            else:
                done.append((p['back'] / p['paid'] - 1, d - p['day'], p['pending']))
                del pos[i]
        if len(pos) < k:
            cand = [int(i) for i in np.flatnonzero(signal[:, t])]
            if null is not None and cand:
                pool = np.flatnonzero(null[:, t])
                cand = [int(i) for i in rng.choice(pool, size=min(len(cand), len(pool)), replace=False)]
            elif order == 'shrink':
                cand.sort(key=lambda i: (np.inf if np.isnan(SHRINK[i, t]) else SHRINK[i, t], i))
            else:
                cand = [int(i) for i in rng.permutation(cand)]
            for i in cand:
                if len(pos) >= k:
                    break
                if i in pos or not can_buy(i, d, (low[i, t] - TICK) * F[i, t]):
                    continue
                price, budget = h['open'][i, d] * (1 + slip), cash / (k - len(pos))
                shares = np.floor(budget / (price * 100)) * 100
                while shares > 0 and shares * price + ra.fee(shares * price, 0.0, False) > budget:
                    shares -= 100
                if shares <= 0:
                    skips += 1
                    continue
                cost = ra.fee(shares * price, 0.0, False)
                cash, fees = cash - shares * price - cost, fees + cost
                pos[i] = {'value': shares * h['close'][i, d], 'lots': int(shares // 100), 'pending': None, 'paid': shares * price + cost,
                          'back': 0.0, 'day': d, 'new': True, 'hold': Hold(i, t, AO[i, d] * (1 + slip), mode, window)}
        for i, p in pos.items():                                 # the close
            c, pc = h['close'][i, d], h['pre'][i, d]
            if not p.pop('new', False) and not (np.isnan(c) or np.isnan(pc)):
                p['value'] *= c / pc
            signal_ = p['hold'].at_close(d)
            if signal_ == 'half':
                p['pending'] = p['pending'] or 'half'
            elif signal_ and p['pending'] in (None, 'half'):
                p['pending'] = signal_
        stock = sum(p['value'] for p in pos.values())
        nav.append((cash + stock) / start_cash)
        invested.append(stock / (cash + stock))
        if floor_day is None and nav[-1] < 0.7:
            floor_day = days[d]
    done += [((p['back'] + p['value']) / p['paid'] - 1, n - 1 - p['day'], 'end') for p in pos.values()]
    nav, decisions = np.array(nav), list(range(first, n - 1, 20))
    prof = ra.profile(nav, days[first:], decisions, first)
    ref = ra.profile(ra.chinext_window(first), days[first:], decisions, first)
    out = {'cagr_pct': round(prof['cagr_pct'], 2), 'max_drawdown_pct': round(prof['max_drawdown_pct'], 2),
           'lowest_nav': round(prof['lowest_nav'], 3), 'final_nav': round(float(nav[-1]), 3), 'below_0.7_on': floor_day,
           'beats_chinext': bool(prof['cagr_pct'] > ref['cagr_pct'] and prof['max_drawdown_pct'] > ref['max_drawdown_pct']),
           'periods': {key: prof[key] for key in ('periods', 'small_loss', 'medium_loss', 'big_loss', 'big_gain')},
           'losing_share': round(prof['losing_share'], 3), 'fees_pct_of_start': round(fees / start_cash * 100, 2),
           'invested_pct': round(float(np.mean(invested)) * 100, 1), 'lot_skips': skips}
    out.update(stats([x[0] for x in done], [x[1] for x in done], [x[2] for x in done]))
    return out


def examples():
    out = []
    for name, code, day in EXAMPLES:
        i, t = row_of[code], days.index(day)
        meets = bool(WHITE[i, t] > YELLOW[i, t] and J[i, t] < 13 and -2 <= R[i, t] <= 1.8 and AMP[i, t] <= 7)
        row = {'name': name, 'code': code, 'date': day, 'meets_b1': meets, 'white_over_yellow': bool(WHITE[i, t] > YELLOW[i, t]),
               'j': round(float(J[i, t]), 2), 'change_pct': round(float(R[i, t]), 2), 'amplitude_pct': round(float(AMP[i, t]), 2),
               'amount_vs_top20': round(float(SHRINK[i, t]), 2)}
        for entry in ('open', 'close'):
            r = trade(i, t, 'short', entry)
            row[entry] = None if r is None else {'ret_pct': round(r['ret'] * 100, 1), 'held': r['held'], 'reason': r['reason'], 'end': days[min(t + r['held'], n - 1)]}
        out.append(row)
    return out


def refs(first):
    span, decisions, out = days[first:], list(range(first, n - 1, 20)), {}
    for name, series in (('chinext', sd.chinext), ('csi2000', sd.c2000)):
        p = ra.profile(series[first:] / series[first], span, decisions, first)
        out[name] = {'cagr_pct': round(p['cagr_pct'], 2), 'max_drawdown_pct': round(p['max_drawdown_pct'], 2), 'lowest_nav': round(p['lowest_nav'], 3)}
    plan = an.simulate(5, first, 0)
    out['plan_5'] = {key: plan[key] for key in ('cagr_pct', 'max_drawdown_pct', 'lowest_nav', 'beats_chinext')}
    return out


A_RUNS = {'B1|short3|open': ('b1', 'short', 'open', 3), 'B1|short5|open': ('b1', 'short', 'open', 5),
          'B1|medium|open': ('b1', 'medium', 'open', 3), 'shrink|short3|open': ('shrink', 'short', 'open', 3),
          'B1|short3|close': ('b1', 'short', 'close', 3)}
B_RUNS = {'B1|short3|5': {}, 'B1|short5|5': {'window': 5}, 'B1|medium|5': {'mode': 'medium'},
          'shrink|short3|5': {'signal': 'shrink'}, 'B1|short3|3': {'k': 3}, 'B1|short3|5|slip0.1%': {'slip': 0.001}}


def spread(runs):
    c = np.array([x['cagr_pct'] for x in runs])
    return {'median': round(float(np.median(c)), 1), 'low': round(float(c.min()), 1), 'high': round(float(c.max()), 1),
            'mdd_median': round(float(np.median([x['max_drawdown_pct'] for x in runs])), 1),
            'lowest_nav': round(min(x['lowest_nav'] for x in runs), 3), 'beats_chinext': sum(x['beats_chinext'] for x in runs),
            'win_share_median': round(float(np.median([x['win_share'] for x in runs])), 3)}


def main():
    out = {'high_low_close_differ': differ, 'signals_per_day': {}, 'charts': check_charts(), 'examples': examples(), 'trades': {}, 'account': {}}
    print('closes that differ from the frozen history:', differ, flush=True)
    for name, row in out['charts'].items():
        print('chart', name, row, flush=True)
    for row in out['examples']:
        print('example', row, flush=True)
    for key, mask in SIGNALS.items():
        per_day = mask[:, FIRST:n - 1].sum(axis=0)
        out['signals_per_day'][key] = {'mean': round(float(per_day.mean()), 1), 'median': float(np.median(per_day)),
                                       'zero_days': int((per_day == 0).sum()), 'days': int(len(per_day))}
    print('signals per day', out['signals_per_day'], flush=True)
    for label, (sig, mode, entry, window) in A_RUNS.items():
        out['trades'][label] = trade_list(SIGNALS[sig], mode, entry, window)
        print('trades', label, json.dumps(out['trades'][label], ensure_ascii=False), flush=True)
    for window, first in (('from_2024-07', FIRST), ('from_2025-04-28', RECENT)):
        block = {'refs': refs(first), 'runs': {}}
        print(window, 'refs', block['refs'], flush=True)
        for label, kw in B_RUNS.items():
            kw = dict(kw)
            block['runs'][label] = account(SIGNALS[kw.pop('signal', 'b1')], first, **kw)
            print(window, label, json.dumps(block['runs'][label], ensure_ascii=False), flush=True)
        for label, kw in (('B1 random order', {'order': 'random'}), ('null any', {'null': U}), ('null trend', {'null': TREND})):
            runs = [account(B1, first, seed=seed, **kw) for seed in range(20)]
            block['runs'][label] = {'spread': spread(runs), 'runs': [{key: x[key] for key in ('cagr_pct', 'max_drawdown_pct', 'lowest_nav', 'win_share')} for x in runs]}
            print(window, label, block['runs'][label]['spread'], flush=True)
        out['account'][window] = block
    (HERE / 'b1_point.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written b1_point.json')


if __name__ == '__main__':
    main()
