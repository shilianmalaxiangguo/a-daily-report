"""Fetch daily bars of the comparison indices into the local backtest history (explicit dates, re-validated)."""
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'scripts'))
from market_data.tushare_client import create_tushare_pro_api  # noqa: E402
from report.market_returns import _pages  # noqa: E402

INDICES = {'399006.SZ': '创业板指', '000688.SH': '科创50', '000300.SH': '沪深300', '000001.SH': '上证指数',
           '399001.SZ': '深证成指', '000852.SH': '中证1000', '932000.CSI': '中证2000', '000922.CSI': '中证红利'}
start, end = sys.argv[2], sys.argv[3]
pro = create_tushare_pro_api(timeout_seconds=60)
now = datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
out = {'retrieved_at': now, 'start': start, 'end': end, 'source': 'tushare.index_daily', 'indices': {}}
for code, name in INDICES.items():
    try:
        rows = _pages(pro, 'index_daily', ts_code=code, start_date=start.replace('-', ''), end_date=end.replace('-', ''),
                      fields='ts_code,trade_date,open,high,low,close,pre_close,amount')
    except Exception as error:
        print(code, name, 'FAILED', type(error).__name__, str(error)[:120])
        continue
    rows = sorted(rows, key=lambda r: r['trade_date'])
    days = [r['trade_date'] for r in rows]
    assert days == sorted(set(days)), code
    assert all(r['ts_code'] == code for r in rows), code
    out['indices'][code] = {'name': name, 'rows': rows}
    print(code, name, len(rows), days[0] if days else None, days[-1] if days else None)
target = ROOT / '.generated/backtest-history/indices.json'
target.write_text(json.dumps(out, ensure_ascii=False), encoding='utf-8')
print('written', target.relative_to(ROOT), len(out['indices']))
