"""C6: can "buy small" be repeated at all once it is traded the way a person could (declared before running)?

Every 20 sessions, on decision day t, rank eligible stocks (not ST, listed >= 120 days) by average turnover over
sessions t-19..t. Baskets: the lowest fifth ("small"), the highest fifth ("large"), and all eligible stocks.
Buy each basket equally at the open of t+1 (names opening at the limit cannot be bought and are skipped), hold to
the close of t+20, pay 0.2% round trip for the whole basket every period, then form the next basket on t+20.
A suspended day counts as no change. Five start offsets (0, 4, 8, 12, 16 sessions) so a single lucky start
does not decide the answer. Two windows: decisions from 2024-03-04 (the backtest window) and from the first
session with 20 sessions of turnover (2024-01-31, so the February 2024 small-cap fall is inside).
"""
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, load  # noqa: E402
from report.strategy_backtest import _metrics  # noqa: E402

PERIOD, COST = 20, 0.002
h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
days, n = h['days'], len(h['days'])
amount, eligible = h['amount'], h['eligible']
filled = np.where(np.isnan(amount), 0, amount)
cs = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(filled, axis=1)], axis=1)
cnt = np.concatenate([np.zeros((amount.shape[0], 1)), np.cumsum(~np.isnan(amount), axis=1)], axis=1)
avg20 = np.full(amount.shape, np.nan)
avg20[:, 19:] = (cs[:, 20:] - cs[:, :-20]) / np.maximum(cnt[:, 20:] - cnt[:, :-20], 1)    # sessions t-19..t
growth = np.where(np.isnan(h['returns']), 0.0, h['returns'] / 100)


def basket_period(members, t):
    """Equal-weight return from the open of t+1 to the close of t+PERIOD, minus the round-trip cost."""
    values = []
    for i in members:
        o, pc, c = h['open'][i, t + 1], h['pre'][i, t + 1], h['close'][i, t + 1]
        if np.isnan(o) or np.isnan(pc) or np.isnan(c) or (o / pc - 1) * 100 >= h['limit'][i] - 0.2:
            continue
        values.append(c / o * np.prod(1 + growth[i, t + 2:t + PERIOD + 1]) - 1)
    return (float(np.mean(values)) - COST) if values else 0.0, len(values)


def run(first, offset):
    decisions = list(range(first + offset, n - PERIOD, PERIOD))
    curves = {k: [1.0] for k in ('small', 'large', 'all')}
    dates = [days[decisions[0]]]
    sizes, liquidity = [], []
    for t in decisions:
        ok = eligible[:, t] & ~np.isnan(avg20[:, t]) & ~np.isnan(h['close'][:, t])
        q20, q80 = np.quantile(avg20[ok, t], [0.2, 0.8])
        groups = {'small': np.flatnonzero(ok & (avg20[:, t] <= q20)), 'large': np.flatnonzero(ok & (avg20[:, t] >= q80)),
                  'all': np.flatnonzero(ok)}
        for k, members in groups.items():
            value, bought = basket_period(members, t)
            curves[k].append(curves[k][-1] * (1 + value))
        sizes.append(len(groups['small']))
        liquidity.append(float(np.median(avg20[groups['small'], t])) / 1e5)          # thousand yuan -> 1e8 yuan
        dates.append(days[t + PERIOD])
    out = {}
    for k, curve in curves.items():
        curve = np.array(curve)
        years = (len(curve) - 1) * PERIOD / 252
        peak = np.maximum.accumulate(curve)
        per = curve[1:] / curve[:-1] - 1
        out[k] = {'cagr_pct': round(float((curve[-1] ** (1 / years) - 1) * 100), 2),
                  'max_drawdown_pct': round(float((curve / peak - 1).min() * 100), 2),
                  'sharpe': round(float(per.mean() / per.std(ddof=1) * np.sqrt(252 / PERIOD)), 2),
                  'periods': len(per)}
        by_year = {}
        for year in ('2024', '2025', '2026'):
            idx = [k for k, d in enumerate(dates) if d.startswith(year) and k > 0]
            if idx:
                by_year[year] = round(float((curve[idx[-1]] / curve[idx[0] - 1] - 1) * 100), 1)
        out[k]['years_by_period_end'] = by_year
        design = [k for k, d in enumerate(dates) if d >= '2026-07-28' and k > 0]
        out[k]['periods_ending_from_2026-07-28_pct'] = round(float((curve[design[-1]] / curve[design[0] - 1] - 1) * 100), 1)
    out['small_basket_size_median'] = int(np.median(sizes))
    out['small_basket_turnover_median_yi'] = round(float(np.median(liquidity)), 3)
    out['span'] = [dates[0], dates[-1]]
    return out


result = {'inputs_sha256': h['inputs_sha256'], 'period_sessions': PERIOD, 'round_trip_cost_pct': COST * 100, 'windows': {}}
for label, first in (('from_2024-03-04', days.index('2024-03-04')), ('from_2024-01-31', 19)):
    runs = {offset: run(first, offset) for offset in (0, 4, 8, 12, 16)}
    summary = {k: {m: {'mean': round(float(np.mean([r[k][m] for r in runs.values()])), 2),
                       'min': round(float(min(r[k][m] for r in runs.values())), 2),
                       'max': round(float(max(r[k][m] for r in runs.values())), 2)}
                   for m in ('cagr_pct', 'max_drawdown_pct', 'sharpe')} for k in ('small', 'large', 'all')}
    result['windows'][label] = {'summary': summary, 'runs': runs}
out = Path(__file__).with_name('small_cap_rule.json')
out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
for label, block in result['windows'].items():
    print(label, json.dumps(block['summary'], ensure_ascii=False))
    print('  basket size', block['runs'][0]['small_basket_size_median'], 'median turnover (yi)', block['runs'][0]['small_basket_turnover_median_yi'],
          'span', block['runs'][0]['span'])


# C7 (declared with C6, run after it): the same rule when an account can only hold 10 names - each decision picks
# 10 at random from the small basket (seeds 0..19, start offset 0), everything else unchanged.
def run_ten(first, seed):
    rng = np.random.default_rng(seed)
    decisions = list(range(first, n - PERIOD, PERIOD))
    curve = [1.0]
    for t in decisions:
        ok = eligible[:, t] & ~np.isnan(avg20[:, t]) & ~np.isnan(h['close'][:, t])
        q20 = np.quantile(avg20[ok, t], 0.2)
        members = rng.permutation(np.flatnonzero(ok & (avg20[:, t] <= q20)))[:10]
        value, _ = basket_period(members, t)
        curve.append(curve[-1] * (1 + value))
    curve = np.array(curve)
    years = (len(curve) - 1) * PERIOD / 252
    return {'cagr_pct': round(float((curve[-1] ** (1 / years) - 1) * 100), 2),
            'max_drawdown_pct': round(float((curve / np.maximum.accumulate(curve) - 1).min() * 100), 2)}


ten = {}
for label, first in (('from_2024-03-04', days.index('2024-03-04')), ('from_2024-01-31', 19)):
    runs = [run_ten(first, seed) for seed in range(20)]
    ten[label] = {'runs': runs, **{m: {'median': round(float(np.median([r[m] for r in runs])), 2),
                                       'min': round(float(min(r[m] for r in runs)), 2),
                                       'max': round(float(max(r[m] for r in runs)), 2)} for m in ('cagr_pct', 'max_drawdown_pct')},
                  'negative_runs': sum(r['cagr_pct'] < 0 for r in runs)}
result['ten_names'] = ten
out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
for label, block in ten.items():
    print('ten names', label, {k: block[k] for k in ('cagr_pct', 'max_drawdown_pct', 'negative_runs')})
