"""Prints the comparison, style and article-check tables used in the Wiki from market_checks.json and small_cap_rule.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
mc = json.loads((HERE / 'market_checks.json').read_text(encoding='utf-8'))
sc = json.loads((HERE / 'small_cap_rule.json').read_text(encoding='utf-8'))


def pct(v, digits=1):
    return '—' if v is None else f"{v:+.{digits}f}%"


print('表6 对照指数\n')
print('| 持有 | 年化（2024-03-04起） | 最大回撤 | 夏普 | 2024（3月起） | 2025 | 2026（至10-29） | 年化（2024-01-02起） |')
print('|---|---|---|---|---|---|---|---|')
a, b = mc['C1']['from_2024-03-04'], mc['C1']['from_2024-01-02']
for code in ('000985.CSI', '399006.SZ', '000688.SH', '000300.SH', '000001.SH', '000852.SH', '932000.CSI', '000922.CSI', 'equal_weight'):
    v, w = a[code], b[code]
    name = v['name'] if code != 'equal_weight' else '等权平均全部可交易A股（理论参照）'
    print(f"| {name} | {pct(v['cagr_pct'])} | {pct(v['max_drawdown_pct'])} | {v['sharpe']:.2f} | {pct(v['years']['2024'])} | "
          f"{pct(v['years']['2025'])} | {pct(v['years']['2026'])} | {pct(w['cagr_pct'])} |")

print('\n表7 每20个交易日换一次的成交额分组（次日开盘买、扣来回0.2%、5个起点）\n')
print('| 分组 | 区间 | 年化平均（最低至最高） | 最大回撤平均 | 夏普平均 |')
print('|---|---|---|---|---|')
for window, label in (('from_2024-03-04', '2024-03-04起'), ('from_2024-01-31', '2024-01-31起，含2024年2月小盘大跌')):
    summary = sc['windows'][window]['summary']
    for k, name in (('small', '成交额最小五分之一'), ('large', '成交额最大五分之一'), ('all', '全部可交易股票')):
        s = summary[k]
        print(f"| {name} | {label} | {pct(s['cagr_pct']['mean'])}（{pct(s['cagr_pct']['min'])}至{pct(s['cagr_pct']['max'])}） | "
              f"{pct(s['max_drawdown_pct']['mean'])} | {s['sharpe']['mean']:.2f} |")
run0 = sc['windows']['from_2024-03-04']['runs']['0']
print('\n起点0（2024-03-04起）分年份：' + '；'.join(
    f"{name} " + '、'.join(f"{y} {pct(v)}" for y, v in run0[k]['years_by_period_end'].items()) + f"，2026年7月下旬以来 {pct(run0[k]['periods_ending_from_2026-07-28_pct'])}"
    for k, name in (('small', '最小五分之一'), ('large', '最大五分之一'), ('all', '全部'))))
print(f"最小五分之一每期约 {run0['small_basket_size_median']} 只，20日日均成交额中位 {run0['small_basket_turnover_median_yi']} 亿元。")
for window, label in (('from_2024-03-04', '2024-03-04起'), ('from_2024-01-31', '2024-01-31起')):
    t = sc['ten_names'][window]
    print(f"只买10只（从最小五分之一随机挑，20次），{label}：年化中位 {pct(t['cagr_pct']['median'])}（{pct(t['cagr_pct']['min'])}至{pct(t['cagr_pct']['max'])}），"
          f"最大回撤中位 {pct(t['max_drawdown_pct']['median'])}（{pct(t['max_drawdown_pct']['min'])}至{pct(t['max_drawdown_pct']['max'])}），亏钱的次数 {t['negative_runs']}/20")

print('\n表8 每日等权、不计成本的理论分组（2024-03-04起）\n')
print('| 分组 | 年化 | 最大回撤 | 2024 | 2025 | 2026 | 2026-07-28至10-29 |')
print('|---|---|---|---|---|---|---|')
for k in ('st', 'small', 'large', 'non_st'):
    v, d = mc['C3']['window'][k], mc['C3']['design_2026-07-28'][k]
    print(f"| {v['name']} | {pct(v['cagr_pct'])} | {pct(v['max_drawdown_pct'])} | {pct(v['years']['2024'])} | {pct(v['years']['2025'])} | "
          f"{pct(v['years']['2026'])} | {pct(d['total_pct'])} |")
print(f"ST股每天约 {mc['C3']['st_count_median']} 只。")

print('\n表9 成交额高低之后5个交易日（次日开盘进场）\n')
print('| 当天成交额在近120日的位置 | 天数 | 中证全指 | 等权平均 |')
print('|---|---|---|---|')
for g, name in (('low', '低（30%以下）'), ('mid', '中间'), ('high', '高（90%以上）')):
    v = mc['C4']['forward_5'][g]
    print(f"| {name} | {v['days']} | {v['index']['mean_pct']:+.2f}%（t {v['index']['nw_t']:.1f}） | {v['equal_weight']['mean_pct']:+.2f}%（t {v['equal_weight']['nw_t']:.1f}） |")
for name, key in (('中证全指', 'index'), ('等权平均', 'equal_weight')):
    t = mc['C4']['timing'][key]
    print(f"{name}：只在成交额中间时持有，年化 {pct(t['timed']['cagr_pct'])}、最大回撤 {pct(t['timed']['max_drawdown_pct'])}；一直持有年化 {pct(t['held']['cagr_pct'])}、"
          f"最大回撤 {pct(t['held']['max_drawdown_pct'])}；在场 {t['in_market_share'] * 100:.0f}%，进出 {t['switches']} 次")
print('最近10个交易日的成交额位置：' + '、'.join(f"{d[5:]} {v}" for d, v in mc['C4']['latest'].items()))

c5 = mc['C5']
print(f"\n表10 红利：中证红利对中证全指的贝塔 {c5['beta_to_csi_all']}；中证全指单日跌超1%的 {c5['big_down_days']} 天，中证红利平均 {c5['div_on_big_down_pct']:+.2f}%，"
      f"中证全指平均 {c5['csi_all_on_big_down_pct']:+.2f}%。2026-07-27至10-29：" + '、'.join(
          f"{ {'000922.CSI': '中证红利', '000985.CSI': '中证全指', '399006.SZ': '创业板指', '000688.SH': '科创50', '932000.CSI': '中证2000'}[k]} {v:+.1f}%"
          for k, v in c5['design_period'].items()))

c2 = mc['C2']
ch, hs = c2['chinext_four_months'], c2['csi300_bear']
print(f"\n表11 材料核对：创业板指2026年高点 {ch['year_peak'][0]} {ch['year_peak'][1]:.2f}，之后最低 {ch['low_after_peak'][0]} {ch['low_after_peak'][1]:.2f}"
      f"（{ch['peak_to_low_pct']:+.1f}%），10-28收 {ch['close_10-28']:.2f}（较高点 {ch['peak_to_10-28_pct']:+.1f}%；{ch['four_months'][0]}至{ch['four_months'][1]} {ch['four_months'][2]:+.1f}%）。"
      f"沪深300 6月高点 {hs['june_peak'][0]} {hs['june_peak'][1]:.2f}，10月最低收盘 {hs['october_low'][0]} {hs['october_low'][1]:.2f}（{hs['drawdown_pct']:+.1f}%），"
      f"10-26至10-29收盘 " + '、'.join(f"{v:.0f}" for v in hs['closes_10-26_to_10-29'].values()) + '。')
print('连续周跌（含截至10-29的本周）：' + '、'.join(f"{v['name']} {v['streak_incl_week_to_10-29']}周" for v in c2['weekly_streaks'].values()))
d = c2['decliners_last60']
print(f"最近60个交易日：下跌超过5000家 {d['days_over_5000']} 天，超过4000家 {d['days_over_4000']} 天，下跌家数中位 {d['median_decliners']}（样本中位 {d['median_universe']} 只）。")
