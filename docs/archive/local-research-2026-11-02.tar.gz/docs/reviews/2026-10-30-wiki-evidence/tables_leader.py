"""Prints the round-ten leader table from leader_lives.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'leader_lives.json').read_text(encoding='utf-8'))
LABEL = {'relay_2': '2连板后，下一个交易日开盘买', 'relay_3': '3连板后，下一个交易日开盘买', 'relay_4': '4连板后，下一个交易日开盘买',
         'relay_5+': '5连板及以上后，下一个交易日开盘买', 'top_board': '空间龙头（当天连板最高、至少3板），下一个交易日开盘买',
         'first_break': '3连板以上第一次断板，当天收盘买（“多条命”）'}


def pct(v):
    return f"{v:+.2f}%"


print('表30 龙头战法能用日线检验的部分（2024-01至2026-10，全部非ST、上市满120天的股票；扣来回0.2%）\n')
print('| 做法 | 次数 | 持有1天：平均 | 胜率 | 持有5天：平均 | 中位数 | 胜率 | 5天内亏超10%的比例 | 5天相对中证全指 | 2026年持有1天：平均（次数） | 开盘就涨停、买不到 |')
print('|---|---|---|---|---|---|---|---|---|---|---|')
for key, label in LABEL.items():
    one, five = r['results'][key]['1'], r['results'][key]['5']
    a1, a5, y = one['all'], five['all'], one['2026']
    skipped = r['skipped_opening_at_limit'][key]
    print(f"| {label} | {a1['trades']} | {pct(a1['mean_pct'])} | {a1['win_share'] * 100:.0f}% | {pct(a5['mean_pct'])} | {pct(a5['median_pct'])} | "
          f"{a5['win_share'] * 100:.0f}% | {a5['loss_over_10_share'] * 100:.0f}% | {a5['mean_excess_pp']:+.2f}个百分点 | {pct(y['mean_pct'])}（{y['trades']}） | "
          f"{skipped if key != 'first_break' else '—'} |")
