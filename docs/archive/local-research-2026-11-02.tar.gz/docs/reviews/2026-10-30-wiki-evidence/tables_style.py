"""Prints the style-switching, state-fund flow and 10,000-yuan account tables used in the Wiki."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
sr = json.loads((HERE / 'style_rotation.json').read_text(encoding='utf-8'))
acct = json.loads((HERE / 'small_cap_account.json').read_text(encoding='utf-8'))
mix = json.loads((HERE / 'account_mix.json').read_text(encoding='utf-8'))


def pct(v, digits=1):
    return f"{v:+.{digits}f}%"


print('表12 风格切换与趋势：全部37种写法（2024-09-02起；扣成本；现金年化1.5%）\n')
print('| 写法 | 年化 | 最大回撤 | 2026-07起大跌期间 | 2024-09反弹期间 | 进出次数 | 2024-07-01起年化 |')
print('|---|---|---|---|---|---|---|')
for name, v in sr['variants'].items():
    u, a, e = v['from_2024-09-02'], v['from_2024-07-01'], v['episodes']
    label = name.replace('H|事后看|', '事后看：').replace('A|', '趋势：').replace('B|', '轮动：').replace('C|', '二选一：').replace('H|', '事后看：').replace('持有|', '一直持有：').replace('|', '，')
    print(f"| {label} | {pct(u['cagr_pct'])} | {pct(u['max_drawdown_pct'])} | {pct(e['2026-07起大跌'])} | {pct(e['2024-09反弹'])} | {u['switches']} | {pct(a['cagr_pct'])} |")

print('\n表13 五只沪深300、上证50 ETF的月度净申购（亿元，份额变化乘当日价格）\n')
monthly = sr['flows']['monthly_net_yi']
print('| 月份 | 净申购 |')
print('|---|---|')
for month in ('2024-01', '2024-02', '2024-07', '2024-08', '2025-04', '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06',
              '2026-07', '2026-08', '2026-09', '2026-10'):
    print(f"| {month} | {monthly[month]:+.0f} |")
print('20日净赎回超过10%的月份：' + '、'.join(sr['flows']['months_over_10pct']))

print('\n表14 按真实账户照做，换算成净值（初始净值1；按1万元本金、整手、每笔佣金最低5元模拟，另列免五；20次随机）\n')
print('| 做法 | 起点 | 期末净值中位（最低至最高） | 年化中位 | 最大回撤中位（最差） | 净值最低（中位／最差） | 跌破0.8的次数 | 跌破0.7的次数 |')
print('|---|---|---|---|---|---|---|---|')
for window, label in (('from_2024-09-02', '2024-09-02'), ('from_2024-01-31', '2024-01-31，含2024年2月小盘大跌')):
    for fee_label, b in acct['windows'][window].items():
        print(f"| 全部做小盘轮换（5只、股价≤20元，{fee_label}） | {label} | {b['final']['median'] / 1e4:.2f}（{b['final']['min'] / 1e4:.2f}至{b['final']['max'] / 1e4:.2f}） | "
              f"{pct(b['cagr_pct']['median'])} | {pct(b['max_drawdown_pct']['median'])}（{pct(b['max_drawdown_pct']['min'])}） | "
              f"{b['lowest']['median'] / 1e4:.2f}／{b['lowest']['min'] / 1e4:.2f} | {b['below_8000']}/20 | {b['below_7000']}/20 |")
names = {'T10000': '全部做创业板指趋势', 'T6000_S4000': '六成创业板指趋势＋四成小盘轮换（4只、股价≤10元）',
         'T5000_S5000': '五成创业板指趋势＋五成小盘轮换（5只、股价≤10元）', 'S10000': '全部做小盘轮换（5只、股价≤20元）'}
for window, label in (('from_2024-09-02', '2024-09-02'), ('from_2024-01-31', '2024-01-31，含2024年2月小盘大跌')):
    for key, b in mix['windows'][window].items():
        runs = b['runs']
        final = f"{b['final']['median'] / 1e4:.2f}" if runs == 1 else f"{b['final']['median'] / 1e4:.2f}（{b['final']['min'] / 1e4:.2f}至{b['final']['max'] / 1e4:.2f}）"
        worst = '' if runs == 1 else f"（{pct(b['max_drawdown_pct']['min'])}）"
        lowest = f"{b['lowest']['median'] / 1e4:.2f}" if runs == 1 else f"{b['lowest']['median'] / 1e4:.2f}／{b['lowest']['min'] / 1e4:.2f}"
        print(f"| {names[key]} | {label} | {final} | "
              f"{pct(b['cagr_pct']['median'])} | {pct(b['max_drawdown_pct']['median'])}{worst} | "
              f"{lowest} | {b['below_8000']}/{runs} | {b['below_7000']}/{runs} |")
