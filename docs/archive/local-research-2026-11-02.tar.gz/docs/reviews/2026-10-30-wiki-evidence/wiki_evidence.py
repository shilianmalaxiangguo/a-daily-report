"""Two checks of Wiki claims on the same local full-market daily history as the frozen backtest.

Declared before running; results are reported whichever way they come out.

1. Gap-up: sell at the open, or keep holding?
   Stock-days 2024-01-02..2026-10-29, not ST that day, listed >= 120 calendar days, valid open,
   previous close and close. gap = open / previous close - 1. What keeping the stock instead of
   selling at the open earns: same-day close / open - 1 (h0), next close / open - 1 (h1) and the
   close four sessions later / open - 1 (h4). Equal weight inside each date, then the mean over
   dates; Newey-West t with lag = horizon. Excess = minus the CSI All Share's open-to-close over
   the same span. Splits: gap bucket, prior five-session return >= 10% or not, calendar year.
   Same-day selling at the open or at the close pays the same fee, so the fee does not change h0.
   Opens at the limit cannot close higher on the day, so h0 <= 0 there by construction.

2. Recent-edge switching and the regime stance.
   Same signals, choices and edge flags as the frozen backtest. For every decision day: the
   equal-weight alpha and beta baskets bought at the next open and sold at the fifth close after
   0.2% cost, minus the index over the same span. Compare days with and without the recent-edge
   flag, and days by stance. Newey-West t with lag 5. Trade-level cross-check from the 'alpha'
   strategy simulation, split by the edge flag on the decision day.
"""
import json
from pathlib import Path
import sys

import numpy as np

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'scripts/report/strategy_backtest.py').is_file())
sys.path.insert(0, str(ROOT / 'scripts'))
from report.strategy_backtest import (HOLD, _basket_forward, daily_choices, load_history, mark_edges,  # noqa: E402
                                      signals, simulate)

HISTORY = ROOT / '.generated/backtest-history'
CACHE = ROOT / '.generated/market-returns-v2'
FROZEN_INPUTS = '85dcc793dbfda5b84885cd97ece1408adcfc76e92fca2541c5f7c362b750ca07'
BUCKETS = [('低开超过2%', -np.inf, -2), ('低开0至2%', -2, 0), ('高开0至2%', 0, 2), ('高开2%至3%', 2, 3),
           ('高开3%至5%', 3, 5), ('高开5%以上未到涨停', 5, None), ('开盘涨停', None, None)]


def newey_west_t(values, lag):
    x = np.asarray([v for v in values if not np.isnan(v)], dtype=float)
    n = len(x)
    if n < lag + 3:
        return float('nan')
    e = x - x.mean()
    s = e @ e / n
    for k in range(1, lag + 1):
        s += 2 * (1 - k / (lag + 1)) * (e[k:] @ e[:-k]) / n
    return float(x.mean() / np.sqrt(s / n)) if s > 0 else float('nan')


def load():
    calendar = json.loads((HISTORY / 'calendar.json').read_text(encoding='utf-8'))
    days = sorted(f"{r['cal_date'][:4]}-{r['cal_date'][4:6]}-{r['cal_date'][6:]}" for r in calendar['rows']
                  if int(r['is_open']) == 1)
    days = [d for d in days if '2024-01-02' <= d <= '2026-10-29']
    assert all((CACHE / f'{d}.json').is_file() for d in days)
    bench = json.loads((HISTORY / 'benchmark.json').read_text(encoding='utf-8'))['rows']
    basics = json.loads((HISTORY / 'basics.json').read_text(encoding='utf-8'))['rows']
    names = json.loads((HISTORY / 'namechange.json').read_text(encoding='utf-8'))['rows']
    return load_history(CACHE, days, bench, basics, names)


def summarize(per_date, lag):
    values = np.array([v for v in per_date if not np.isnan(v)])
    return {'dates': int(len(values)), 'mean_pct': round(float(values.mean()), 3) if len(values) else None,
            'nw_t': round(newey_west_t(values, lag), 2) if len(values) else None}


def gap_study(h):
    days, n = h['days'], len(h['days'])
    o, pre, c, el, limit = h['open'], h['pre'], h['close'], h['eligible'], h['limit'][:, None]
    growth, m_growth = 1 + h['returns'] / 100, 1 + h['m_ret'] / 100   # previous-close based, so ex-rights safe
    gap = (o / pre - 1) * 100
    prior5 = np.full(c.shape, np.nan)
    prior5[:, 5:] = (np.prod([growth[:, j:n - 5 + j] for j in range(5)], axis=0) - 1) * 100   # sessions t-5..t-1
    at_limit = gap >= limit - 0.2
    results = {}
    for horizon, lag in (('h0', 1), ('h1', 2), ('h4', 5)):
        k = {'h0': 0, 'h1': 1, 'h4': 4}[horizon]
        chain, m_chain = np.full(c.shape, np.nan), np.full(n, np.nan)
        chain[:, :n - k] = np.prod([growth[:, j:n - k + j] for j in range(1, k + 1)], axis=0) if k else 1.0
        m_chain[:n - k] = np.prod([m_growth[j:n - k + j] for j in range(1, k + 1)], axis=0) if k else 1.0
        hold = (c / o * chain - 1) * 100
        m_hold = (h['m_close'] / h['m_open'] * m_chain - 1) * 100
        excess = hold - m_hold[None, :]
        base = el & ~np.isnan(gap) & ~np.isnan(hold)
        for label, lo, hi in BUCKETS:
            if label == '开盘涨停':
                mask = base & at_limit
            elif hi is None:
                mask = base & (gap >= lo) & ~at_limit
            else:
                mask = base & (gap >= lo) & (gap < hi) & ~at_limit
            for split, extra in (('全部', None), ('前5日已涨10%以上', prior5 >= 10), ('前5日涨幅不到10%', prior5 < 10)):
                m = mask if extra is None else mask & extra
                for year in ('全部', '2024', '2025', '2026'):
                    cols = np.array([year == '全部' or d.startswith(year) for d in days])
                    mm = m & cols[None, :]
                    counts = mm.sum(axis=0)
                    with np.errstate(all='ignore'):
                        per_abs = np.where(counts > 0, np.nansum(np.where(mm, hold, 0), axis=0) / counts, np.nan)
                        per_exc = np.where(counts > 0, np.nansum(np.where(mm, excess, 0), axis=0) / counts, np.nan)
                    key = f'{horizon}|{label}|{split}|{year}'
                    vals = hold[mm]
                    results[key] = {'events': int(mm.sum()), 'abs': summarize(per_abs, lag), 'excess': summarize(per_exc, lag),
                                    'median_pct': round(float(np.median(vals)), 3) if vals.size else None,
                                    'up_share': round(float((vals > 0).mean()), 3) if vals.size else None}
    return results


def edge_study(h):
    s = signals(h)
    choices = daily_choices(h, s)
    mark_edges(h, choices)
    rows = []
    for t, choice in enumerate(choices):
        if choice is None or choice['stance'] is None or t + HOLD >= len(h['days']):
            continue
        m = h['m_ret'][t + 2:t + HOLD + 1]
        if np.isnan(h['m_open'][t + 1]) or np.isnan(m).any():
            continue
        index_fwd = (h['m_close'][t + 1] / h['m_open'][t + 1] * np.prod(1 + m / 100) - 1) * 100
        a, b = _basket_forward(h, choice['alpha'], t), _basket_forward(h, choice['beta'], t)
        rows.append({'day': h['days'][t], 'edge': bool(choice.get('edge')), 'stance': choice['stance'],
                     'index': index_fwd, 'alpha': a, 'beta': b})
    out = {}
    for basket in ('alpha', 'beta'):
        for name, keep in (('近期有优势', lambda r: r['edge']), ('近期无优势', lambda r: not r['edge']),
                           ('进攻', lambda r: r['stance'] == 'offense'), ('均衡', lambda r: r['stance'] == 'balanced'),
                           ('防守', lambda r: r['stance'] == 'defense'), ('全部', lambda r: True)):
            sel = [r for r in rows if keep(r) and r[basket] is not None]
            out[f'{basket}|{name}'] = {'abs': summarize([r[basket] for r in sel], HOLD),
                                       'excess': summarize([r[basket] - r['index'] for r in sel], HOLD),
                                       'index': summarize([r['index'] for r in sel], HOLD)}
    start = next(t for t, c in enumerate(choices) if c is not None and c['stance'] is not None)
    _, trades, _ = simulate(h, choices, 'alpha', start)
    position = {d: k for k, d in enumerate(h['days'])}
    split = {'近期有优势': [], '近期无优势': []}
    for trade in trades:
        if trade['reason'] == 'open':
            continue
        decided = choices[position[trade['entry']] - 1]
        split['近期有优势' if decided.get('edge') else '近期无优势'].append((trade['exit_value'] / trade['cost_basis'] - 1) * 100)
    out['alpha_trades'] = {k: {'trades': len(v), 'mean_pct': round(float(np.mean(v)), 3), 'median_pct': round(float(np.median(v)), 3),
                               'win_share': round(float(np.mean([x > 0 for x in v])), 3)} for k, v in split.items()}
    return out


def main():
    h = load()
    assert h['inputs_sha256'] == FROZEN_INPUTS, h['inputs_sha256']
    result = {'inputs_sha256': h['inputs_sha256'], 'sessions': len(h['days']), 'first': h['days'][0], 'last': h['days'][-1],
              'gap': gap_study(h), 'edge': edge_study(h)}
    out = Path(__file__).with_name('wiki_evidence.json')
    out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding='utf-8')
    print('written', out)


if __name__ == '__main__':
    main()
