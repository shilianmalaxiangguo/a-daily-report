"""Prints the holding-count, schedule, loss-profile, best-period and guard tables used in the Wiki (round five)."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
design = json.loads((HERE / 'small_cap_design.json').read_text(encoding='utf-8'))['windows']
outlier = json.loads((HERE / 'outlier_check.json').read_text(encoding='utf-8'))
WINDOWS = (('from_2024-07', '2024-07-01起'), ('from_2024-01-31', '2024-01-31起（含2024年2月小盘大跌）'))
PLAN = '3只业绩为正里最冷门|每20日换'


def pct(v, digits=1):
    return f"{v:+.{digits}f}%"


def runs(window, name):
    return design[window]['configs'][name]['all_runs']


def spread(values, fmt=pct):
    values = sorted(values)
    mid = values[len(values) // 2] if len(values) % 2 else (values[len(values) // 2 - 1] + values[len(values) // 2]) / 2
    return f"{fmt(mid)}（{fmt(values[0])}至{fmt(values[-1])}）" if len(values) > 1 else fmt(mid)


def label(name):
    rule, _, guard = name.partition('|每20日换')
    rule = rule.replace('事后补测|', '事后补测：')
    return rule + (f"＋{guard.strip('|')}" if guard else '')


print('表16 持股几只、怎样挑（每20个交易日换一次；随机挑选各20次，规则挑选各4个起点）\n')
print('| 做法 | 起点 | 年化中位（最低至最高） | 最大回撤中位（最差） | 净值最低（最差） | 一期亏超10%的次数中位（最多） | 跑赢创业板指的比例 | 净值守住0.8的比例 |')
print('|---|---|---|---|---|---|---|---|')
for window, wlabel in WINDOWS:
    ref = design[window]['chinext']['20']
    print(f"| 对照：一直持有创业板指 | {wlabel} | {pct(ref['cagr_pct'])} | {pct(ref['max_drawdown_pct'])} | {ref['lowest_nav']:.2f} | {ref['big_loss']} | — | — |")
    for name in ('随机1只|每20日换', '随机2只|每20日换', '随机3只|每20日换', '随机5只|每20日换', '随机10只|每20日换', '整篮子|每20日换',
                 PLAN, '3只最冷门|每20日换', '3只最低波动|每20日换', '事后补测|5只业绩为正里最冷门|每20日换', '事后补测|10只业绩为正里最冷门|每20日换'):
        rs, s = runs(window, name), design[window]['configs'][name]['summary']
        shown = label(name).replace('整篮子', '整篮子（成交额最小五分之一，约950只）')
        if name == PLAN:
            shown = '执行计划：' + shown
        print(f"| {shown} | {wlabel} | {spread([r['cagr_pct'] for r in rs])} | {pct(s['max_drawdown_pct']['median'])}（{pct(min(r['max_drawdown_pct'] for r in rs))}） | "
              f"{min(r['lowest_nav'] for r in rs):.2f} | {s['big_loss']['median']:.0f}（{max(r['big_loss'] for r in rs)}） | "
              f"{sum(r['beats_chinext'] for r in rs)}/{len(rs)} | {sum(r['nav_above_0.8'] for r in rs)}/{len(rs)} |")

print('\n表17 小亏还是偶尔大亏：每20个交易日算一期（2024-07-01起；小亏0至-5%，中亏-5%至-10%，大亏超过-10%，大赚超过+10%）\n')
print('| 做法 | 期数 | 亏钱的期 | 小亏 | 中亏 | 大亏 | 大赚 | 最差一期 | 最好一期 | 每期波动损耗 | 最长水下（交易日） |')
print('|---|---|---|---|---|---|---|---|---|---|---|')
ref = design['from_2024-07']['chinext']['20']


def row(shown, r):
    losing = r['small_loss'] + r['medium_loss'] + r['big_loss']
    best = f"{r['best_period_pct']:+.1f}%" if 'best_period_pct' in r else '—'
    print(f"| {shown} | {r['periods']} | {losing} | {r['small_loss']} | {r['medium_loss']} | {r['big_loss']} | {r['big_gain']} | "
          f"{r['worst_period_pct']:+.1f}% | {best} | {r['swing_cost_pct']:.2f}个百分点 | {r['longest_underwater_sessions']} |")


row('一直持有创业板指（同样的换手日）', ref)
row('执行计划：3只业绩为正里最冷门（起点2024-07-01，日报用的就是这条）', runs('from_2024-07', PLAN)[0])
for k, offset in ((1, 5), (2, 10), (3, 15)):
    row(f'同规则，起点晚{offset}个交易日', runs('from_2024-07', PLAN)[k])
row('整篮子（起点2024-07-01）', runs('from_2024-07', '整篮子|每20日换')[0])
row('3只最冷门（起点2024-07-01）', runs('from_2024-07', '3只最冷门|每20日换')[0])
rs = runs('from_2024-07', '随机3只|每20日换')
print(f"| 随机3只（20次的中位） | {rs[0]['periods']} | — | {design['from_2024-07']['configs']['随机3只|每20日换']['summary']['small_loss']['median']:.0f} | "
      f"{design['from_2024-07']['configs']['随机3只|每20日换']['summary']['medium_loss']['median']:.0f} | "
      f"{design['from_2024-07']['configs']['随机3只|每20日换']['summary']['big_loss']['median']:.0f}（最多{max(r['big_loss'] for r in rs)}） | "
      f"{design['from_2024-07']['configs']['随机3只|每20日换']['summary']['big_gain']['median']:.0f} | "
      f"{design['from_2024-07']['configs']['随机3只|每20日换']['summary']['worst_period_pct']['median']:+.1f}%（最差{min(r['worst_period_pct'] for r in rs):+.1f}%） | — | "
      f"{design['from_2024-07']['configs']['随机3只|每20日换']['summary']['swing_cost_pct']['median']:.2f}个百分点 | "
      f"{design['from_2024-07']['configs']['随机3只|每20日换']['summary']['longest_underwater_sessions']['median']:.0f} |")

print('\n表18 多久一换（整篮子；各4个起点）\n')
print('| 换手 | 2024-07-01起年化中位 | 最大回撤中位 | 一期亏超10%的次数中位 | 每期波动损耗 | 2024-01-31起年化中位 | 最大回撤中位 | 跑赢创业板指的比例（两个起点合计） |')
print('|---|---|---|---|---|---|---|---|')
for name, shown in (('整篮子|每10日换', '每10个交易日'), ('整篮子|每20日换', '每20个交易日（现行）'), ('整篮子|每40日换', '每40个交易日'),
                    ('整篮子|每60日换', '每60个交易日'), ('整篮子|每月末换', '每月最后一个交易日')):
    a, b = design['from_2024-07']['configs'][name], design['from_2024-01-31']['configs'][name]
    beat = sum(r['beats_chinext'] for r in a['all_runs'] + b['all_runs'])
    print(f"| {shown} | {pct(a['summary']['cagr_pct']['median'])} | {pct(a['summary']['max_drawdown_pct']['median'])} | {a['summary']['big_loss']['median']:.0f} | "
          f"{a['summary']['swing_cost_pct']['median']:.2f}个百分点 | {pct(b['summary']['cagr_pct']['median'])} | {pct(b['summary']['max_drawdown_pct']['median'])} | "
          f"{beat}/{len(a['all_runs']) + len(b['all_runs'])} |")

print('\n表19 去掉最好的一两期（事后补测；被去掉的期按0收益算；创业板指用同样的换手日；4个起点的中位与范围）\n')
print('| 做法 | 起点 | 全部 | 去掉最好一期 | 去掉最好两期 | 最好的两期 |')
print('|---|---|---|---|---|---|')
for window, wlabel in WINDOWS:
    for name, shown in (('创业板指（同样的换手日）', '一直持有创业板指'), ('整篮子', '整篮子'), ('3只业绩为正里最冷门', '执行计划：3只业绩为正里最冷门'),
                        ('3只最冷门', '3只最冷门'), ('3只最低波动', '3只最低波动')):
        rs = outlier[window][name]
        best = '；'.join('、'.join(f"{v:+.0f}%" for v in r['best_two_periods_pct']) for r in rs)
        print(f"| {shown} | {wlabel} | {spread([r['all_pct'] for r in rs])} | {spread([r['without_best_pct'] for r in rs])} | "
              f"{spread([r['without_best_two_pct'] for r in rs])} | {best} |")

print('\n表20 两种防大亏的办法（每20个交易日换；各4个起点）\n')
print('| 做法 | 起点 | 年化中位（最低至最高） | 最大回撤中位（最差） | 一期亏超10%的次数中位 | 跑赢创业板指的比例 |')
print('|---|---|---|---|---|---|')
for window, wlabel in WINDOWS:
    for name in ('整篮子|每20日换', '整篮子|每20日换|中证2000跌破20日均线清仓', '整篮子|每20日换|净值从高点回撤10%清仓',
                 '3只最低波动|每20日换', '3只最低波动|每20日换|中证2000跌破20日均线清仓', '3只最低波动|每20日换|净值从高点回撤10%清仓'):
        rs, s = runs(window, name), design[window]['configs'][name]['summary']
        print(f"| {label(name)} | {wlabel} | {spread([r['cagr_pct'] for r in rs])} | {pct(s['max_drawdown_pct']['median'])}（{pct(min(r['max_drawdown_pct'] for r in rs))}） | "
              f"{s['big_loss']['median']:.0f} | {sum(r['beats_chinext'] for r in rs)}/{len(rs)} |")
