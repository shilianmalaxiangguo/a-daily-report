"""Hindsight check (both sleeves were chosen after their results were seen): small-stock rotation mixed with the
growth basket from industry_rotation.py, held as two sleeves that are never rebalanced against each other.
Four start offsets, as in industry_rotation.py."""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import industry_rotation as ir  # noqa: E402
from report.strategy_backtest import _metrics  # noqa: E402


def main():
    out = {'note': 'hindsight: two sleeves chosen after their results were seen; no rebalancing between sleeves', 'mixes': {}}
    for w_small in (1.0, 0.7, 0.5, 0.0):
        runs = []
        for offset in (0, 5, 10, 15):
            small, span, _ = ir.run('SMALL', offset)
            growth, span2, _ = ir.run('IIIA', offset)
            assert span == span2
            nav = w_small * small + (1 - w_small) * growth
            m = _metrics(nav, span)
            a = max(k for k, d in enumerate(span) if d <= '2026-06-30')
            z = max(k for k, d in enumerate(span) if d <= '2026-02-27')
            runs.append({'cagr_pct': m['cagr_pct'], 'max_drawdown_pct': m['max_drawdown_pct'], 'lowest_nav': float(nav.min()),
                         'mar_jun_pct': (nav[a] / nav[z] - 1) * 100, 'jul_oct_pct': (nav[-1] / nav[a] - 1) * 100, 'sharpe': m['sharpe']})
        key = f'小盘{int(w_small * 100)}%＋业绩增长{int(round((1 - w_small) * 100))}%'
        out['mixes'][key] = {k: {'mean': round(float(np.mean([r[k] for r in runs])), 2), 'min': round(float(min(r[k] for r in runs)), 2),
                                 'max': round(float(max(r[k] for r in runs)), 2)} for k in runs[0]}
    (HERE / 'mix_small_growth.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    for key, s in out['mixes'].items():
        print(key, s['cagr_pct']['mean'], s['max_drawdown_pct']['mean'], s['lowest_nav']['min'], s['sharpe']['mean'])


if __name__ == '__main__':
    main()
