"""Sell rules on the user's last 20 months (declared before running, 2026-11-01, round eighteen).

User, 2026-10-31: "就从这最近20个月的数据，我觉得就已经很可以了。之前的版本不具备参考意义了，就是超过20个月之前的".
The same account, list and 15 runs as sell_rules.py (round sixteen); only the window changes. First decision day
2025-02-28 (on the plan's 20-session calendar from 2024-07-01; the frozen data ends 2026-10-29), start offsets 0, 5,
10, 15 sessions (4 paths). Per run as in sell_rules.py; per rule: the median annual return, the drawdown range, the
lowest net value, paths beating ChiNext, and against the base (no take-profit) the paths with a higher annual return,
the paths with a deeper drawdown and the median gap. ChiNext and CSI 2000 held over each path, the same way.
One more run, only to explain a gap: the daily report's backtest curve buys every name afresh at each rotation's open,
so a kept name's take-profit line restarts there, while the rule (and this account) keeps the price first paid. So
TP10 with every name sold and bought again at each rotation (REBAL+TP10), the same 4 paths.
For the report's charts: on offset 0, the net values of the base, TP10, ChiNext and CSI 2000, and their 20-session
period returns.
Nothing is chosen here: the plan already uses take-profit 10% (v0.3). These 20 months were part of the data the rule
was chosen on, so this is not a new test of it; H17 (the forward ledger) is. The base on offset 0 must equal
account_names.simulate(5) from the same start.
"""
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import sell_rules as sr  # noqa: E402

FIRST = '2025-02-28'
OFFSETS = (0, 5, 10, 15)
KEYS = ('start', 'cagr_pct', 'max_drawdown_pct', 'lowest_nav', 'final_nav', 'beats_chinext', 'big_loss', 'big_gain',
        'periods', 'worst_period_pct', 'fees_pct_of_start', 'idle_pct', 'rule_sales', 'gave_up_mean_pct')


def held_index(series, start):
    nav = series[start:] / series[start]
    p = sr.ra.profile(nav, sr.days[start:], list(range(start, sr.n - 1, 20)), start)
    return {'start': sr.days[start], 'cagr_pct': round(p['cagr_pct'], 2), 'max_drawdown_pct': round(p['max_drawdown_pct'], 2),
            'lowest_nav': round(p['lowest_nav'], 3), 'final_nav': round(float(nav[-1]), 3), 'big_loss': p['big_loss'],
            'big_gain': p['big_gain'], 'periods': p['periods'], 'worst_period_pct': round(p['worst_period_pct'], 1)}


def periods(nav, start):
    """Returns between decision-day closes, the same cut as b1_point/real_account profile()."""
    idx = [t - start for t in range(start, sr.n - 1, 20)] + [len(nav) - 1]
    return [{'from': sr.days[start + idx[k]], 'to': sr.days[start + idx[k + 1]],
             'pct': round(float(nav[idx[k + 1]] / nav[idx[k]] - 1) * 100, 2)} for k in range(len(idx) - 1)]


def summarise(paths, base):
    pairs = list(zip(paths, base))
    return {'median_cagr_pct': round(float(np.median([a['cagr_pct'] for a, _ in pairs])), 2),
            'drawdown_shallowest': max(a['max_drawdown_pct'] for a, _ in pairs),
            'drawdown_deepest': min(a['max_drawdown_pct'] for a, _ in pairs),
            'lowest_nav': min(a['lowest_nav'] for a, _ in pairs),
            'beats_chinext': sum(a['beats_chinext'] for a, _ in pairs),
            'higher_than_base': sum(a['cagr_pct'] > b['cagr_pct'] for a, b in pairs),
            'deeper_than_base': sum(a['max_drawdown_pct'] < b['max_drawdown_pct'] for a, b in pairs),
            'median_gap_pp': round(float(np.median([a['cagr_pct'] - b['cagr_pct'] for a, b in pairs])), 2)}


def main():
    first = sr.days.index(FIRST)
    assert (first - sr.days.index('2024-07-01')) % 20 == 0, 'the first day is not on the plan calendar'
    out = {'window': {'first': FIRST, 'last': sr.days[-1], 'offsets': list(OFFSETS)}, 'rules': {}, 'explain': {},
           'chinext': [held_index(sr.ra.sd.chinext, first + o) for o in OFFSETS],
           'csi2000': [held_index(sr.ra.sd.c2000, first + o) for o in OFFSETS]}
    navs = {}
    for name, kw in sr.RULES.items():
        runs = [sr.simulate(first, offset, keep_nav=True, **kw) for offset in OFFSETS]
        navs[name] = runs[0]['nav']
        out['rules'][name] = {'paths': [{k: r[k] for k in KEYS} for r in runs]}
        print(name, [(r['cagr_pct'], r['max_drawdown_pct']) for r in runs], flush=True)
    runs = [sr.simulate(first, offset, rule=('REBAL', 'TP10')) for offset in OFFSETS]
    out['explain']['REBAL+TP10'] = {'paths': [{k: r[k] for k in KEYS} for r in runs]}
    print('REBAL+TP10', [(r['cagr_pct'], r['max_drawdown_pct']) for r in runs], flush=True)
    ref, base0 = sr.an.simulate(5, first, 0), out['rules']['base']['paths'][0]
    assert (ref['cagr_pct'], ref['max_drawdown_pct']) == (base0['cagr_pct'], base0['max_drawdown_pct']), (ref, base0)
    print('base on offset 0 reproduces account_names.simulate(5)', flush=True)
    base = out['rules']['base']['paths']
    for group in (out['rules'], out['explain']):
        for name, x in group.items():
            x['summary'] = summarise(x['paths'], base)
            print(name, x['summary'], flush=True)
    series = {'TP10': navs['TP10'], 'base': navs['base'], 'chinext': sr.ra.sd.chinext[first:] / sr.ra.sd.chinext[first],
              'csi2000': sr.ra.sd.c2000[first:] / sr.ra.sd.c2000[first]}
    out['charts'] = {'dates': list(sr.days[first:]), 'nav': {k: [round(float(v), 5) for v in s] for k, s in series.items()},
                     'periods': {k: periods(s, first) for k, s in series.items()}}
    (HERE / 'sell_rules_20m.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written sell_rules_20m.json')


if __name__ == '__main__':
    main()
