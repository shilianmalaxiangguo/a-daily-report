"""Prints the round-thirteen tables (monthly returns; starting mid-period) from monthly_view.json and late_entry.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
m = json.loads((HERE / 'monthly_view.json').read_text(encoding='utf-8'))
late = json.loads((HERE / 'late_entry.json').read_text(encoding='utf-8'))
WINDOW = {'from_2024-07': '2024-07-01起', 'from_2024-01-31': '2024-01-31起（含2024年2月小盘大跌）'}


def pct(v, d=1):
    return f"{v:+.{d}f}%"


print('表33 按月看（用户的账户：1万元、万一免五、主板和创业板、5只；四个起步日）\n')
print('| 起点 | 做法 | 年化 | 平均每月（复利） | 月中位数 | 上涨的月份 | 最好一个月 | 最差一个月 | 涨10%以上的月份 | 跌10%以上的月份 | 最好的连续12个月 | 最差的连续12个月 |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|')
for window, label in WINDOW.items():
    block = m[window]
    for r in block['runs']:
        print(f"| {label} | 执行计划，晚{r['offset']}个交易日起步 | {pct(r['annual_pct'])} | {pct(r['geo_month_pct'], 2)} | {pct(r['median_month_pct'], 2)} | "
              f"{r['up_share'] * 100:.0f}% | {pct(r['best_month_pct'])} | {pct(r['worst_month_pct'])} | {r['months_10_up']}/{r['months']} | "
              f"{r['months_10_down']}/{r['months']} | {pct(r['best_12m_pct'])} | {pct(r['worst_12m_pct'])} |")
    for key, name in (('chinext', '一直持有创业板指'), ('csi2000', '一直持有中证2000')):
        r = block['refs'][key]
        print(f"| {label} | {name} | {pct(r['annual_pct'])} | {pct(r['geo_month_pct'], 2)} | {pct(r['median_month_pct'], 2)} | {r['up_share'] * 100:.0f}% | "
              f"{pct(r['best_month_pct'])} | {pct(r['worst_month_pct'])} | {r['months_10_up']}/{r['months']} | {r['months_10_down']}/{r['months']} | "
              f"{pct(r['best_12m_pct'])} | {pct(r['worst_12m_pct'])} |")

print('\n表34 一期中途才开始：用这一期的名单，还是用进场前一天收盘重新排的名单（5只，等权，每次来回0.2%，拿到下一个换手日）\n')
print('| 起点 | 第几个交易日后才开始 | 次数 | 这一期的名单：平均 | 重新排的名单：平均 | 重新排的更好的比例 | 平均多出 | t值 | 两份名单平均差几只 |')
print('|---|---|---|---|---|---|---|---|---|')
for window, label in WINDOW.items():
    for k in (5, 10):
        r = late[f'{window}|{k}']
        print(f"| {label} | {k} | {r['entries']} | {pct(r['period_mean'], 2)} | {pct(r['fresh_mean'], 2)} | {r['fresh_better_share'] * 100:.0f}% | "
              f"{r['mean_gap_pp']:+.2f}个百分点 | {r['t']:.2f} | {r['names_differ_mean']:.1f} |")
