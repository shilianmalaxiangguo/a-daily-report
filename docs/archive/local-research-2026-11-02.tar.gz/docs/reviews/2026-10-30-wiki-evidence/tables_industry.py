"""Prints the sector, stock-selection and growth table used in the Wiki from industry_rotation.json."""
import json
from pathlib import Path

r = json.loads((Path(__file__).resolve().parent / 'industry_rotation.json').read_text(encoding='utf-8'))


def pct(v):
    return f"{v:+.1f}%"


print('表15 不买指数、选行业和个股（净值从1开始；2024-07-01起；每20个交易日换；扣成本；四个起点）\n')
print('| 写法 | 年化平均（最低至最高） | 最大回撤平均 | 净值最低（最差起点） | 2026年3至6月 | 2026年7至10月 | 2024-09-02起年化 |')
print('|---|---|---|---|---|---|---|')
for name, v in r['benchmarks'].items():
    print(f"| 对照：一直持有{name} | {pct(v['cagr_pct'])} | {pct(v['max_drawdown_pct'])} | {v['lowest_nav']:.2f} | {pct(v['2026-03_to_06_pct'])} | "
          f"{pct(v['2026-07_to_10_pct'])} | {pct(v['from_2024-09-02']['cagr_pct'])} |")
for name, v in r['variants'].items():
    s = v['summary']
    label = name.replace('|', '，')
    print(f"| {label} | {pct(s['cagr_pct']['mean'])}（{pct(s['cagr_pct']['min'])}至{pct(s['cagr_pct']['max'])}） | {pct(s['max_drawdown_pct']['mean'])} | "
          f"{s['lowest_nav']['min']:.2f} | {pct(s['2026-03_to_06_pct']['mean'])} | {pct(s['2026-07_to_10_pct']['mean'])} | {pct(s['from_2024-09-02_cagr_mean'])} |")
print('\n2026年3至6月等权涨幅最高的行业：' + '、'.join(f"{g} {v:+.1f}%" for g, v in r['industries_2026-03_to_06'][:6]))
for name in ('I-A|只选行业|前3个|看120日', '事后补测P|行业龙头：前3个行业成交最活跃的各5只|看60日'):
    held = [f"{e['date'][5:]} {'、'.join(e['industries'])}" for e in r['variants'][name]['holdings_since_2025-12'] if '2026-02' <= e['date'] <= '2026-08']
    print(f"{name.replace('|', '，')} 在2026年的换手日选中：" + '；'.join(held))
