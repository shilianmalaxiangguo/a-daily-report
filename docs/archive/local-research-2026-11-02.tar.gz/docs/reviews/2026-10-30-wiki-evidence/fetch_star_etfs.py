"""Fetch daily bars, fees and latest shares of representative STAR ETFs (own file; other caches untouched)."""
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'scripts'))
from market_data.tushare_client import create_tushare_pro_api  # noqa: E402
from report.market_returns import _pages  # noqa: E402

CODES = {'588000.SH': '科创50', '588080.SH': '科创50', '588170.SH': '半导体材料设备', '588200.SH': '芯片', '588780.SH': '芯片设计',
         '588190.SH': '科创100', '588230.SH': '科创200', '589880.SH': '科创综指', '588790.SH': '人工智能', '588260.SH': '新一代信息技术',
         '588010.SH': '新材料', '588700.SH': '生物医药', '589720.SH': '创新药', '588830.SH': '新能源', '588110.SH': '成长', '588850.SH': '工业机械'}
start, end = sys.argv[2], sys.argv[3]
pro = create_tushare_pro_api(timeout_seconds=60)
out = {'retrieved_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(), 'start': start, 'end': end,
       'source': 'tushare.fund_daily / fund_basic / fund_share', 'etfs': {}}
basics = {r['ts_code']: r for r in _pages(pro, 'fund_basic', market='E', fields='ts_code,name,list_date,m_fee,c_fee,benchmark')}
for code, theme in CODES.items():
    rows = _pages(pro, 'fund_daily', ts_code=code, start_date=start.replace('-', ''), end_date=end.replace('-', ''),
                  fields='ts_code,trade_date,open,close,pre_close,amount')
    rows = sorted(rows, key=lambda r: r['trade_date'])
    assert [r['trade_date'] for r in rows] == sorted({r['trade_date'] for r in rows}), code
    try:
        shares = _pages(pro, 'fund_share', ts_code=code, start_date=(end.replace('-', ''))[:6] + '01', end_date=end.replace('-', ''),
                        fields='ts_code,trade_date,fd_share')
        latest = max(shares, key=lambda r: r['trade_date']) if shares else None
    except Exception as error:
        latest = {'error': type(error).__name__}
    b = basics.get(code, {})
    out['etfs'][code] = {'theme': theme, 'name': b.get('name'), 'list_date': b.get('list_date'), 'm_fee': b.get('m_fee'),
                         'c_fee': b.get('c_fee'), 'benchmark': b.get('benchmark'), 'latest_share': latest, 'rows': rows}
    print(code, theme, b.get('name'), len(rows), rows[0]['trade_date'] if rows else None, rows[-1]['trade_date'] if rows else None,
          'fee', b.get('m_fee'), b.get('c_fee'), 'share', (latest or {}).get('fd_share'))
target = ROOT / '.generated/backtest-history/star_etfs.json'
target.write_text(json.dumps(out, ensure_ascii=False, default=str), encoding='utf-8')
print('written', target.relative_to(ROOT))
