"""Daily prices and share counts of the broad ETFs the state funds are known to hold, plus the free-cash-flow ETF."""
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'scripts'))
from market_data.tushare_client import create_tushare_pro_api  # noqa: E402
from report.market_returns import _pages  # noqa: E402

ETFS = {'510300.SH': '华泰柏瑞沪深300ETF', '510310.SH': '易方达沪深300ETF', '510330.SH': '华夏沪深300ETF',
        '159919.SZ': '嘉实沪深300ETF', '510050.SH': '华夏上证50ETF', '510500.SH': '南方中证500ETF',
        '512100.SH': '南方中证1000ETF', '588000.SH': '华夏科创50ETF', '159915.SZ': '易方达创业板ETF',
        '159201.SZ': '华夏国证自由现金流ETF'}
start, end = sys.argv[2].replace('-', ''), sys.argv[3].replace('-', '')
pro = create_tushare_pro_api(timeout_seconds=60)
out = {'retrieved_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(), 'start': sys.argv[2], 'end': sys.argv[3],
       'source': 'tushare.fund_daily + fund_share', 'etfs': {}}
for code, name in ETFS.items():
    item = {'name': name}
    for endpoint, fields, key in (('fund_daily', 'ts_code,trade_date,open,close,pre_close,amount', 'prices'),
                                  ('fund_share', 'ts_code,trade_date,fd_share', 'shares')):
        try:
            rows = sorted(_pages(pro, endpoint, ts_code=code, start_date=start, end_date=end, fields=fields),
                          key=lambda r: r['trade_date'])
            assert all(r['ts_code'] == code for r in rows)
            assert [r['trade_date'] for r in rows] == sorted({r['trade_date'] for r in rows})
            item[key] = rows
        except Exception as error:
            item[key + '_error'] = f'{type(error).__name__}: {str(error)[:120]}'
    out['etfs'][code] = item
    print(code, name, {k: len(v) for k, v in item.items() if isinstance(v, list)}, {k: v for k, v in item.items() if k.endswith('_error')},
          (item.get('prices') or [{}])[0].get('trade_date'), (item.get('shares') or [{}])[0].get('trade_date'))
target = ROOT / '.generated/backtest-history/etf_flows.json'
target.write_text(json.dumps(out, ensure_ascii=False), encoding='utf-8')
print('written', target.relative_to(ROOT))
