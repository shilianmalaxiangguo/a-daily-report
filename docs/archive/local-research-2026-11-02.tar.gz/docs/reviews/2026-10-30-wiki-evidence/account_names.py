"""How many names for the user's actual account: 10,000 yuan, commission 0.01% with no minimum ("万一免五")
(declared before running, 2026-10-31, round twelve).

Pool and execution as in names_count.py (main board and ChiNext; list published after the decision day's close and
traded at the next open; names still on the list are kept; a limit-up open is passed over), with the user's costs:
commission 0.01% of each order and no minimum, stamp duty 0.05% on sales, transfer fee 0.001%.
How it buys: go down the list in order; each empty place gets the cash divided by the empty places; a name whose one
lot (100 shares) costs more than that is passed over and the next name is tried; whole lots only.
Names held: 3, 4, 5, 6, 8, 10.
  rule    the coldest names of the pool (the plan), start offsets 0, 5, 10, 15 sessions;
  random  names drawn at random from the pool on each decision day (20 draws, offset 0).
Windows from 2024-07-01 and from 2024-01-31.
Reported: annual return, max drawdown, lowest net value, beating ChiNext (higher annual return and a shallower max
drawdown, same window), fees as a share of the starting money, average names actually held, average idle cash,
names passed over because one lot did not fit, the deepest list position used, the median price paid; for random,
the spread of annual returns.
"""
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import real_account as ra  # noqa: E402

ra.RATE = 0.0001                      # 万一
ra.ACCOUNTS['1万万一免五'] = (10_000.0, 0.0)
h, days, n, codes = ra.h, ra.days, ra.n, ra.codes
STAR = ('688', '689')


def simulate(k, first, offset=0, seed=None, account='1万万一免五'):
    start_cash, minimum = ra.ACCOUNTS[account]
    rng = np.random.default_rng(seed) if seed is not None else None
    decisions = set(range(first + offset, n - 1, 20))
    start = min(decisions)
    cash, held, pending, plan_list = start_cash, {}, set(), []
    nav, stats, counts, idle, depth, prices = [1.0], Counter(), [], [], [], []
    for d in range(start + 1, n):
        t = d - 1
        switch = t in decisions
        if switch:
            pool = [i for i in ra.ranked(t) if not codes[i].startswith(STAR)]
            plan_list = list(rng.permutation(pool)) if rng is not None else pool
            pending |= {i for i in held if i not in set(plan_list[:k])}
        freed = False
        for i in sorted(pending):
            g = ra.gap(i, d)
            if g is None or g <= -(h['limit'][i] - 0.2):
                continue
            gross = held.pop(i) * h['open'][i, d] / h['pre'][i, d]
            cost = ra.fee(gross, minimum, True)
            cash += gross - cost
            stats['fees'] += cost
            pending.discard(i)
            freed = not switch
        bought = set()
        if plan_list and len(held) < k and (switch or freed):
            for rank, i in enumerate(plan_list, start=1):
                if len(held) >= k:
                    break
                if i in held:
                    continue
                g = ra.gap(i, d)
                if g is None or g >= h['limit'][i] - 0.2:
                    continue
                price = h['open'][i, d]
                budget = cash / (k - len(held))
                shares = np.floor(budget / (price * 100)) * 100
                while shares > 0 and shares * price + ra.fee(shares * price, minimum, False) > budget:
                    shares -= 100
                if shares <= 0:
                    stats['lot_skips'] += 1
                    continue
                amount = shares * price
                cost = ra.fee(amount, minimum, False)
                cash -= amount + cost
                stats['fees'] += cost
                held[i] = shares * h['close'][i, d]
                bought.add(i)
                depth.append(rank)
                prices.append(float(price))
        for i in held:
            c, p = h['close'][i, d], h['pre'][i, d]
            if i not in bought and not (np.isnan(c) or np.isnan(p)):
                held[i] *= c / p
        equity = cash + sum(held.values())
        nav.append(equity / start_cash)
        counts.append(len(held))
        idle.append(cash / equity)
    nav = np.array(nav)
    span = days[start:]
    d = ra.profile(nav, span, sorted(decisions), start)
    ref = ra.profile(ra.chinext_window(start), span, sorted(decisions), start)
    return {'cagr_pct': round(d['cagr_pct'], 2), 'max_drawdown_pct': round(d['max_drawdown_pct'], 2), 'lowest_nav': round(d['lowest_nav'], 3),
            'big_loss': d['big_loss'], 'beats_chinext': bool(d['cagr_pct'] > ref['cagr_pct'] and d['max_drawdown_pct'] > ref['max_drawdown_pct']),
            'chinext_cagr_pct': round(ref['cagr_pct'], 2), 'fees_pct_of_start': round(stats['fees'] / start_cash * 100, 2),
            'held_mean': round(float(np.mean(counts)), 2), 'idle_pct': round(float(np.mean(idle)) * 100, 2), 'lot_skips': stats['lot_skips'],
            'deepest_rank': max(depth) if depth else None, 'price_median': round(float(np.median(prices)), 2) if prices else None}


def main():
    out = {}
    for window, label in (('from_2024-07', '2024-07-01'), ('from_2024-01-31', '2024-01-31')):
        first = days.index(label)
        for k in (3, 4, 5, 6, 8, 10):
            rule = [simulate(k, first, o) for o in (0, 5, 10, 15)]
            rand = [simulate(k, first, 0, seed) for seed in range(20)]
            c = np.array([x['cagr_pct'] for x in rand])
            key = f'{window}|{k}'
            out[key] = {'rule': rule, 'random': rand,
                        'random_spread': {'p10': round(float(np.percentile(c, 10)), 1), 'median': round(float(np.median(c)), 1),
                                          'p90': round(float(np.percentile(c, 90)), 1), 'lowest_nav': min(x['lowest_nav'] for x in rand)}}
            print(key, 'rule', [x['cagr_pct'] for x in rule], 'mdd', [x['max_drawdown_pct'] for x in rule], 'low', min(x['lowest_nav'] for x in rule),
                  'beats', sum(x['beats_chinext'] for x in rule), 'fees', [x['fees_pct_of_start'] for x in rule], 'held', [x['held_mean'] for x in rule],
                  'idle', [x['idle_pct'] for x in rule], 'skips', [x['lot_skips'] for x in rule], 'deep', [x['deepest_rank'] for x in rule],
                  'price', [x['price_median'] for x in rule], '| random', out[key]['random_spread'], flush=True)
    (HERE / 'account_names.json').write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
    print('written account_names.json')


if __name__ == '__main__':
    main()
