"""Equal-weight average of eligible stocks as a second benchmark (no costs), over the frozen backtest window."""
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, load  # noqa: E402
from report.strategy_backtest import _metrics  # noqa: E402

h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
days = h['days']
start, end = days.index('2024-03-04'), days.index('2026-10-29')
r = np.where(h['eligible'] & ~np.isnan(h['returns']), h['returns'], np.nan)
eq = np.nanmean(r, axis=0)[start + 1:end + 1] / 100        # first session is the starting point, as in the frozen curves
m = h['m_ret'][start + 1:end + 1] / 100
out = {}
for name, series in (('equal_weight', eq), ('index', m)):
    curve = np.concatenate([[1.0], np.cumprod(1 + series)])
    dd = curve / np.maximum.accumulate(curve) - 1
    by_year = {}
    for y in ('2024', '2025', '2026'):
        idx = [k + 1 for k, d in enumerate(days[start + 1:end + 1]) if d.startswith(y)]
        by_year[y] = round(float((curve[idx[-1]] / curve[idx[0] - 1] - 1) * 100), 1)
    out[name] = {'total_pct': round(float((curve[-1] - 1) * 100), 1), 'cagr_pct': round(float(_metrics(curve, days[start:end + 1])['cagr_pct']), 1),
                 'max_drawdown_pct': round(float(dd.min() * 100), 1), 'years': by_year}
print(json.dumps(out, ensure_ascii=False))
Path(__file__).with_name('equal_weight.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
