"""Prints the round-seventeen tables (after a take-profit sale; 80/20) from sell_refill.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
r = json.loads((HERE / 'sell_refill.json').read_text(encoding='utf-8'))
LABEL = {'base': '现行：不止盈，拿到换手日', 'WAIT': '止盈10%，钱留到下一个换手日', 'PERIOD': '止盈10%，马上按这一期的名单补下一只',
         'FRESH': '止盈10%，马上按前一天收盘重排的名单补', 'CALM': '止盈10%，中证2000在20日均线上才补，否则留着'}
pct = lambda v: f'{v:+.1f}%'

print('表47 止盈之后的钱：留着，还是马上补下一只（用户的账户：1万元，万一免五，主板和创业板，5只；8条路径）\n')
print('| 做法 | 2024-07起年化中位 | 2024-01-31起年化中位 | 最大回撤（8条路径） | 最低净值 | 跑赢创业板指 | 比“钱留着”：年化更高几条，回撤更深几条 | '
      '2025-04-28起：年化／回撤 | 大亏期数（中位） | 最差的一期 | 平均空着的钱 | 每条路径补买几次 | 费用占本金 |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|---|')
for key, label in LABEL.items():
    x = r['variants'][key]
    versus = f"更高{x['higher_than_wait']}/8，更深{x['deeper_than_wait']}/8" if 'higher_than_wait' in x else '—'
    print(f"| {label} | {pct(x['from_2024-07_median'])} | {pct(x['from_2024-01-31_median'])} | {pct(x['drawdown_shallowest'])}至{pct(x['drawdown_deepest'])} | "
          f"{x['lowest_nav']:.2f} | {x['beats_chinext']}/8 | {versus} | {pct(x['recent_cagr'])}／{pct(x['recent_drawdown'])} | {x['big_loss_median']:g} | "
          f"{pct(x['worst_period_pct'])} | {x['idle_pct_median']:.0f}% | {x['refills_mean']:.0f} | {x['fees_pct_median']:.1f}% |")
better = [LABEL[k] for k, x in r['variants'].items() if x.get('better_than_wait')]
print('\n按事先写定的标准（8条路径里至少6条年化更高、最多2条回撤更深、2025-04-28起不更低）比“钱留着”更好的：' + ('、'.join(better) if better else '没有') + '。')

s = r['tp10_sales']
print('\n表48 止盈10%卖掉的股票，如果一直拿到这一期结束（8条路径的全部卖出，同一笔在几条路径上出现就算几次）\n')
print('| 卖出次数 | 之后涨跌的中位 | 平均 | 又涨了10%以上 | 跌了 | 跌了10%以上 |')
print('|---|---|---|---|---|---|')
print(f"| {s['sales']} | {pct(s['median_pct'])} | {pct(s['mean_pct'])} | {s['rose_10_more_share']:.0%} | {s['fell_share']:.0%} | {s['fell_10_more_share']:.0%} |")

print('\n表49 二八：最好的20%交易日贡献了多少（2024-07-01与2024-01-31起各4个起步日，8条路径的中位）\n')
print('| | 全部交易日 | 只算最好的20%交易日 | 只算其余80%交易日 |')
print('|---|---|---|---|')
for key, label in (('ChiNext', '一直拿创业板指'), ('base', '执行计划：现行'), ('WAIT', '止盈10%，钱留着'), ('PERIOD', '止盈10%，马上补下一只')):
    x = r['eighty_twenty'][key]
    print(f"| {label} | {pct(x['total_pct'])} | {pct(x['best20_pct'])} | {pct(x['other80_pct'])} |")
