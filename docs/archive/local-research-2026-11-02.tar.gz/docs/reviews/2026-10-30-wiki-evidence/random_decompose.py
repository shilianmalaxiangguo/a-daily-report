"""Where the random-picks run loses against the equal-weight average: costs, then exit levels (20 seeds each)."""
from copy import copy
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wiki_evidence import FROZEN_INPUTS, load  # noqa: E402
import report.strategy_backtest as bt  # noqa: E402

h = load()
assert h['inputs_sha256'] == FROZEN_INPUTS
s = bt.signals(h)
choices = bt.daily_choices(h, s)
start = next(t for t, c in enumerate(choices) if c is not None and c['stance'] is not None)
days = h['days'][start:]
no_stop = np.full(len(h['codes']), np.nan)
out = {}
for label, cost, stops in (('原样', True, True), ('不计成本', False, True), ('不计成本且不设失效价', False, False)):
    bt.BUY_COST, bt.SELL_COST = (0.00075, 0.00125) if cost else (0.0, 0.0)
    runs = []
    for seed in range(20):
        rng = np.random.default_rng(seed)
        mod = []
        for t, c in enumerate(choices):
            if c is None:
                mod.append(None)
                continue
            pool = np.flatnonzero(s['complete'][:, t] & (s['amount'][:, t] >= bt.LIQUIDITY_K)
                                  & (h['returns'][:, t] < h['limit'] - bt.LIMIT_MARGIN))
            c2 = copy(c)
            c2['alpha'] = rng.permutation(pool)[:13]
            if not stops:
                c2['stop'] = no_stop
            mod.append(c2)
        curve, trades, exposure = bt.simulate(h, mod, 'alpha', start)
        runs.append(bt._metrics(curve, days, exposure, trades)['cagr_pct'])
    out[label] = {'median_cagr_pct': round(float(np.median(runs)), 2), 'min': round(float(min(runs)), 2), 'max': round(float(max(runs)), 2)}
    print(label, out[label])
bt.BUY_COST, bt.SELL_COST = 0.00075, 0.00125
Path(__file__).with_name('random_decompose.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
null = json.loads(Path(__file__).with_name('random_null.json').read_text(encoding='utf-8'))
for name, frozen_key in (('random', 'beta'), ('random', 'alpha'), ('random_offense', 'beta_offense')):
    target = null['frozen'][frozen_key]['cagr_pct']
    beaten = sum(r['cagr_pct'] >= target for r in null[name]['runs'])
    print(f'{name}: {beaten}/20 random runs reach {frozen_key} CAGR {target}')
